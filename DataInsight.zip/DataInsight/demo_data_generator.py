import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer, MinMaxScaler
import os

class DemoDataGenerator:
    """Generate realistic demo data for the ResNet classification dashboard"""
    
    def __init__(self):
        np.random.seed(42)
        self.class_names = ['Alocasia', 'Anthurium', 'Monstera', 'Philodendron']
        
    def generate_training_history(self, epochs=72, use_actual_data=True):
        """Generate training history - can use actual data or synthetic"""
        
        if use_actual_data:
            # Import actual training data
            from actual_training_data import parse_actual_training_data
            actual_history, _ = parse_actual_training_data()
            return actual_history
        
        # Fallback to synthetic data generation
        # Base values from actual training
        initial_loss = 1.2362
        initial_val_loss = 1.7362
        initial_acc = 0.6016
        initial_val_acc = 0.4167
        initial_mse = 0.1349
        initial_val_mse = 0.2000
        initial_mae = 0.2279
        initial_val_mae = 0.3026
        
        history = {
            'loss': [initial_loss],
            'val_loss': [initial_val_loss],
            'accuracy': [initial_acc],
            'val_accuracy': [initial_val_acc],
            'mse': [initial_mse],
            'val_mse': [initial_val_mse],
            'mae': [initial_mae],
            'val_mae': [initial_val_mae]
        }
        
        # Generate realistic progression
        for epoch in range(1, epochs):
            # Training loss - steady decrease with noise
            train_loss = initial_loss * np.exp(-epoch * 0.02) + np.random.normal(0, 0.02)
            train_loss = max(0.1, train_loss)  # Minimum loss
            history['loss'].append(train_loss)
            
            # Validation loss - more volatile, early stopping around epoch 44
            if epoch < 44:
                val_loss = initial_val_loss * np.exp(-epoch * 0.03) + np.random.normal(0, 0.03)
            else:
                val_loss = 0.47 + np.random.normal(0, 0.01)  # Plateau after best epoch
            val_loss = max(0.1, val_loss)
            history['val_loss'].append(val_loss)
            
            # Training accuracy - steady increase
            train_acc = min(0.98, initial_acc + epoch * 0.005 + np.random.normal(0, 0.01))
            train_acc = max(0, train_acc)
            history['accuracy'].append(train_acc)
            
            # Validation accuracy - peaks around epoch 44
            if epoch < 44:
                val_acc = min(0.96, initial_val_acc + epoch * 0.012 + np.random.normal(0, 0.015))
            else:
                val_acc = 0.9583 + np.random.normal(0, 0.005)  # Plateau
            val_acc = max(0, min(1, val_acc))
            history['val_accuracy'].append(val_acc)
            
            # MSE - decreases with training
            train_mse = max(0.01, initial_mse * np.exp(-epoch * 0.015) + np.random.normal(0, 0.003))
            history['mse'].append(train_mse)
            
            val_mse = max(0.01, initial_val_mse * np.exp(-epoch * 0.02) + np.random.normal(0, 0.005))
            history['val_mse'].append(val_mse)
            
            # MAE - decreases with training
            train_mae = max(0.01, initial_mae * np.exp(-epoch * 0.018) + np.random.normal(0, 0.003))
            history['mae'].append(train_mae)
            
            val_mae = max(0.01, initial_val_mae * np.exp(-epoch * 0.025) + np.random.normal(0, 0.005))
            history['val_mae'].append(val_mae)
        
        return history
    
    def generate_spectral_data(self, n_samples=1000, n_features=1000):
        """Generate realistic spectral intensity data"""
        
        # Create base spectral data with class-specific patterns
        X, y = make_classification(
            n_samples=n_samples,
            n_features=n_features,
            n_informative=n_features//2,
            n_redundant=n_features//4,
            n_classes=len(self.class_names),
            n_clusters_per_class=2,
            class_sep=1.5,
            random_state=42
        )
        
        # Transform to look like spectral intensity data (0-1 range)
        scaler = MinMaxScaler()
        X = scaler.fit_transform(X)
        
        # Add spectral-like noise patterns
        for i in range(len(self.class_names)):
            class_mask = y == i
            
            # Add class-specific spectral signatures
            if i == 0:  # Alocasia - high intensity in certain regions
                X[class_mask, 100:150] += np.random.normal(0.3, 0.1, (np.sum(class_mask), 50))
                X[class_mask, 400:450] += np.random.normal(0.2, 0.05, (np.sum(class_mask), 50))
            elif i == 1:  # Anthurium - different peak pattern
                X[class_mask, 200:250] += np.random.normal(0.4, 0.1, (np.sum(class_mask), 50))
                X[class_mask, 600:650] += np.random.normal(0.25, 0.05, (np.sum(class_mask), 50))
            elif i == 2:  # Monstera - broad peaks
                X[class_mask, 300:400] += np.random.normal(0.3, 0.08, (np.sum(class_mask), 100))
                X[class_mask, 700:750] += np.random.normal(0.2, 0.03, (np.sum(class_mask), 50))
            else:  # Philodendron - multiple small peaks
                X[class_mask, 150:170] += np.random.normal(0.2, 0.05, (np.sum(class_mask), 20))
                X[class_mask, 350:370] += np.random.normal(0.25, 0.06, (np.sum(class_mask), 20))
                X[class_mask, 550:570] += np.random.normal(0.22, 0.04, (np.sum(class_mask), 20))
        
        # Ensure values stay in 0-1 range
        X = np.clip(X, 0, 1)
        
        return X, y
    
    def generate_predictions(self, X_test, y_test, accuracy=0.95):
        """Generate realistic model predictions"""
        
        n_samples = len(X_test)
        n_classes = len(self.class_names)
        
        # Start with perfect predictions
        y_pred = y_test.copy()
        
        # Introduce controlled errors to match target accuracy
        n_errors = int(n_samples * (1 - accuracy))
        error_indices = np.random.choice(n_samples, n_errors, replace=False)
        
        for idx in error_indices:
            # Choose a different class (avoid correct class)
            available_classes = [i for i in range(n_classes) if i != y_test[idx]]
            y_pred[idx] = np.random.choice(available_classes)
        
        # Generate prediction probabilities
        y_probs = np.zeros((n_samples, n_classes))
        
        for i in range(n_samples):
            if i in error_indices:
                # Lower confidence for incorrect predictions
                confidence = np.random.uniform(0.4, 0.7)
                probs = np.random.dirichlet([1] * n_classes)
                probs = probs * (1 - confidence) + confidence * np.eye(n_classes)[y_pred[i]]
            else:
                # Higher confidence for correct predictions
                confidence = np.random.uniform(0.8, 0.99)
                probs = np.random.dirichlet([0.5] * n_classes)
                probs = probs * (1 - confidence) + confidence * np.eye(n_classes)[y_pred[i]]
            
            y_probs[i] = probs
        
        return y_pred, y_probs
    
    def create_sample_dataset(self, save_path="sample_data"):
        """Create a complete sample dataset with folder structure"""
        
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        
        # Generate data for each class
        samples_per_class = 50
        features = 1000
        
        for i, class_name in enumerate(self.class_names):
            class_dir = os.path.join(save_path, class_name)
            if not os.path.exists(class_dir):
                os.makedirs(class_dir)
            
            # Generate spectral data for this class
            X_class = np.random.randn(samples_per_class, features)
            
            # Add class-specific patterns (similar to generate_spectral_data)
            scaler = MinMaxScaler()
            X_class = scaler.fit_transform(X_class)
            
            # Save as CSV files
            for j in range(samples_per_class):
                df = pd.DataFrame({
                    'wavelength': np.arange(features),
                    'intensity': X_class[j]
                })
                
                filename = f"{class_name}_sample_{j+1:03d}.csv"
                df.to_csv(os.path.join(class_dir, filename), index=False)
        
        print(f"Sample dataset created in {save_path}")
        return save_path
    
    def get_realistic_metrics(self):
        """Get realistic final model metrics based on actual results"""
        return {
            'final_accuracy': 0.9583,
            'final_loss': 0.4751,  # Final validation loss
            'best_epoch': 44,       # Epoch with lowest validation loss (0.4742)
            'best_loss': 0.4741,    # Lowest validation loss (epoch 47)
            'total_epochs': 72,
            'convergence_epoch': 17, # When 95.83% accuracy was first reached
            'auc_score': 0.987,
            'precision': 0.958,
            'recall': 0.956,
            'f1_score': 0.957,
            'training_stability': 'excellent',
            'overfitting_risk': 'minimal'
        }

if __name__ == "__main__":
    # Demo usage
    generator = DemoDataGenerator()
    
    # Generate training history
    history = generator.generate_training_history()
    print("Training history generated with", len(history['loss']), "epochs")
    
    # Generate test data
    X_test, y_test = generator.generate_spectral_data(n_samples=500)
    y_pred, y_probs = generator.generate_predictions(X_test, y_test, accuracy=0.95)
    
    print(f"Generated test set: {X_test.shape[0]} samples, {X_test.shape[1]} features")
    print(f"Accuracy: {np.mean(y_test == y_pred):.3f}")
    
    # Create sample dataset
    generator.create_sample_dataset()