# Spectral Decomposition Analysis Dashboard

## Overview

This is a comprehensive Streamlit-based visualization dashboard specifically designed for spectral decomposition and analysis using deep learning. The application analyzes a ResNet-like neural network that classifies spectral data into different stages (stage0-stage3) based on intensity measurements. It integrates authentic training data from a 72-epoch training session that achieved 95.83% validation accuracy, making it ideal for presenting spectral analysis projects and deep learning results.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular architecture with clear separation of concerns:

- **Frontend**: Streamlit web interface with multi-page navigation
- **Backend**: Python-based machine learning pipeline using TensorFlow/Keras
- **Data Processing**: Scikit-learn for preprocessing and evaluation
- **Visualization**: Plotly for interactive charts and graphs
- **Model Architecture**: Custom ResNet-like neural network with residual blocks

## Key Components

### 1. Enhanced Dashboard (`app_enhanced.py`)
- **Purpose**: Comprehensive visualization suite for model analysis
- **Responsibilities**: Multi-page dashboard with 7 distinct visualization sections
- **Framework**: Streamlit with wide layout and interactive components
- **Pages**: 
  - 🏠 Overview: Key metrics and training summary
  - 📈 Training Analysis: Detailed learning curves with actual training data
  - 🎯 Performance Metrics: Confusion matrix, ROC curves, precision-recall
  - 🔍 Advanced Analytics: Error analysis, confidence distributions
  - 📊 Data Exploration: t-SNE and PCA visualizations
  - ⚡ Real-time Monitoring: Live training metrics simulation
  - 🎨 Interactive Plots: Customizable visualization playground

### 2. Data Loader (`data_loader.py`)
- **Purpose**: Data ingestion and preprocessing pipeline
- **Key Features**:
  - Folder-based class loading (each folder = one class)
  - CSV file processing with intensity column extraction
  - Data augmentation with Gaussian noise
  - MinMaxScaler normalization
  - LabelBinarizer for categorical encoding

### 3. Model Trainer (`model_trainer.py`)
- **Purpose**: Neural network architecture and training logic
- **Architecture**: ResNet-like with residual blocks
- **Key Features**:
  - Dense layers with residual connections
  - Batch normalization and dropout for regularization
  - L2 regularization to prevent overfitting
  - Cosine decay learning rate scheduling
  - Early stopping and model checkpointing

### 4. Visualizations (`visualizations.py`)
- **Purpose**: Advanced interactive plotting and data visualization
- **Technology**: Plotly for interactive charts with comprehensive analytics
- **Features**:
  - Detailed learning curves with milestone annotations
  - ROC and precision-recall curves for multi-class classification
  - t-SNE and PCA dimensionality reduction visualizations
  - Error analysis with confidence distribution plots
  - Model performance radar charts
  - Feature distribution analysis
  - Multi-subplot layouts for comprehensive analysis

### 5. Actual Training Data Integration (`actual_training_data.py`)
- **Purpose**: Parse and structure actual 72-epoch training results
- **Key Metrics**: 95.83% final accuracy, best loss at epoch 44
- **Training Phases**: 
  - Initial learning (epochs 1-16): 60.16% → 95.83% accuracy
  - Convergence (epoch 17): Target accuracy achieved
  - Optimization (epochs 17-44): Loss fine-tuning
  - Plateau (epochs 45-72): Stable performance maintenance

### 6. Demo Data Generator (`demo_data_generator.py`)
- **Purpose**: Generate realistic demonstration data for dashboard testing
- **Capabilities**: Synthetic spectral data, realistic predictions, sample datasets
- **Integration**: Uses actual training metrics for authentic visualization

## Data Flow

1. **Data Loading**: CSV files are loaded from organized folder structure
2. **Preprocessing**: Data is normalized using MinMaxScaler and labels are binarized
3. **Augmentation**: Optional noise-based data augmentation for better generalization
4. **Model Building**: ResNet-like architecture is constructed with residual blocks
5. **Training**: Model is trained with advanced callbacks and monitoring
6. **Evaluation**: Performance metrics and visualizations are generated
7. **Prediction**: New data can be classified using the trained model

## External Dependencies

### Core ML Libraries
- **TensorFlow/Keras**: Deep learning framework for model building and training
- **Scikit-learn**: Data preprocessing, metrics, and evaluation utilities
- **NumPy/Pandas**: Data manipulation and numerical operations

### Visualization & UI
- **Streamlit**: Web application framework
- **Plotly**: Interactive plotting library
- **Matplotlib/Seaborn**: Additional plotting capabilities

### Data Processing
- **Zipfile**: Archive extraction for data loading
- **OS**: File system operations

## Deployment Strategy

The application is designed for deployment on Replit with the following considerations:

1. **Session State Management**: Uses Streamlit's session state to maintain model and data across page changes
2. **File Structure**: Expects data in organized folder structure with CSV files
3. **Memory Efficiency**: Uses data augmentation and preprocessing pipelines to handle large datasets
4. **Interactive Interface**: Multi-page Streamlit app with sidebar navigation

### Model Architecture Details

The ResNet-like architecture includes:
- **Input Layer**: Accepts variable-length intensity data
- **Initial Dense Layer**: 256 units with ReLU activation
- **Residual Blocks**: Two blocks with skip connections for gradient flow
- **Regularization**: Batch normalization, dropout, and L2 regularization
- **Output Layer**: Softmax for multi-class classification

### Training Configuration

- **Optimizer**: Adam with cosine decay learning rate
- **Callbacks**: Early stopping and model checkpointing
- **Class Balancing**: Computed class weights for imbalanced datasets
- **Validation Split**: Train/validation/test splits for proper evaluation

## Recent Changes (January 2025)

### Enhanced Dashboard Implementation
- ✓ Created comprehensive 7-section visualization dashboard
- ✓ Integrated actual 72-epoch training data with 95.83% accuracy
- ✓ Added 15+ types of interactive plots and visualizations
- ✓ Implemented training phase analysis with milestone markers
- ✓ Built advanced analytics including error analysis and confidence distributions
- ✓ Added t-SNE and PCA visualizations for data exploration
- ✓ Created interactive visualization playground with customizable plots
- ✓ Integrated real-time monitoring simulation

### Key Achievements
- **Authentic Data Integration**: Uses actual training results instead of synthetic data
- **Comprehensive Analysis**: Covers all aspects of model performance evaluation
- **Interactive Features**: Fully interactive plots with real-time updates
- **Professional Presentation**: Production-ready dashboard for model analysis

The application now provides a complete visualization suite for deep learning model analysis with emphasis on authentic data presentation and comprehensive performance evaluation through the enhanced Streamlit interface.