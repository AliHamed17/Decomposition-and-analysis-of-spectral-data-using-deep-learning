import zipfile
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_class_weight
from sklearn.preprocessing import LabelBinarizer, MinMaxScaler

class DataLoader:
    def __init__(self):
        self.scaler = MinMaxScaler()
        self.encoder = LabelBinarizer()
    
    def load_data_from_folders(self, base_path):
        """Load data from folder structure where each folder represents a class"""
        X, y = [], []
        
        # Get all folders in the base path
        folders = sorted([f for f in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, f))])
        
        for folder in folders:
            folder_path = os.path.join(base_path, folder)
            
            # Get all CSV files in the folder
            csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
            
            for fname in sorted(csv_files):
                file_path = os.path.join(folder_path, fname)
                df = pd.read_csv(file_path)
                
                # Extract intensity column or use second column if 'intensity' not found
                if 'intensity' in df.columns:
                    intensity = df['intensity'].values
                else:
                    intensity = df.iloc[:, 1].values if df.shape[1] > 1 else df.iloc[:, 0].values
                
                X.append(intensity)
                y.append(folder)
        
        return np.array(X), np.array(y)
    
    def augment_data(self, X, y, std=0.02):
        """Apply data augmentation by adding noise"""
        noise = np.random.normal(0, std, X.shape)
        X_augmented = np.clip(X + noise, 0, 1)
        
        # Combine original and augmented data
        X_combined = np.vstack([X, X_augmented])
        y_combined = np.vstack([y, y])
        
        return X_combined, y_combined
    
    def load_and_preprocess(self, zip_path):
        """Complete data loading and preprocessing pipeline"""
        # Extract ZIP file
        extract_path = "temp_extract"
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
        
        # Find the data directory (usually the first subdirectory)
        extracted_items = os.listdir(extract_path)
        data_path = None
        
        for item in extracted_items:
            item_path = os.path.join(extract_path, item)
            if os.path.isdir(item_path):
                data_path = item_path
                break
        
        if data_path is None:
            data_path = extract_path
        
        # Load raw data
        X_raw, y_raw = self.load_data_from_folders(data_path)
        
        # Preprocess features
        X_scaled = self.scaler.fit_transform(X_raw)
        
        # Encode labels
        y_encoded = self.encoder.fit_transform(y_raw)
        
        # Apply data augmentation
        X_all, y_all = self.augment_data(X_scaled, y_encoded)
        
        # Split data
        X_train, X_temp, y_train, y_temp = train_test_split(
            X_all, y_all, test_size=0.2, 
            stratify=y_all.argmax(1), random_state=42
        )
        
        X_val, X_test, y_val, y_test = train_test_split(
            X_temp, y_temp, test_size=0.5, 
            stratify=y_temp.argmax(1), random_state=42
        )
        
        # Compute class weights
        weights = compute_class_weight(
            class_weight='balanced', 
            classes=np.unique(np.argmax(y_train, axis=1)), 
            y=np.argmax(y_train, axis=1)
        )
        class_weights = {i: w for i, w in enumerate(weights)}
        
        # Clean up temporary files
        import shutil
        shutil.rmtree(extract_path)
        
        return X_train, X_val, X_test, y_train, y_val, y_test, self.encoder, self.scaler, class_weights
