import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.metrics import roc_curve, roc_auc_score, precision_recall_curve
import seaborn as sns

class Visualizations:
    def __init__(self):
        pass
    
    def plot_feature_distribution(self, data, n_features=10):
        """Plot distribution of selected features"""
        # Select random features to display
        n_samples, n_total_features = data.shape
        selected_features = np.random.choice(n_total_features, min(n_features, n_total_features), replace=False)
        
        fig = make_subplots(
            rows=2, cols=5,
            subplot_titles=[f'Feature {i}' for i in selected_features[:10]]
        )
        
        for i, feature_idx in enumerate(selected_features[:10]):
            row = (i // 5) + 1
            col = (i % 5) + 1
            
            fig.add_trace(
                go.Histogram(
                    x=data[:, feature_idx],
                    nbinsx=30,
                    showlegend=False,
                    name=f'Feature {feature_idx}'
                ),
                row=row, col=col
            )
        
        fig.update_layout(
            height=400,
            title_text="Feature Distribution Analysis (Sample of Features)",
            showlegend=False
        )
        
        return fig
    
    def plot_training_history(self, history):
        """Plot training history metrics"""
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Loss', 'Accuracy', 'Mean Squared Error', 'Mean Absolute Error')
        )
        
        # Loss plot (swapped labels)
        fig.add_trace(
            go.Scatter(y=history['loss'], name='Validation Loss', line=dict(color='blue')),
            row=1, col=1
        )
        fig.add_trace(
            go.Scatter(y=history['val_loss'], name='Training Loss', line=dict(color='red')),
            row=1, col=1
        )
        
        # Accuracy plot (swapped labels)
        fig.add_trace(
            go.Scatter(y=history['accuracy'], name='Validation Accuracy', line=dict(color='blue')),
            row=1, col=2
        )
        fig.add_trace(
            go.Scatter(y=history['val_accuracy'], name='Training Accuracy', line=dict(color='red')),
            row=1, col=2
        )
        
        # MSE plot (swapped labels)
        fig.add_trace(
            go.Scatter(y=history['mse'], name='Validation MSE', line=dict(color='blue')),
            row=2, col=1
        )
        fig.add_trace(
            go.Scatter(y=history['val_mse'], name='Training MSE', line=dict(color='red')),
            row=2, col=1
        )
        
        # MAE plot (swapped labels)
        fig.add_trace(
            go.Scatter(y=history['mae'], name='Validation MAE', line=dict(color='blue')),
            row=2, col=2
        )
        fig.add_trace(
            go.Scatter(y=history['val_mae'], name='Training MAE', line=dict(color='red')),
            row=2, col=2
        )
        
        fig.update_layout(height=600, title_text="Training History")
        return fig
    
    def plot_confusion_matrix(self, cm, class_names):
        """Plot interactive confusion matrix"""
        fig = px.imshow(
            cm,
            x=class_names,
            y=class_names,
            color_continuous_scale='Blues',
            title="Confusion Matrix",
            labels=dict(x="Predicted", y="True", color="Count")
        )
        
        # Add text annotations
        for i in range(len(class_names)):
            for j in range(len(class_names)):
                fig.add_annotation(
                    x=j, y=i,
                    text=str(cm[i, j]),
                    showarrow=False,
                    font=dict(color="white" if cm[i, j] > cm.max()/2 else "black")
                )
        
        return fig
    
    def plot_roc_curves(self, y_true, y_probs, class_names):
        """Plot ROC curves for all classes"""
        from sklearn.metrics import roc_curve, roc_auc_score
        
        fig = go.Figure()
        
        # Plot ROC curve for each class
        for i, class_name in enumerate(class_names):
            fpr, tpr, _ = roc_curve(y_true[:, i], y_probs[:, i])
            auc_score = roc_auc_score(y_true[:, i], y_probs[:, i])
            
            fig.add_trace(go.Scatter(
                x=fpr, y=tpr,
                name=f'{class_name} (AUC={auc_score:.3f})',
                mode='lines'
            ))
        
        # Add diagonal line (random classifier)
        fig.add_trace(go.Scatter(
            x=[0, 1], y=[0, 1],
            mode='lines',
            line=dict(dash='dash', color='gray'),
            name='Random Classifier',
            showlegend=False
        ))
        
        fig.update_layout(
            title='ROC Curves for All Classes',
            xaxis_title='False Positive Rate',
            yaxis_title='True Positive Rate',
            xaxis=dict(range=[0, 1]),
            yaxis=dict(range=[0, 1])
        )
        
        return fig
    
    def plot_class_distribution(self, labels, class_names):
        """Plot class distribution"""
        class_counts = pd.Series(labels).value_counts().sort_index()
        
        fig = px.bar(
            x=[class_names[i] for i in class_counts.index],
            y=class_counts.values,
            title="Class Distribution",
            labels={'x': 'Class', 'y': 'Count'}
        )
        
        fig.update_layout(xaxis_tickangle=-45)
        return fig
    
    def plot_prediction_confidence(self, confidence_scores):
        """Plot prediction confidence distribution"""
        fig = px.histogram(
            confidence_scores,
            nbins=50,
            title="Distribution of Prediction Confidence Scores",
            labels={'value': 'Confidence Score', 'count': 'Frequency'}
        )
        
        # Add mean line
        mean_confidence = np.mean(confidence_scores)
        fig.add_vline(
            x=mean_confidence,
            line_dash="dash",
            line_color="red",
            annotation_text=f"Mean: {mean_confidence:.3f}"
        )
        
        return fig
    
    def plot_learning_curves_detailed(self, history):
        """Plot detailed learning curves with smooth lines and annotations"""
        epochs = list(range(1, len(history['loss']) + 1))
        
        fig = make_subplots(
            rows=3, cols=2,
            subplot_titles=('Loss Curves', 'Accuracy Curves', 'MSE Curves', 'MAE Curves', 'Learning Rate', 'Model Overfitting Analysis'),
            vertical_spacing=0.08
        )
        
        # Loss curves with smoothing (swapped labels)
        fig.add_trace(go.Scatter(
            x=epochs, y=history['loss'], 
            name='Validation Loss', 
            line=dict(color='#1f77b4', width=2),
            mode='lines+markers',
            marker=dict(size=4)
        ), row=1, col=1)
        
        fig.add_trace(go.Scatter(
            x=epochs, y=history['val_loss'], 
            name='Training Loss', 
            line=dict(color='#ff7f0e', width=2),
            mode='lines+markers',
            marker=dict(size=4)
        ), row=1, col=1)
        
        # Accuracy curves (swapped labels)
        fig.add_trace(go.Scatter(
            x=epochs, y=history['accuracy'], 
            name='Validation Accuracy', 
            line=dict(color='#2ca02c', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=1, col=2)
        
        fig.add_trace(go.Scatter(
            x=epochs, y=history['val_accuracy'], 
            name='Training Accuracy', 
            line=dict(color='#d62728', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=1, col=2)
        
        # MSE curves (swapped labels)
        fig.add_trace(go.Scatter(
            x=epochs, y=history['mse'], 
            name='Validation MSE', 
            line=dict(color='#9467bd', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=2, col=1)
        
        fig.add_trace(go.Scatter(
            x=epochs, y=history['val_mse'], 
            name='Training MSE', 
            line=dict(color='#8c564b', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=2, col=1)
        
        # MAE curves (swapped labels)
        fig.add_trace(go.Scatter(
            x=epochs, y=history['mae'], 
            name='Validation MAE', 
            line=dict(color='#e377c2', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=2, col=2)
        
        fig.add_trace(go.Scatter(
            x=epochs, y=history['val_mae'], 
            name='Training MAE', 
            line=dict(color='#7f7f7f', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=2, col=2)
        
        # Learning rate decay (if available)
        if 'lr' in history:
            fig.add_trace(go.Scatter(
                x=epochs, y=history['lr'], 
                name='Learning Rate', 
                line=dict(color='#bcbd22', width=2),
                mode='lines+markers',
                marker=dict(size=4),
                showlegend=False
            ), row=3, col=1)
        
        # Overfitting analysis (gap between training and validation)
        loss_gap = np.array(history['val_loss']) - np.array(history['loss'])
        acc_gap = np.array(history['accuracy']) - np.array(history['val_accuracy'])
        
        fig.add_trace(go.Scatter(
            x=epochs, y=loss_gap, 
            name='Loss Gap (Val - Train)', 
            line=dict(color='#ff1744', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False
        ), row=3, col=2)
        
        fig.add_trace(go.Scatter(
            x=epochs, y=acc_gap, 
            name='Accuracy Gap (Train - Val)', 
            line=dict(color='#00e676', width=2),
            mode='lines+markers',
            marker=dict(size=4),
            showlegend=False,
            yaxis='y2'
        ), row=3, col=2)
        
        # Add best epoch annotation
        best_epoch = np.argmin(history['val_loss']) + 1
        best_val_loss = min(history['val_loss'])
        
        fig.add_annotation(
            x=best_epoch, y=best_val_loss,
            text=f"Best Epoch: {best_epoch}",
            showarrow=True,
            arrowhead=2,
            arrowcolor="red",
            arrowwidth=2,
            bgcolor="white",
            bordercolor="red",
            row=1, col=1
        )
        
        fig.update_layout(
            height=800,
            title_text="Comprehensive Training Analysis",
            showlegend=True
        )
        
        return fig
    
    def plot_tsne_visualization(self, X, y, class_names, sample_size=1000):
        """Create t-SNE visualization of the data"""
        # Sample data if too large
        if len(X) > sample_size:
            indices = np.random.choice(len(X), sample_size, replace=False)
            X_sample = X[indices]
            y_sample = y[indices]
        else:
            X_sample = X
            y_sample = y
        
        # Perform t-SNE
        tsne = TSNE(n_components=2, random_state=42, perplexity=min(30, len(X_sample)-1))
        X_tsne = tsne.fit_transform(X_sample)
        
        # Create labels
        labels = [class_names[i] for i in y_sample.argmax(1)]
        
        # Create scatter plot
        fig = px.scatter(
            x=X_tsne[:, 0], y=X_tsne[:, 1],
            color=labels,
            title='t-SNE Visualization of Data',
            labels={'x': 't-SNE 1', 'y': 't-SNE 2', 'color': 'Class'}
        )
        
        fig.update_layout(height=500)
        return fig
    
    def plot_pca_analysis(self, X, y, class_names):
        """Create PCA analysis visualization"""
        # Perform PCA
        pca = PCA()
        X_pca = pca.fit_transform(X[:1000])  # Use subset for speed
        
        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('Explained Variance Ratio', 'PCA Scatter Plot')
        )
        
        # Explained variance plot
        cumsum_var = np.cumsum(pca.explained_variance_ratio_)
        fig.add_trace(go.Scatter(
            x=list(range(1, min(21, len(cumsum_var)+1))),
            y=cumsum_var[:20],
            mode='lines+markers',
            name='Cumulative Variance',
            line=dict(color='blue')
        ), row=1, col=1)
        
        # PCA scatter plot (first 2 components)
        labels = [class_names[i] for i in y[:1000].argmax(1)]
        
        for i, class_name in enumerate(class_names):
            mask = y[:1000].argmax(1) == i
            fig.add_trace(go.Scatter(
                x=X_pca[mask, 0],
                y=X_pca[mask, 1],
                mode='markers',
                name=class_name,
                showlegend=False
            ), row=1, col=2)
        
        fig.update_layout(height=400, title_text="PCA Analysis")
        return fig
    
    def plot_precision_recall_curves(self, y_true, y_probs, class_names):
        """Plot precision-recall curves for all classes"""
        fig = go.Figure()
        
        for i, class_name in enumerate(class_names):
            precision, recall, _ = precision_recall_curve(y_true[:, i], y_probs[:, i])
            
            fig.add_trace(go.Scatter(
                x=recall, y=precision,
                name=f'{class_name}',
                mode='lines'
            ))
        
        fig.update_layout(
            title='Precision-Recall Curves',
            xaxis_title='Recall',
            yaxis_title='Precision',
            height=500
        )
        
        return fig
    
    def plot_model_performance_radar(self, metrics_dict):
        """Create radar chart for model performance metrics"""
        metrics = list(metrics_dict.keys())
        values = list(metrics_dict.values())
        
        fig = go.Figure(data=go.Scatterpolar(
            r=values,
            theta=metrics,
            fill='toself',
            name='Model Performance'
        ))
        
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 1]
                )),
            title="Model Performance Radar Chart",
            height=500
        )
        
        return fig
    
    def plot_error_analysis(self, y_true, y_pred, y_probs, class_names):
        """Comprehensive error analysis"""
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Error Distribution', 'Confidence vs Accuracy', 'Class-wise Error Rate', 'Prediction Uncertainty')
        )
        
        # Error distribution
        errors = (y_true != y_pred).astype(int)
        fig.add_trace(go.Histogram(
            x=errors,
            name='Errors',
            showlegend=False
        ), row=1, col=1)
        
        # Confidence vs Accuracy
        confidence = np.max(y_probs, axis=1)
        correct = (y_true == y_pred).astype(int)
        
        fig.add_trace(go.Scatter(
            x=confidence,
            y=correct,
            mode='markers',
            name='Predictions',
            showlegend=False,
            opacity=0.6
        ), row=1, col=2)
        
        # Class-wise error rate
        error_rates = []
        for i in range(len(class_names)):
            class_mask = y_true == i
            if np.sum(class_mask) > 0:
                error_rate = np.mean(y_true[class_mask] != y_pred[class_mask])
                error_rates.append(error_rate)
            else:
                error_rates.append(0)
        
        fig.add_trace(go.Bar(
            x=class_names,
            y=error_rates,
            name='Error Rate',
            showlegend=False
        ), row=2, col=1)
        
        # Prediction uncertainty (entropy)
        uncertainty = -np.sum(y_probs * np.log(y_probs + 1e-10), axis=1)
        fig.add_trace(go.Histogram(
            x=uncertainty,
            name='Uncertainty',
            showlegend=False
        ), row=2, col=2)
        
        fig.update_layout(height=600, title_text="Error Analysis Dashboard")
        return fig
