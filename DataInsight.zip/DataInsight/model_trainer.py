import tensorflow as tf
from tensorflow.keras import Model, Input
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization, Add
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.optimizers.schedules import CosineDecay
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.regularizers import l2

class ModelTrainer:
    def __init__(self):
        self.model = None
    
    def residual_block(self, x, units, dropout_rate=0.2):
        """Create a residual block"""
        shortcut = x
        
        # First dense layer
        x = Dense(units, activation='relu', kernel_regularizer=l2(1e-4))(x)
        x = BatchNormalization()(x)
        x = Dropout(dropout_rate)(x)
        
        # Second dense layer
        x = Dense(units, activation='relu', kernel_regularizer=l2(1e-4))(x)
        x = BatchNormalization()(x)
        
        # Add residual connection
        x = Add()([x, shortcut])
        
        return x
    
    def build_model(self, input_shape, num_classes):
        """Build ResNet-like model architecture"""
        # Input layer
        input_layer = Input(shape=(input_shape,))
        
        # Initial dense layer
        x = Dense(256, activation='relu', kernel_regularizer=l2(1e-4))(input_layer)
        x = BatchNormalization()(x)
        x = Dropout(0.2)(x)
        
        # Residual blocks
        x = self.residual_block(x, 256)
        x = self.residual_block(x, 256)
        
        # Additional dense layer
        x = Dense(128, activation='relu', kernel_regularizer=l2(1e-4))(x)
        x = BatchNormalization()(x)
        x = Dropout(0.2)(x)
        
        # Output layer
        output_layer = Dense(num_classes, activation='softmax')(x)
        
        # Create model
        model = Model(inputs=input_layer, outputs=output_layer)
        
        return model
    
    def train_model(self, X_train, y_train, X_val, y_val, class_weights, 
                   epochs=100, batch_size=32, learning_rate=0.001):
        """Train the model"""
        # Build model
        input_shape = X_train.shape[1]
        num_classes = y_train.shape[1]
        self.model = self.build_model(input_shape, num_classes)
        
        # Compile model
        self.model.compile(
            optimizer=Adam(learning_rate=CosineDecay(
                initial_learning_rate=learning_rate, 
                decay_steps=500, 
                alpha=1e-5
            )),
            loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.05),
            metrics=[
                'accuracy', 
                tf.keras.metrics.MeanSquaredError(name="mse"), 
                tf.keras.metrics.MeanAbsoluteError(name="mae")
            ]
        )
        
        # Define callbacks
        early_stop = EarlyStopping(
            monitor="val_loss", 
            patience=25, 
            restore_best_weights=True, 
            min_delta=1e-4
        )
        
        checkpoint = ModelCheckpoint(
            "best_model_resnet.keras", 
            save_best_only=True, 
            monitor="val_accuracy", 
            mode="max"
        )
        
        # Train model
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=epochs,
            batch_size=batch_size,
            class_weight=class_weights,
            callbacks=[early_stop, checkpoint],
            verbose=0  # Silent training for Streamlit
        )
        
        return self.model, history
