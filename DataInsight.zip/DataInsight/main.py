# Main entry point for deployment
# This ensures the enhanced dashboard is used for deployment

import subprocess
import sys
import os

# Set the main app to be the enhanced version
os.environ['STREAMLIT_APP'] = 'app_enhanced.py'

if __name__ == "__main__":
    # Run the enhanced dashboard
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", 
        "app_enhanced.py", 
        "--server.port=5000",
        "--server.address=0.0.0.0",
        "--server.headless=true"
    ])