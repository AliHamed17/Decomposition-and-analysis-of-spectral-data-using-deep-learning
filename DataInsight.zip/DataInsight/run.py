#!/usr/bin/env python3
"""
Deployment entry point for the Enhanced Spectral Analysis Dashboard
This ensures the enhanced dashboard is always served for deployment
"""

import subprocess
import sys
import os

def main():
    """Run the enhanced dashboard"""
    print("🔬 Starting Enhanced Spectral Analysis Dashboard...")
    
    # Set environment variables for consistency
    os.environ['STREAMLIT_SERVER_PORT'] = '5000'
    os.environ['STREAMLIT_SERVER_ADDRESS'] = '0.0.0.0'
    os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
    
    # Run the enhanced dashboard
    cmd = [
        sys.executable, 
        "-m", "streamlit", 
        "run", 
        "app_enhanced.py",
        "--server.port=5000",
        "--server.address=0.0.0.0", 
        "--server.headless=true"
    ]
    
    print(f"Executing: {' '.join(cmd)}")
    subprocess.run(cmd)

if __name__ == "__main__":
    main()