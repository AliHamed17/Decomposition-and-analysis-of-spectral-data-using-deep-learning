# Spectral Data Analyzer - Project Overview

## Overview

This is a Streamlit-based web application for analyzing and visualizing spectral data across multiple contamination stages. The application allows users to upload spectral data files, explore interactive visualizations, and perform statistical analysis to gain insights from the data.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular architecture with clear separation of concerns:

1. **Frontend**: Streamlit web interface that provides interactive components for data upload, visualization selection, and analysis tools.

2. **Data Processing Layer**: Handles data extraction, organization, and preprocessing from CSV files.

3. **Visualization Layer**: Generates various plots and visualizations using matplotlib, seaborn, and plotly.

4. **Statistical Analysis Layer**: Performs calculations on spectral data to extract meaningful insights.

5. **Utilities**: Provides helper functions for common tasks across the application.

## Key Components

### 1. Main Application (`app.py`)
- Entry point for the Streamlit application
- Manages the UI layout and user interactions
- Coordinates between data processing, visualization, and analysis modules
- Manages session state to preserve data between interactions

### 2. Data Processor (`data_processor.py`)
- Handles extraction and parsing of CSV data files
- Organizes data by contamination stages and file numbers
- Performs data cleaning and preprocessing

### 3. Visualization (`visualization.py`)
- Generates various visualization types:
  - Single spectrum plots
  - Zoomed spectrum views
  - Multi-spectra comparison plots
  - Heatmaps
  - 3D surface plots
- Uses matplotlib, seaborn, and plotly for different visualization needs

### 4. Statistics (`statistics.py`)
- Calculates statistical measures from spectral data
- Provides summary statistics for each file and stage
- Includes functions for min, max, mean, median, and standard deviation calculations

### 5. Utilities (`utils.py`)
- Provides helper functions used across the application
- Handles figure downloads and exports
- Performs data normalization
- Calculates wavelength ranges

## Data Flow

1. **Data Ingestion**: 
   - User uploads CSV files through the Streamlit interface
   - Files are organized by contamination stages

2. **Data Processing**:
   - CSV files are parsed and converted to pandas DataFrames
   - Data is cleaned (handling missing values, converting to numeric types)
   - Organized into a structured format by stage and file number

3. **Analysis and Visualization**:
   - User selects visualization types and parameters
   - Application generates the requested visualizations
   - Statistical analysis is performed on selected data subsets

4. **Output**:
   - Interactive visualizations displayed in the web interface
   - Option to download plots and analysis results

## External Dependencies

The application relies on the following key libraries:

1. **Streamlit**: Powers the interactive web interface
2. **Pandas & NumPy**: For data manipulation and numerical operations
3. **Matplotlib & Seaborn**: For static visualizations
4. **Plotly**: For interactive visualizations
5. **Python Standard Library**: For file operations and utility functions

## Deployment Strategy

The application is configured to run as a Streamlit web service:

1. **Runtime Environment**: Python 3.11 with specific packages installed via pip
2. **Server Configuration**:
   - Streamlit runs on port 5000
   - Configured for headless operation (no browser auto-launch)
   - Binds to all network interfaces (0.0.0.0)
   
3. **Deployment Target**: Configured for autoscaling deployment

4. **Workflow Configuration**:
   - Project workflow runs the server task in parallel
   - Server task installs required dependencies and starts the Streamlit server

## Development Guidelines

1. **Adding New Features**:
   - Maintain the modular structure
   - Add new visualization types to the visualization.py module
   - Add new analysis methods to the statistics.py module

2. **UI Enhancements**:
   - Use Streamlit's widgets for interactive elements
   - Keep the main app.py file focused on UI organization
   - Implement complex logic in the appropriate module

3. **Data Handling**:
   - Use session state to persist data between interactions
   - Implement proper error handling for file uploads and data processing

4. **Performance Considerations**:
   - Use caching for computationally intensive operations
   - Consider lazy loading for large datasets

## Recent Changes: Latest modifications with dates

### July 27, 2025 - File Upload Functionality Fixed
- Fixed HTTP 400 errors in file upload system
- Enhanced ZIP file processing with robust directory detection
- Improved data_processor.py to handle both DataFrame and NPZ formats
- Added file size validation (100MB for ZIP, 50MB for NPZ)
- Implemented better error handling and user feedback
- Successfully tested with user's realData_final_project.zip containing 4 stages (0-3) with 120 files each