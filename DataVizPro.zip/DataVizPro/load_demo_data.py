#!/usr/bin/env python3
"""
Load demo data from the attached assets to demonstrate all features
"""
import streamlit as st
import numpy as np
import pandas as pd
from data_processor import DataProcessor
import os

def load_demo_data():
    """Load the existing extracted data from attached assets"""
    
    # Check if we have the extracted data file
    demo_file = "attached_assets/extracted_data.npz"
    
    if os.path.exists(demo_file):
        st.info("Loading demonstration data from attached assets...")
        
        # Load the NPZ data
        try:
            data = np.load(demo_file, allow_pickle=True)
            
            # Extract the organized data
            organized_data = data['organized_data'].item()
            
            # Store in session state
            st.session_state.data = data
            st.session_state.organized_data = organized_data
            st.session_state.stages = list(organized_data.keys())
            st.session_state.file_numbers = {
                stage: list(organized_data[stage].keys()) 
                for stage in organized_data.keys()
            }
            st.session_state.current_stage = st.session_state.stages[0]
            st.session_state.current_file = st.session_state.file_numbers[st.session_state.current_stage][0]
            
            st.success(f"✅ Demo data loaded successfully!")
            st.info(f"Loaded {len(st.session_state.stages)} stages with {sum(len(files) for files in st.session_state.file_numbers.values())} total spectral files")
            
            return True
            
        except Exception as e:
            st.error(f"Error loading demo data: {str(e)}")
            return False
    else:
        st.warning("Demo data file not found. Please upload your data using the file uploader.")
        return False

if __name__ == "__main__":
    load_demo_data()