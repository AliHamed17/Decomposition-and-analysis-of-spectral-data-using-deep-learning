import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import signal
from scipy.optimize import curve_fit
from scipy.integrate import simpson
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class SpectralPeakAnalyzer:
    def __init__(self):
        self.peak_data = {}
        self.peak_statistics = {}
        self.peak_trends = {}
        
    def detect_peaks(self, wavelength, intensity, prominence=0.1, width=2, height=None, distance=5):
        """
        Detect peaks in a spectrum using scipy's find_peaks
        
        Parameters:
        - prominence: Required prominence of peaks
        - width: Required width of peaks in samples
        - height: Required height of peaks
        - distance: Minimum distance between peaks in samples
        """
        # Find peaks
        peaks, properties = signal.find_peaks(
            intensity,
            prominence=prominence,
            width=width,
            height=height,
            distance=distance
        )
        
        # Extract peak information
        peak_info = {
            'indices': peaks,
            'wavelengths': wavelength[peaks],
            'intensities': intensity[peaks],
            'prominences': properties.get('prominences', np.array([])),
            'widths': properties.get('widths', np.array([])),
            'left_bases': properties.get('left_bases', np.array([])),
            'right_bases': properties.get('right_bases', np.array([])),
            'width_heights': properties.get('width_heights', np.array([]))
        }
        
        return peak_info
    
    def calculate_peak_properties(self, wavelength, intensity, peak_info):
        """
        Calculate detailed properties for detected peaks
        """
        peaks = peak_info['indices']
        peak_wavelengths = peak_info['wavelengths']
        peak_intensities = peak_info['intensities']
        
        properties = []
        
        for i, peak_idx in enumerate(peaks):
            # Basic properties
            peak_wav = peak_wavelengths[i]
            peak_int = peak_intensities[i]
            
            # Calculate FWHM (Full Width at Half Maximum)
            half_max = peak_int / 2
            
            # Find left and right indices where intensity drops to half maximum
            left_idx = peak_idx
            right_idx = peak_idx
            
            # Search left
            for j in range(peak_idx, -1, -1):
                if intensity[j] <= half_max:
                    left_idx = j
                    break
            
            # Search right
            for j in range(peak_idx, len(intensity)):
                if intensity[j] <= half_max:
                    right_idx = j
                    break
            
            fwhm = wavelength[right_idx] - wavelength[left_idx]
            
            # Calculate peak area (using Simpson's integration)
            if left_idx < right_idx:
                peak_area = simpson(intensity[left_idx:right_idx+1], wavelength[left_idx:right_idx+1])
            else:
                peak_area = 0
            
            # Calculate asymmetry
            left_width = peak_wav - wavelength[left_idx]
            right_width = wavelength[right_idx] - peak_wav
            asymmetry = (right_width - left_width) / (right_width + left_width) if (right_width + left_width) > 0 else 0
            
            # Signal-to-noise ratio estimate
            # Use local baseline as noise estimate
            baseline_start = max(0, left_idx - 10)
            baseline_end = min(len(intensity), right_idx + 10)
            baseline_region = np.concatenate([
                intensity[baseline_start:left_idx],
                intensity[right_idx:baseline_end]
            ])
            noise_level = np.std(baseline_region) if len(baseline_region) > 0 else 1
            snr = peak_int / noise_level if noise_level > 0 else peak_int
            
            # Peak sharpness (second derivative at peak)
            if 1 <= peak_idx < len(intensity) - 1:
                sharpness = intensity[peak_idx-1] - 2*intensity[peak_idx] + intensity[peak_idx+1]
            else:
                sharpness = 0
            
            properties.append({
                'peak_index': peak_idx,
                'wavelength': peak_wav,
                'intensity': peak_int,
                'fwhm': fwhm,
                'area': peak_area,
                'asymmetry': asymmetry,
                'snr': snr,
                'sharpness': abs(sharpness),
                'left_base': wavelength[left_idx],
                'right_base': wavelength[right_idx],
                'prominence': peak_info['prominences'][i] if i < len(peak_info['prominences']) else 0
            })
        
        return pd.DataFrame(properties)
    
    def analyze_spectrum_peaks(self, wavelength, intensity, spectrum_id, prominence=0.1, width=2):
        """
        Complete peak analysis for a single spectrum
        """
        # Detect peaks
        peak_info = self.detect_peaks(wavelength, intensity, prominence=prominence, width=width)
        
        # Calculate properties
        if len(peak_info['indices']) > 0:
            properties_df = self.calculate_peak_properties(wavelength, intensity, peak_info)
            
            # Store results
            self.peak_data[spectrum_id] = {
                'peak_info': peak_info,
                'properties': properties_df,
                'wavelength': wavelength,
                'intensity': intensity
            }
            
            return properties_df
        else:
            # No peaks found
            empty_df = pd.DataFrame(columns=[
                'peak_index', 'wavelength', 'intensity', 'fwhm', 'area', 
                'asymmetry', 'snr', 'sharpness', 'left_base', 'right_base', 'prominence'
            ])
            
            self.peak_data[spectrum_id] = {
                'peak_info': peak_info,
                'properties': empty_df,
                'wavelength': wavelength,
                'intensity': intensity
            }
            
            return empty_df
    
    def analyze_stage_peaks(self, organized_data, stage, prominence=0.1, width=2):
        """
        Analyze peaks for all files in a stage
        """
        stage_results = {}
        
        if stage not in organized_data:
            return stage_results
        
        for file_num, file_data in organized_data[stage].items():
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            spectrum_id = f"Stage_{stage}_File_{file_num}"
            
            properties_df = self.analyze_spectrum_peaks(
                wavelength, intensity, spectrum_id, prominence, width
            )
            
            stage_results[file_num] = properties_df
        
        return stage_results
    
    def compare_peaks_across_stages(self, organized_data, prominence=0.1, width=2):
        """
        Compare peaks across all stages
        """
        stage_peak_data = {}
        
        for stage in organized_data.keys():
            stage_results = self.analyze_stage_peaks(organized_data, stage, prominence, width)
            stage_peak_data[stage] = stage_results
        
        return stage_peak_data
    
    def calculate_stage_peak_statistics(self, stage_peak_data):
        """
        Calculate statistical summaries for peaks in each stage
        """
        stage_stats = {}
        
        for stage, stage_results in stage_peak_data.items():
            all_peaks = []
            
            # Combine all peaks from all files in the stage
            for file_num, properties_df in stage_results.items():
                if not properties_df.empty:
                    all_peaks.append(properties_df)
            
            if all_peaks:
                combined_peaks = pd.concat(all_peaks, ignore_index=True)
                
                # Calculate statistics
                stats = {
                    'total_peaks': len(combined_peaks),
                    'avg_peaks_per_file': len(combined_peaks) / len(stage_results),
                    'peak_wavelength_range': (combined_peaks['wavelength'].min(), combined_peaks['wavelength'].max()),
                    'avg_intensity': combined_peaks['intensity'].mean(),
                    'avg_fwhm': combined_peaks['fwhm'].mean(),
                    'avg_area': combined_peaks['area'].mean(),
                    'avg_prominence': combined_peaks['prominence'].mean(),
                    'avg_snr': combined_peaks['snr'].mean(),
                    'wavelength_std': combined_peaks['wavelength'].std(),
                    'intensity_std': combined_peaks['intensity'].std()
                }
                
                stage_stats[stage] = {
                    'statistics': stats,
                    'peak_data': combined_peaks
                }
            else:
                stage_stats[stage] = {
                    'statistics': {
                        'total_peaks': 0,
                        'avg_peaks_per_file': 0,
                        'peak_wavelength_range': (0, 0),
                        'avg_intensity': 0,
                        'avg_fwhm': 0,
                        'avg_area': 0,
                        'avg_prominence': 0,
                        'avg_snr': 0,
                        'wavelength_std': 0,
                        'intensity_std': 0
                    },
                    'peak_data': pd.DataFrame()
                }
        
        self.peak_statistics = stage_stats
        return stage_stats
    
    def identify_persistent_peaks(self, stage_peak_data, min_occurrence=0.7, wavelength_tolerance=2.0):
        """
        Identify peaks that appear consistently across files and stages
        """
        all_peak_wavelengths = []
        
        # Collect all peak wavelengths
        for stage, stage_results in stage_peak_data.items():
            for file_num, properties_df in stage_results.items():
                if not properties_df.empty:
                    all_peak_wavelengths.extend(properties_df['wavelength'].tolist())
        
        if not all_peak_wavelengths:
            return pd.DataFrame()
        
        # Cluster peaks by wavelength
        wavelengths_array = np.array(all_peak_wavelengths).reshape(-1, 1)
        clustering = DBSCAN(eps=wavelength_tolerance, min_samples=2).fit(wavelengths_array)
        
        # Analyze clusters
        persistent_peaks = []
        
        for cluster_id in set(clustering.labels_):
            if cluster_id == -1:  # Skip noise points
                continue
            
            cluster_wavelengths = wavelengths_array[clustering.labels_ == cluster_id].flatten()
            avg_wavelength = np.mean(cluster_wavelengths)
            
            # Count occurrences across stages and files
            total_files = sum(len(stage_results) for stage_results in stage_peak_data.values())
            occurrence_count = len(cluster_wavelengths)
            occurrence_rate = occurrence_count / total_files
            
            if occurrence_rate >= min_occurrence:
                persistent_peaks.append({
                    'avg_wavelength': avg_wavelength,
                    'wavelength_std': np.std(cluster_wavelengths),
                    'occurrence_count': occurrence_count,
                    'occurrence_rate': occurrence_rate,
                    'cluster_size': len(cluster_wavelengths)
                })
        
        return pd.DataFrame(persistent_peaks).sort_values('occurrence_rate', ascending=False)
    
    def track_peak_evolution(self, stage_peak_data, reference_peaks_df):
        """
        Track how peaks evolve across contamination stages
        """
        if reference_peaks_df.empty:
            return {}
        
        evolution_data = {}
        
        for _, ref_peak in reference_peaks_df.iterrows():
            ref_wavelength = ref_peak['avg_wavelength']
            wavelength_tolerance = 3.0
            
            peak_evolution = {}
            
            for stage in sorted(stage_peak_data.keys()):
                stage_results = stage_peak_data[stage]
                
                # Find peaks near reference wavelength in this stage
                stage_intensities = []
                stage_areas = []
                stage_fwhms = []
                
                for file_num, properties_df in stage_results.items():
                    if not properties_df.empty:
                        nearby_peaks = properties_df[
                            abs(properties_df['wavelength'] - ref_wavelength) <= wavelength_tolerance
                        ]
                        
                        if not nearby_peaks.empty:
                            # Take the closest peak
                            closest_peak = nearby_peaks.loc[
                                abs(nearby_peaks['wavelength'] - ref_wavelength).idxmin()
                            ]
                            
                            stage_intensities.append(closest_peak['intensity'])
                            stage_areas.append(closest_peak['area'])
                            stage_fwhms.append(closest_peak['fwhm'])
                
                # Calculate stage averages
                peak_evolution[stage] = {
                    'avg_intensity': np.mean(stage_intensities) if stage_intensities else 0,
                    'std_intensity': np.std(stage_intensities) if stage_intensities else 0,
                    'avg_area': np.mean(stage_areas) if stage_areas else 0,
                    'avg_fwhm': np.mean(stage_fwhms) if stage_fwhms else 0,
                    'detection_rate': len(stage_intensities) / len(stage_results) if stage_results else 0
                }
            
            evolution_data[ref_wavelength] = peak_evolution
        
        self.peak_trends = evolution_data
        return evolution_data
    
    def create_peak_detection_plot(self, wavelength, intensity, peak_info, title="Peak Detection"):
        """
        Create an interactive plot showing detected peaks
        """
        fig = go.Figure()
        
        # Add spectrum
        fig.add_trace(go.Scatter(
            x=wavelength,
            y=intensity,
            mode='lines',
            name='Spectrum',
            line=dict(color='blue', width=2)
        ))
        
        # Add detected peaks
        if len(peak_info['indices']) > 0:
            fig.add_trace(go.Scatter(
                x=peak_info['wavelengths'],
                y=peak_info['intensities'],
                mode='markers',
                name='Detected Peaks',
                marker=dict(
                    size=10,
                    color='red',
                    symbol='triangle-up'
                )
            ))
            
            # Add peak labels
            for i, (wav, intens) in enumerate(zip(peak_info['wavelengths'], peak_info['intensities'])):
                fig.add_annotation(
                    x=wav,
                    y=intens,
                    text=f'{wav:.1f}',
                    showarrow=True,
                    arrowhead=2,
                    arrowsize=1,
                    arrowwidth=1,
                    arrowcolor='red',
                    yshift=10
                )
        
        fig.update_layout(
            title=title,
            xaxis_title='Wavelength',
            yaxis_title='Intensity',
            showlegend=True
        )
        
        return fig
    
    def create_peak_comparison_plot(self, stage_peak_statistics):
        """
        Create comparison plots for peak statistics across stages
        """
        stages = sorted(stage_peak_statistics.keys())
        
        # Extract statistics
        total_peaks = [stage_peak_statistics[stage]['statistics']['total_peaks'] for stage in stages]
        avg_intensity = [stage_peak_statistics[stage]['statistics']['avg_intensity'] for stage in stages]
        avg_fwhm = [stage_peak_statistics[stage]['statistics']['avg_fwhm'] for stage in stages]
        avg_snr = [stage_peak_statistics[stage]['statistics']['avg_snr'] for stage in stages]
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=[
                'Total Peaks per Stage',
                'Average Peak Intensity',
                'Average Peak FWHM',
                'Average Signal-to-Noise Ratio'
            ]
        )
        
        # Total peaks
        fig.add_trace(go.Bar(
            x=[f'Stage {s}' for s in stages],
            y=total_peaks,
            name='Total Peaks',
            marker_color='lightblue'
        ), row=1, col=1)
        
        # Average intensity
        fig.add_trace(go.Scatter(
            x=[f'Stage {s}' for s in stages],
            y=avg_intensity,
            mode='lines+markers',
            name='Avg Intensity',
            line=dict(color='red', width=3),
            marker=dict(size=8)
        ), row=1, col=2)
        
        # Average FWHM
        fig.add_trace(go.Scatter(
            x=[f'Stage {s}' for s in stages],
            y=avg_fwhm,
            mode='lines+markers',
            name='Avg FWHM',
            line=dict(color='green', width=3),
            marker=dict(size=8)
        ), row=2, col=1)
        
        # Average SNR
        fig.add_trace(go.Scatter(
            x=[f'Stage {s}' for s in stages],
            y=avg_snr,
            mode='lines+markers',
            name='Avg SNR',
            line=dict(color='orange', width=3),
            marker=dict(size=8)
        ), row=2, col=2)
        
        fig.update_layout(
            title='Peak Statistics Comparison Across Stages',
            height=600,
            showlegend=False
        )
        
        return fig
    
    def create_peak_evolution_plot(self, peak_trends):
        """
        Create plot showing how peaks evolve across stages
        """
        if not peak_trends:
            return None
        
        fig = go.Figure()
        
        colors = px.colors.qualitative.Set1
        
        for i, (wavelength, evolution) in enumerate(peak_trends.items()):
            stages = sorted(evolution.keys())
            intensities = [evolution[stage]['avg_intensity'] for stage in stages]
            
            fig.add_trace(go.Scatter(
                x=[f'Stage {s}' for s in stages],
                y=intensities,
                mode='lines+markers',
                name=f'{wavelength:.1f} nm',
                line=dict(color=colors[i % len(colors)], width=2),
                marker=dict(size=8)
            ))
        
        fig.update_layout(
            title='Peak Intensity Evolution Across Stages',
            xaxis_title='Stage',
            yaxis_title='Average Intensity',
            showlegend=True
        )
        
        return fig
    
    def create_peak_heatmap(self, stage_peak_data):
        """
        Create heatmap showing peak distribution across wavelengths and stages
        """
        # Create wavelength bins
        all_wavelengths = []
        for stage_results in stage_peak_data.values():
            for properties_df in stage_results.values():
                if not properties_df.empty:
                    all_wavelengths.extend(properties_df['wavelength'].tolist())
        
        if not all_wavelengths:
            return None
        
        min_wav = min(all_wavelengths)
        max_wav = max(all_wavelengths)
        wav_bins = np.linspace(min_wav, max_wav, 50)
        
        # Create intensity matrix
        stages = sorted(stage_peak_data.keys())
        intensity_matrix = np.zeros((len(stages), len(wav_bins)-1))
        
        for i, stage in enumerate(stages):
            stage_results = stage_peak_data[stage]
            
            # Collect all intensities for this stage
            stage_wavelengths = []
            stage_intensities = []
            
            for properties_df in stage_results.values():
                if not properties_df.empty:
                    stage_wavelengths.extend(properties_df['wavelength'].tolist())
                    stage_intensities.extend(properties_df['intensity'].tolist())
            
            # Bin the data
            if stage_wavelengths:
                hist, _ = np.histogram(stage_wavelengths, bins=wav_bins, weights=stage_intensities)
                intensity_matrix[i, :] = hist
        
        # Create heatmap
        fig = go.Figure(data=go.Heatmap(
            z=intensity_matrix,
            x=wav_bins[:-1],
            y=[f'Stage {s}' for s in stages],
            colorscale='Viridis',
            colorbar=dict(title='Peak Intensity')
        ))
        
        fig.update_layout(
            title='Peak Distribution Heatmap',
            xaxis_title='Wavelength',
            yaxis_title='Stage'
        )
        
        return fig
    
    def generate_peak_report(self, organized_data, prominence=0.1, width=2):
        """
        Generate comprehensive peak analysis report
        """
        # Perform complete analysis
        stage_peak_data = self.compare_peaks_across_stages(organized_data, prominence, width)
        stage_stats = self.calculate_stage_peak_statistics(stage_peak_data)
        persistent_peaks = self.identify_persistent_peaks(stage_peak_data)
        peak_trends = self.track_peak_evolution(stage_peak_data, persistent_peaks)
        
        report = {
            'stage_peak_data': stage_peak_data,
            'stage_statistics': stage_stats,
            'persistent_peaks': persistent_peaks,
            'peak_trends': peak_trends,
            'summary': self._generate_summary(stage_stats, persistent_peaks)
        }
        
        return report
    
    def _generate_summary(self, stage_stats, persistent_peaks):
        """
        Generate text summary of peak analysis
        """
        total_stages = len(stage_stats)
        total_peaks = sum(stats['statistics']['total_peaks'] for stats in stage_stats.values())
        persistent_count = len(persistent_peaks)
        
        summary = f"""
        Peak Analysis Summary:
        
        • Total Stages Analyzed: {total_stages}
        • Total Peaks Detected: {total_peaks}
        • Persistent Peaks Found: {persistent_count}
        • Average Peaks per Stage: {total_peaks/total_stages:.1f}
        
        Stage-wise Peak Counts:
        """
        
        for stage, stats in stage_stats.items():
            peak_count = stats['statistics']['total_peaks']
            avg_intensity = stats['statistics']['avg_intensity']
            summary += f"• Stage {stage}: {peak_count} peaks (avg intensity: {avg_intensity:.2f})\n        "
        
        if persistent_count > 0:
            summary += f"""
        
        Top Persistent Peaks:
            """
            for _, peak in persistent_peaks.head(5).iterrows():
                wavelength = peak['avg_wavelength']
                occurrence = peak['occurrence_rate']
                summary += f"• {wavelength:.1f} nm (appears in {occurrence:.1%} of spectra)\n            "
        
        return summary