import streamlit as st
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
import seaborn as sns
from io import BytesIO
import zipfile
import tempfile
import base64
from datetime import datetime

import data_processor as dp
import visualization as viz
import stats_analyzer as stats  # Using our renamed module
import utils
import database as db
import advanced_analytics as aa
import ml_anomaly_detection as ml_ad
import neural_network_classifier as nn_clf
import advanced_visualizations as adv_viz
import enhanced_visualizations as enh_viz
import stage_comparison as stage_comp
import difference_visualizations as diff_viz
import pdf_report_generator as pdf_gen
import ai_stage_predictor as ai_pred
import peak_analysis as peak_analyzer
import batch_processor as batch_proc
import interactive_progress as prog_viz
import batch_job_manager as job_mgr
import job_performance_heatmap as perf_heatmap
import job_complexity_analyzer as complexity_analyzer
import gamified_achievement_system as achievement_system
import time

# Set page configuration
st.set_page_config(
    page_title="Spectral Data Analyzer Pro",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI/UX
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .feature-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 8px;
        border: 1px solid #e1e5e9;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        transition: transform 0.2s;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .success-message {
        background: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #c3e6cb;
        margin: 1rem 0;
    }
    
    .warning-message {
        background: #fff3cd;
        color: #856404;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #ffeaa7;
        margin: 1rem 0;
    }
    
    .sidebar-section {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        border: 1px solid #e9ecef;
    }
    
    .data-summary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .analysis-section {
        background: white;
        border: 1px solid #e1e5e9;
        border-radius: 10px;
        padding: 1.5rem;
        margin: 1rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding-left: 20px;
        padding-right: 20px;
        background-color: #f8f9fa;
        border-radius: 8px 8px 0px 0px;
        border: 1px solid #e9ecef;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: #667eea;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# Enhanced page header
st.markdown("""
<div class="main-header">
    <h1>🔬 Advanced Spectral Data Analyzer Pro</h1>
    <p>Comprehensive spectral analysis with machine learning and advanced visualization capabilities</p>
</div>
""", unsafe_allow_html=True)

# Initialize database (optional - app works without it)
db_initialized = False
try:
    db_initialized = db.init_db()
    if not db_initialized:
        st.session_state.db_available = False
    else:
        st.session_state.db_available = True
except Exception as e:
    st.session_state.db_available = False

# Initialize session state for storing data
if 'data' not in st.session_state:
    st.session_state.data = None
if 'organized_data' not in st.session_state:
    st.session_state.organized_data = None
if 'stages' not in st.session_state:
    st.session_state.stages = []
if 'current_stage' not in st.session_state:
    st.session_state.current_stage = None
if 'file_numbers' not in st.session_state:
    st.session_state.file_numbers = {}
if 'current_file' not in st.session_state:
    st.session_state.current_file = None
if 'data_source' not in st.session_state:
    st.session_state.data_source = "memory"  # Options: "memory", "database"
if 'normalized_data' not in st.session_state:
    st.session_state.normalized_data = None

# Sidebar for data upload and controls
with st.sidebar:
    st.header("Data Controls")
    
    # Data source options
    data_source = st.radio(
        "Choose data source:",
        ["Upload data", "Database"],
        index=0 if st.session_state.data_source == "memory" else 1,
        key="data_source_radio"
    )
    
    # Update session state based on selection
    st.session_state.data_source = "memory" if data_source == "Upload data" else "database"
    
    # Initialize variables
    summary_df = None
    col1 = None
    col2 = None
    db_data = None
    success = None
    stage_to_delete = None
    
    # Database section
    if st.session_state.data_source == "database":
        st.subheader("Database Operations")
        
        # Show summary of data in database
        st.write("#### Database Content Summary")
        summary_df = db.get_stage_summary()
        if not summary_df.empty:
            st.dataframe(summary_df)
        else:
            st.info("No data found in the database.")
            
        st.write("---")
        
        # Database operations in columns
        col1, col2 = st.columns(2)
        
        with col1:
            # Load data from database
            if st.button("Load Data from Database"):
                with st.spinner("Loading data from database..."):
                    db_data = db.load_data_from_db()
                    if db_data and len(db_data) > 0:
                        st.session_state.organized_data = db_data
                        st.session_state.stages = sorted(db_data.keys())
                        
                        if st.session_state.stages:
                            st.session_state.current_stage = st.session_state.stages[0]
                            st.session_state.file_numbers = {
                                stage: sorted(db_data[stage].keys()) 
                                for stage in st.session_state.stages
                            }
                            
                            if st.session_state.file_numbers[st.session_state.current_stage]:
                                st.session_state.current_file = st.session_state.file_numbers[st.session_state.current_stage][0]
                        
                        st.success("Data loaded from database successfully!")
                        st.rerun()
                    else:
                        st.error("No data found in the database.")
            
            # Save current data to database
            if st.session_state.organized_data is not None:
                if st.button("Save Current Data to Database"):
                    with st.spinner("Saving data to database..."):
                        success = db.save_data_to_db(st.session_state.organized_data)
                        if success:
                            st.success("Data saved to database successfully!")
                            st.rerun()  # Refresh to update summary
                        else:
                            st.error("Failed to save data to database.")
        
        with col2:
            # Delete data
            if not summary_df.empty:
                st.write("#### Delete Data")
                stage_to_delete = st.selectbox(
                    "Select stage to delete:",
                    options=summary_df['Stage'].tolist(),
                    key="stage_to_delete"
                )
                
                if st.button("Delete Selected Stage", type="primary", key="delete_button"):
                    if st.session_state.current_stage == stage_to_delete:
                        st.error("Cannot delete the currently selected stage. Please select a different stage first.")
                    else:
                        with st.spinner(f"Deleting stage {stage_to_delete}..."):
                            success = db.delete_stage(stage_to_delete)
                            if success:
                                st.success(f"Stage {stage_to_delete} deleted successfully!")
                                st.rerun()  # Refresh to update summary
                            else:
                                st.error(f"Failed to delete stage {stage_to_delete}.")
    
    # Initialize upload variables
    upload_option = None
    uploaded_zip = None
    uploaded_npz = None
    file_size = 0
    all_data = None
    base_path = None
    temp_dir = None
    zip_ref = None
    e = None
    
    # Upload options
    if st.session_state.data_source == "memory":
        # Data upload options
        upload_option = st.radio(
            "Choose data input method:",
            ["Upload data directory", "Upload extracted NPZ file"]
        )
    
    if upload_option == "Upload data directory":
        st.info("Upload a ZIP file containing the data directory structure with CSV files.")
        
        # Check if the realData_final_project.zip file exists in the main directory
        if os.path.exists("realData_final_project.zip"):
            if st.button("Load Existing Data (realData_final_project.zip)", type="primary", key="load_real_data_btn"):
                with st.spinner("Loading existing data file..."):
                    try:
                        with tempfile.TemporaryDirectory() as temp_dir:
                            # Extract the existing ZIP file
                            with zipfile.ZipFile("realData_final_project.zip", 'r') as zip_ref:
                                zip_ref.extractall(temp_dir)
                            
                            # Find base path
                            base_path = os.path.join(temp_dir, "realData_final_project")
                            
                            if os.path.exists(base_path):
                                # Extract data
                                all_data = dp.extract_all_data(base_path)
                                
                                if not all_data:
                                    st.error("No data found in the existing file.")
                                else:
                                    # Store data in session state
                                    st.session_state.data = all_data
                                    st.session_state.organized_data = dp.organize_data(all_data)
                                    st.session_state.stages = sorted(st.session_state.organized_data.keys())
                                    
                                    if st.session_state.stages:
                                        st.session_state.current_stage = st.session_state.stages[0]
                                        st.session_state.file_numbers = {
                                            stage: sorted(st.session_state.organized_data[stage].keys()) 
                                            for stage in st.session_state.stages
                                        }
                                        
                                        if st.session_state.file_numbers[st.session_state.current_stage]:
                                            st.session_state.current_file = st.session_state.file_numbers[st.session_state.current_stage][0]
                                    
                                    st.success(f"Data loaded successfully! Found {len(st.session_state.stages)} stages with {sum(len(files) for files in st.session_state.file_numbers.values())} spectral files.")
                                    st.rerun()
                            else:
                                st.error("Invalid ZIP file structure.")
                                
                    except Exception as e:
                        st.error(f"Error loading existing data: {str(e)}")
        
        st.write("---")
        st.write("Or upload a new ZIP file:")
        
        uploaded_zip = st.file_uploader(
            "Upload ZIP file", 
            type=["zip"], 
            key="zip_uploader",
            help="Upload a ZIP file containing stage directories (stage0/, stage1/, etc.) with CSV files"
        )
        
        if uploaded_zip is not None:
            try:
                # Get file info safely
                file_size = uploaded_zip.size if hasattr(uploaded_zip, 'size') else len(uploaded_zip.getvalue())
                
                # Validate file size (limit to 150MB to match config)
                if file_size > 150 * 1024 * 1024:  # 150MB limit
                    st.error("File size too large. Please upload a file smaller than 150MB.")
                else:
                    st.info(f"Processing file ({file_size / (1024*1024):.1f} MB)...")
                    
                    # Process the ZIP file
                    try:
                        with tempfile.TemporaryDirectory() as temp_dir:
                            # Write uploaded file to temporary location
                            temp_zip_path = os.path.join(temp_dir, "uploaded.zip")
                            with open(temp_zip_path, "wb") as f:
                                f.write(uploaded_zip.getvalue())
                            
                            # Extract the ZIP file
                            with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                                zip_ref.extractall(temp_dir)
                            
                            # Check if the extracted directory has the expected structure
                            extracted_contents = os.listdir(temp_dir)
                            possible_base_paths = []
                            
                            # Look for realData_final_project directory
                            for item in extracted_contents:
                                item_path = os.path.join(temp_dir, item)
                                if os.path.isdir(item_path):
                                    if "realData" in item or "final_project" in item:
                                        possible_base_paths.append(item_path)
                                    # Also check for stage directories directly
                                    sub_contents = os.listdir(item_path)
                                    if any(d.startswith("stage") for d in sub_contents):
                                        possible_base_paths.append(item_path)
                            
                            # If no specific directory found, check temp_dir directly
                            if not possible_base_paths:
                                if any(d.startswith("stage") for d in extracted_contents if os.path.isdir(os.path.join(temp_dir, d))):
                                    possible_base_paths.append(temp_dir)
                            
                            if not possible_base_paths:
                                st.error("Could not find stage directories in the uploaded ZIP file. Expected structure: stage0/, stage1/, etc.")
                            else:
                                base_path = possible_base_paths[0]
                                
                                # Extract data using the functions from data_processor.py
                                with st.spinner("Extracting data from CSV files..."):
                                    try:
                                        # Use our data processor to extract the data
                                        all_data = dp.extract_all_data(base_path)
                                        
                                        if not all_data:
                                            st.error("No data found in the uploaded files.")
                                        else:
                                            # Store data directly in session state
                                            st.session_state.data = all_data
                                            st.session_state.organized_data = dp.organize_data(all_data)
                                            st.session_state.stages = sorted(st.session_state.organized_data.keys())
                                            
                                            if st.session_state.stages:
                                                st.session_state.current_stage = st.session_state.stages[0]
                                                st.session_state.file_numbers = {
                                                    stage: sorted(st.session_state.organized_data[stage].keys()) 
                                                    for stage in st.session_state.stages
                                                }
                                                
                                                if st.session_state.file_numbers[st.session_state.current_stage]:
                                                    st.session_state.current_file = st.session_state.file_numbers[st.session_state.current_stage][0]
                                            
                                            st.success(f"Data extracted successfully! Found {len(st.session_state.stages)} stages with spectral data.")
                                            st.rerun()
                                            
                                    except Exception as e:
                                        st.error(f"Error extracting data: {str(e)}")
                                        st.write("Debug info:", str(e))
                                        
                    except Exception as e:
                        st.error(f"Error processing ZIP file: {str(e)}")
                        st.write("Please ensure you're uploading a valid ZIP file.")
                        
            except Exception as e:
                st.error(f"Error handling uploaded file: {str(e)}")
                st.write("Please try uploading the file again.")
    
    elif upload_option == "Upload extracted NPZ file":
        st.info("Upload a previously extracted NPZ file.")
        uploaded_npz = st.file_uploader(
            "Upload NPZ file", 
            type=["npz"], 
            key="npz_uploader",
            help="Upload a previously processed NPZ file containing spectral data"
        )
        
        if uploaded_npz is not None:
            # Validate file size (limit to 50MB for NPZ files)
            file_size = len(uploaded_npz.getvalue())
            if file_size > 50 * 1024 * 1024:  # 50MB limit
                st.error("File size too large. Please upload a file smaller than 50MB.")
            else:
                st.info(f"Loading file ({file_size / (1024*1024):.1f} MB)...")
                
                # Load the NPZ file
                with st.spinner("Loading data..."):
                    try:
                        # Load data directly from the uploaded file
                        uploaded_bytes = uploaded_npz.getvalue()
                        with BytesIO(uploaded_bytes) as buffer:
                            data_loaded = np.load(buffer, allow_pickle=True)
                            
                            # Convert numpy archive to dictionary format
                            if hasattr(data_loaded, 'files'):
                                # NPZ file format
                                all_data = {}
                                for file_key in data_loaded.files:
                                    all_data[file_key] = data_loaded[file_key].item()
                            else:
                                # Direct numpy array
                                all_data = data_loaded
                            
                            if not all_data:
                                st.error("No data found in the NPZ file.")
                            else:
                                st.session_state.data = all_data
                                st.session_state.organized_data = dp.organize_data(all_data)
                                st.session_state.stages = sorted(st.session_state.organized_data.keys())
                                
                                if st.session_state.stages:
                                    st.session_state.current_stage = st.session_state.stages[0]
                                    st.session_state.file_numbers = {
                                        stage: sorted(st.session_state.organized_data[stage].keys()) 
                                        for stage in st.session_state.stages
                                    }
                                    
                                    if st.session_state.file_numbers[st.session_state.current_stage]:
                                        st.session_state.current_file = st.session_state.file_numbers[st.session_state.current_stage][0]
                                
                                st.success(f"Data loaded successfully! Found {len(st.session_state.stages)} stages with spectral data.")
                                st.rerun()
                                
                    except Exception as e:
                        st.error(f"Error loading NPZ file: {str(e)}")
                        st.write("Please ensure you're uploading a valid NPZ file with spectral data.")
    
    # Initialize visualization variables
    selected_stage = None
    selected_file = None
    visualization_data = None
    normalize_intensities = False
    show_single_spectrum = False
    show_stage_overview = False
    show_heatmap = False
    show_3d_surface = False
    show_histogram = False
    show_box_plot = False
    show_kde_plot = False
    show_zoomed_plot = False
    wavelength = None
    min_wavelength = 0
    max_wavelength = 100
    zoom_range = (0, 100)
    
    # Controls for visualization (only shown if data is loaded)
    if st.session_state.data is not None:
        st.header("Visualization Controls")
        
        # Stage selection
        selected_stage = st.selectbox(
            "Select stage:",
            st.session_state.stages,
            index=st.session_state.stages.index(st.session_state.current_stage) if st.session_state.current_stage in st.session_state.stages else 0
        )
        
        if selected_stage != st.session_state.current_stage:
            st.session_state.current_stage = selected_stage
            if st.session_state.file_numbers[selected_stage]:
                st.session_state.current_file = st.session_state.file_numbers[selected_stage][0]
        
        # File selection
        selected_file = st.selectbox(
            "Select file number:",
            st.session_state.file_numbers[selected_stage],
            index=st.session_state.file_numbers[selected_stage].index(st.session_state.current_file) if st.session_state.current_file in st.session_state.file_numbers[selected_stage] else 0
        )
        
        if selected_file != st.session_state.current_file:
            st.session_state.current_file = selected_file
        
        # Visualization type selection
        st.subheader("Visualization Types")
        show_single_spectrum = st.checkbox("Single Spectrum Plot", value=True)
        show_stage_overview = st.checkbox("Stage Overview Plot", value=True)
        show_heatmap = st.checkbox("Heatmap Visualization", value=True)
        show_3d_surface = st.checkbox("3D Surface Plot", value=True)
        show_histogram = st.checkbox("Histogram", value=True)
        show_box_plot = st.checkbox("Box Plot", value=True)
        show_kde_plot = st.checkbox("KDE Plot", value=True)
        show_zoomed_plot = st.checkbox("Zoomed Line Plot", value=True)
        
        # Data processing options
        st.subheader("Data Processing")
        normalize_intensities = st.checkbox("Normalize Intensities to [0-1]", value=True)
        
        # Apply normalization if selected
        if normalize_intensities and st.session_state.organized_data is not None:
            if 'normalized_data' not in st.session_state or st.session_state.normalized_data is None:
                with st.spinner("Normalizing data..."):
                    st.session_state.normalized_data = utils.normalize_all_spectra(st.session_state.organized_data)
                st.success("Data normalized successfully!")
            
            # Use normalized data for visualizations
            visualization_data = st.session_state.normalized_data
        else:
            # Use original data for visualizations
            visualization_data = st.session_state.organized_data
        
        # Wavelength range for zoomed plot
        if show_zoomed_plot:
            st.subheader("Zoom Settings")
            # Get the wavelength range from the data
            wavelength = visualization_data[selected_stage][selected_file]['wavelength']
            min_wavelength, max_wavelength = float(wavelength[0]), float(wavelength[-1])
            
            zoom_range = st.slider(
                "Select wavelength range:",
                min_value=min_wavelength,
                max_value=max_wavelength,
                value=(min_wavelength + (max_wavelength - min_wavelength) * 0.4, 
                       min_wavelength + (max_wavelength - min_wavelength) * 0.6),
                step=1.0
            )

# Initialize main visualization variables
files = []
col1 = None
col2 = None  
col3 = None
stage_stats = None
stat_fig = None
tab1 = None
tab2 = None
tab3 = None
tab4 = None
single_fig = None
single_spectrum_download = None
zoomed_fig = None
zoomed_spectrum_download = None
overview_fig = None
overview_download = None
heatmap_fig = None
heatmap_download = None
surface_fig = None
selected_stages_for_comparison = []
hist_fig = None
hist_download = None
box_fig = None
box_download = None
kde_fig = None
kde_download = None
reference_stage = None
comparison_stages = []
comparison_results = None
significance_fig = None
selected_comparison = None
diff_fig = None
top_wavelengths = []
wavelength_df = None
fig = None
csv = None
diff_viz_type = None
diff_analysis_fig = None
timeline_fig = None
sensitivity_result = None
sensitivity_fig = None
sensitivity_data = None
top_sensitive = []
sens_df = None
transition_fig = None
# Additional advanced analysis variables
adv_col1 = None
adv_col2 = None
anomaly_type = None
anomaly_results = None
anomaly_fig = None
classification_type = None
classification_results = None
classification_fig = None
enhanced_viz_type = None
enhanced_fig = None
ai_prediction_type = None
prediction_results = None
prediction_fig = None
peak_analysis_type = None
peak_results = None
peak_fig = None
batch_operation = None
batch_results = None
batch_fig = None
progress_type = None
progress_results = None
progress_fig = None

# Main content area for visualizations and statistics
if st.session_state.data is not None:
    # Data summary and statistics
    with st.expander("Data Summary and Statistics", expanded=True):
        st.subheader("Data Overview")
        
        # Basic information about the data
        total_stages = len(st.session_state.stages)
        files = st.session_state.file_numbers.values() if st.session_state.file_numbers else []
        total_files = sum(len(file_list) for file_list in files)
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Stages", total_stages)
        col2.metric("Total Files", total_files)
        col3.metric("Current Stage", f"Stage {st.session_state.current_stage}")
        
        # Statistics for the current stage
        st.subheader(f"Statistics for Stage {st.session_state.current_stage}")
        
        # Calculate statistics
        stage_stats = stats.calculate_stage_statistics(
            st.session_state.organized_data, 
            st.session_state.current_stage
        )
        
        # Display statistics
        st.write("Intensity Statistics:")
        st.dataframe(stage_stats)
        
        # Display statistics visualization
        st.subheader("Statistical Distribution")
        stat_fig = stats.plot_stage_statistics(
            st.session_state.organized_data, 
            st.session_state.current_stage
        )
        st.pyplot(stat_fig)
    
    # Visualizations
    st.header("Data Visualizations")
    
    # Create tabs for different visualization categories
    tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8, tab9, tab10, tab11, tab12, tab13, tab14, tab15, tab16 = st.tabs(["Single File Analysis", "Stage Analysis", "Multi-Stage Comparison", "Stage Comparison Tools", "Advanced Analytics", "Anomaly Detection", "Neural Network Classification", "Advanced Visualizations", "🤖 AI Stage Prediction Simulator", "🔍 Peak Detection & Analysis", "⚡ Batch Processing", "📊 Interactive Progress", "🎛️ Job Management", "🔥 Performance Heatmaps", "🔍 Complexity Analyzer", "🏆 Achievement System"])
    
    with tab1:
        if show_single_spectrum:
            st.subheader(f"Single Spectrum - Stage {st.session_state.current_stage}, File {st.session_state.current_file}")
            single_fig = viz.plot_single_spectrum(
                st.session_state.current_stage, 
                st.session_state.current_file, 
                visualization_data
            )
            st.pyplot(single_fig)
            
            # Add download button for this figure
            single_spectrum_download = utils.get_figure_download_link(
                single_fig, 
                f"spectrum_stage{st.session_state.current_stage}_file{st.session_state.current_file}.png"
            )
            st.markdown(single_spectrum_download, unsafe_allow_html=True)
        
        if show_zoomed_plot:
            st.subheader(f"Zoomed Spectrum - Stage {st.session_state.current_stage}, File {st.session_state.current_file}")
            zoomed_fig = viz.plot_zoomed_spectrum(
                st.session_state.current_stage, 
                st.session_state.current_file, 
                visualization_data,
                zoom_range
            )
            st.pyplot(zoomed_fig)
            
            # Add download button for this figure
            zoomed_spectrum_download = utils.get_figure_download_link(
                zoomed_fig, 
                f"zoomed_spectrum_stage{st.session_state.current_stage}_file{st.session_state.current_file}.png"
            )
            st.markdown(zoomed_spectrum_download, unsafe_allow_html=True)
    
    with tab2:
        if show_stage_overview:
            st.subheader(f"Stage {st.session_state.current_stage} Overview")
            overview_fig = viz.plot_stage_overview(
                st.session_state.current_stage, 
                visualization_data
            )
            st.pyplot(overview_fig)
            
            # Add download button for this figure
            overview_download = utils.get_figure_download_link(
                overview_fig, 
                f"stage{st.session_state.current_stage}_overview.png"
            )
            st.markdown(overview_download, unsafe_allow_html=True)
        
        if show_heatmap:
            st.subheader(f"Heatmap - Stage {st.session_state.current_stage}")
            heatmap_fig = viz.plot_heatmap(
                st.session_state.current_stage, 
                visualization_data
            )
            st.pyplot(heatmap_fig)
            
            # Add download button for this figure
            heatmap_download = utils.get_figure_download_link(
                heatmap_fig, 
                f"stage{st.session_state.current_stage}_heatmap.png"
            )
            st.markdown(heatmap_download, unsafe_allow_html=True)
        
        if show_3d_surface:
            st.subheader(f"3D Surface Plot - Stage {st.session_state.current_stage}")
            
            # Use Plotly for interactive 3D plot
            surface_fig = viz.plot_3d_surface_plotly(
                st.session_state.current_stage, 
                visualization_data
            )
            st.plotly_chart(surface_fig, use_container_width=True)
    
    with tab3:
        st.subheader("Multi-Stage Comparison")
        
        # Select stages to compare
        selected_stages_for_comparison = st.multiselect(
            "Select stages to compare:",
            st.session_state.stages,
            default=st.session_state.stages[:min(len(st.session_state.stages), 4)]
        )
        
        if selected_stages_for_comparison:
            if show_histogram:
                st.subheader("Histogram of Spectral Intensities")
                hist_fig = viz.plot_histogram(
                    selected_stages_for_comparison, 
                    visualization_data
                )
                st.pyplot(hist_fig)
                
                # Add download button for this figure
                hist_download = utils.get_figure_download_link(
                    hist_fig, 
                    "histogram_comparison.png"
                )
                st.markdown(hist_download, unsafe_allow_html=True)
            
            if show_box_plot:
                st.subheader("Box Plot of Intensity Distributions")
                box_fig = viz.plot_box_plot(
                    selected_stages_for_comparison, 
                    visualization_data
                )
                st.pyplot(box_fig)
                
                # Add download button for this figure
                box_download = utils.get_figure_download_link(
                    box_fig, 
                    "boxplot_comparison.png"
                )
                st.markdown(box_download, unsafe_allow_html=True)
            
            if show_kde_plot:
                st.subheader("KDE Plot of Intensity Distributions")
                kde_fig = viz.plot_kde(
                    selected_stages_for_comparison, 
                    visualization_data
                )
                st.pyplot(kde_fig)
                
                # Add download button for this figure
                kde_download = utils.get_figure_download_link(
                    kde_fig, 
                    "kde_comparison.png"
                )
                st.markdown(kde_download, unsafe_allow_html=True)
    
    with tab4:
        st.markdown("""
        <div class="analysis-section">
            <h2>⚖️ Stage Comparison Tools</h2>
            <p>Comprehensive tools to directly measure and quantify differences between contamination stages</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.organized_data is not None:
            # Stage comparison configuration
            st.write("### 🔧 Comparison Configuration")
            
            col1, col2 = st.columns(2)
            
            with col1:
                reference_stage = st.selectbox(
                    "Reference Stage (baseline):",
                    list(st.session_state.organized_data.keys()),
                    index=0,
                    help="This stage will be used as the baseline for comparison"
                )
            
            with col2:
                comparison_stages = st.multiselect(
                    "Stages to Compare Against Reference:",
                    [stage for stage in st.session_state.organized_data.keys() if stage != reference_stage],
                    default=[stage for stage in st.session_state.organized_data.keys() if stage != reference_stage][:3],
                    help="Select which stages to compare against the reference"
                )
            
            if comparison_stages:
                if st.button("🔍 Run Comprehensive Stage Comparison", type="primary"):
                    with st.spinner("Calculating stage differences and statistical metrics..."):
                        # Calculate comprehensive stage differences
                        comparison_results = stage_comp.calculate_stage_differences(
                            st.session_state.organized_data, 
                            reference_stage, 
                            comparison_stages
                        )
                        
                        if comparison_results:
                            st.session_state['stage_comparison_results'] = comparison_results
                            st.success(f"Comparison analysis complete! Analyzed {len(comparison_results)} stage pairs.")
                
                # Display results if available
                if 'stage_comparison_results' in st.session_state and st.session_state['stage_comparison_results']:
                    comparison_results = st.session_state['stage_comparison_results']
                    
                    # Overview metrics
                    st.write("### 📊 Comparison Overview")
                    overview_fig = stage_comp.plot_stage_comparison_overview(comparison_results)
                    if overview_fig:
                        st.plotly_chart(overview_fig, use_container_width=True)
                    
                    # Summary table
                    st.write("### 📋 Detailed Metrics Summary")
                    summary_df = stage_comp.create_comparison_summary_table(comparison_results)
                    if not summary_df.empty:
                        st.dataframe(summary_df, use_container_width=True)
                        
                        # Download option for summary
                        csv = summary_df.to_csv(index=False)
                        st.download_button(
                            label="📥 Download Summary as CSV",
                            data=csv,
                            file_name="stage_comparison_summary.csv",
                            mime="text/csv"
                        )
                    
                    # Statistical significance matrix
                    st.write("### 📈 Statistical Significance Analysis")
                    significance_fig = stage_comp.plot_statistical_significance_matrix(comparison_results)
                    if significance_fig:
                        st.plotly_chart(significance_fig, use_container_width=True)
                        st.info("Lower p-values (darker blue) indicate more significant differences between stages")
                    
                    # Detailed difference analysis
                    st.write("### 🔍 Detailed Difference Analysis")
                    selected_comparison = st.selectbox(
                        "Select comparison for detailed analysis:",
                        list(comparison_results.keys())
                    )
                    
                    if selected_comparison:
                        diff_fig = stage_comp.plot_difference_spectra(comparison_results, selected_comparison)
                        if diff_fig:
                            st.plotly_chart(diff_fig, use_container_width=True)
                    
                    # Most changed wavelengths
                    st.write("### 🎯 Most Significant Wavelength Changes")
                    top_wavelengths = stage_comp.identify_most_changed_wavelengths(comparison_results)
                    if top_wavelengths:
                        # Create DataFrame with proper data types to avoid Arrow conversion issues
                        wavelength_data = []
                        for wl, change in top_wavelengths:
                            wavelength_data.append({
                                'Wavelength': float(wl) if not isinstance(wl, str) else wl,
                                'Average Change': float(change) if not isinstance(change, str) else change
                            })
                        wavelength_df = pd.DataFrame(wavelength_data)
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.dataframe(wavelength_df, use_container_width=True)
                        
                        with col2:
                            # Plot top wavelengths
                            wavelengths, changes = zip(*top_wavelengths)
                            fig = go.Figure(data=go.Bar(
                                x=list(wavelengths),
                                y=list(changes),
                                marker_color='lightcoral'
                            ))
                            fig.update_layout(
                                title="Top 10 Most Changed Wavelengths",
                                xaxis_title="Wavelength",
                                yaxis_title="Average Absolute Change",
                                height=400
                            )
                            st.plotly_chart(fig, use_container_width=True)
                    
                    # Key insights
                    with st.expander("📚 Understanding Your Comparison Results"):
                        st.markdown("""
                        **Key Metrics Explained:**
                        
                        - **RMSE**: Root Mean Square Error - measures overall spectral difference
                        - **Correlation**: How similar the spectral patterns are (1 = identical, 0 = no similarity)
                        - **Spectral Angle**: Angular difference between spectra (0° = identical)
                        - **Effect Size (Cohen's d)**: Standardized measure of difference magnitude
                        - **p-values**: Statistical significance (p < 0.05 indicates significant difference)
                        
                        **Interpretation Guidelines:**
                        - High RMSE values indicate large spectral differences
                        - Low correlation suggests different contamination signatures
                        - Large effect sizes (|d| > 0.8) indicate substantial differences
                        - Significant p-values confirm the differences are not due to chance
                        """)
                
                # Add specialized difference detection visualizations
                st.markdown("---")
                st.write("### 🎯 Advanced Difference Detection Visualizations")
                
                # Visualization type selection
                diff_viz_type = st.selectbox(
                    "Select Difference Detection Analysis:",
                    [
                        "Comprehensive Difference Analysis",
                        "Contamination Timeline",
                        "Wavelength Sensitivity Map",
                        "Stage Transition Matrix"
                    ],
                    help="Choose specialized visualizations to detect contamination patterns"
                )
                
                if st.button("🔍 Generate Difference Detection Plots", type="secondary"):
                    with st.spinner(f"Creating {diff_viz_type.lower()}..."):
                        
                        if diff_viz_type == "Comprehensive Difference Analysis":
                            diff_analysis_fig = diff_viz.create_difference_detection_plots(
                                st.session_state.organized_data, reference_stage
                            )
                            if diff_analysis_fig:
                                st.plotly_chart(diff_analysis_fig, use_container_width=True)
                                st.info("This comprehensive analysis shows spectral evolution, difference heatmaps, peak shifts, contamination indices, change points, and discrimination maps.")
                        
                        elif diff_viz_type == "Contamination Timeline":
                            timeline_fig = diff_viz.create_contamination_timeline(
                                st.session_state.organized_data, reference_stage
                            )
                            if timeline_fig:
                                st.plotly_chart(timeline_fig, use_container_width=True)
                                st.info("Timeline analysis shows how contamination progresses across stages with multiple indicators.")
                        
                        elif diff_viz_type == "Wavelength Sensitivity Map":
                            sensitivity_result = diff_viz.create_wavelength_sensitivity_map(
                                st.session_state.organized_data, reference_stage
                            )
                            if sensitivity_result:
                                sensitivity_fig, sensitivity_data = sensitivity_result
                                st.plotly_chart(sensitivity_fig, use_container_width=True)
                                
                                # Show top sensitive wavelengths
                                st.write("#### Most Contamination-Sensitive Wavelengths")
                                top_sensitive = sensitivity_data[:15]  # Top 15
                                # Create DataFrame with proper data types to avoid Arrow conversion issues  
                                sensitivity_data_clean = []
                                for wl, score in top_sensitive:
                                    sensitivity_data_clean.append({
                                        'Wavelength': float(wl) if not isinstance(wl, str) else wl,
                                        'Sensitivity Score': float(score) if not isinstance(score, str) else score
                                    })
                                sens_df = pd.DataFrame(sensitivity_data_clean)
                                st.dataframe(sens_df, use_container_width=True)
                                
                                st.info("Wavelength sensitivity analysis identifies which spectral regions are most affected by contamination.")
                        
                        elif diff_viz_type == "Stage Transition Matrix":
                            transition_fig = diff_viz.create_stage_transition_matrix(
                                st.session_state.organized_data
                            )
                            if transition_fig:
                                st.plotly_chart(transition_fig, use_container_width=True)
                                st.info("Stage transition matrix shows similarity patterns between all contamination stages.")
                
                # Additional insights
                with st.expander("🧠 Advanced Analysis Insights"):
                    st.markdown("""
                    **Difference Detection Techniques:**
                    
                    - **Spectral Evolution**: Tracks how spectra change from reference to contaminated stages
                    - **Peak Shift Detection**: Identifies wavelength shifts in spectral peaks due to contamination
                    - **Contamination Index**: Quantifies overall contamination level using multiple metrics
                    - **Change Point Analysis**: Finds wavelengths with most significant variations
                    - **Wavelength Sensitivity**: Maps which regions are most affected by contamination
                    - **Timeline Analysis**: Shows contamination progression patterns over stages
                    
                    **Applications:**
                    - Early contamination detection
                    - Identifying contamination signatures
                    - Monitoring contamination progression
                    - Quality control and validation
                    """)
                
                # PDF Report Export Section
                st.markdown("---")
                st.write("### 📄 Export Comprehensive PDF Report")
                
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    st.write("Generate a detailed PDF report containing:")
                    st.markdown("""
                    - Executive summary with key findings
                    - Complete statistical analysis and significance testing
                    - All comparison visualizations and metrics
                    - Wavelength sensitivity analysis
                    - Detailed stage-by-stage comparisons
                    - Professional conclusions and recommendations
                    """)
                
                with col2:
                    if st.button("📊 Generate PDF Report", type="primary"):
                        with st.spinner("Generating comprehensive PDF report..."):
                            try:
                                # Initialize PDF generator
                                report_generator = pdf_gen.StageComparisonReportGenerator()
                                
                                # Get wavelength sensitivity data if available
                                sensitivity_data = None
                                if 'wavelength_sensitivity' in st.session_state:
                                    sensitivity_data = st.session_state.wavelength_sensitivity
                                else:
                                    # Generate sensitivity data for the report
                                    sensitivity_result = diff_viz.create_wavelength_sensitivity_map(
                                        st.session_state.organized_data, reference_stage
                                    )
                                    if sensitivity_result:
                                        _, sensitivity_data = sensitivity_result
                                
                                # Generate comprehensive PDF report
                                pdf_buffer = report_generator.generate_comprehensive_report(
                                    st.session_state.organized_data,
                                    comparison_results,
                                    sensitivity_data,
                                    reference_stage
                                )
                                
                                # Create download button
                                current_time = datetime.now().strftime("%Y%m%d_%H%M%S")
                                filename = f"Stage_Comparison_Report_{current_time}.pdf"
                                
                                st.download_button(
                                    label="💾 Download PDF Report",
                                    data=pdf_buffer.getvalue(),
                                    file_name=filename,
                                    mime="application/pdf",
                                    help="Click to download the comprehensive stage comparison report"
                                )
                                
                                st.success("PDF report generated successfully! Click the download button above to save it.")
                                
                                # Show report summary
                                with st.expander("📋 Report Summary"):
                                    st.write(f"**Report Generated:** {datetime.now().strftime('%B %d, %Y at %H:%M')}")
                                    st.write(f"**Reference Stage:** {reference_stage}")
                                    st.write(f"**Stages Analyzed:** {len(st.session_state.organized_data)}")
                                    st.write(f"**Comparisons Performed:** {len(comparison_results)}")
                                    st.write(f"**Filename:** {filename}")
                                
                            except Exception as e:
                                st.error(f"Error generating PDF report: {str(e)}")
                                st.info("Please ensure all comparison analysis has been completed before generating the report.")
            else:
                st.info("Please select at least one stage to compare against the reference stage.")
        
        else:
            st.info("Please upload and process your spectral data first to use stage comparison tools.")
    
    with tab5:
        st.subheader("Advanced Analytics")
        
        if st.session_state.organized_data is not None:
            # Create two columns for the advanced options
            adv_col1, adv_col2 = st.columns(2)
            
            with adv_col1:
                st.write("#### Signal Processing")
                
                # Spectrum processing options
                st.write("Apply processing to the current spectrum:")
                apply_baseline = st.checkbox("Apply Baseline Correction", value=False)
                
                if apply_baseline:
                    polynomial_order = st.slider("Polynomial Order", min_value=1, max_value=5, value=2)
                
                apply_smoothing = st.checkbox("Apply Smoothing", value=False)
                
                if apply_smoothing:
                    window_length = st.slider("Window Length", min_value=5, max_value=21, value=11, step=2)
                    polyorder = st.slider("Polynomial Order", min_value=1, max_value=5, value=3)
                
                # Button to apply processing
                if st.button("Process Current Spectrum"):
                    if st.session_state.current_stage is not None and st.session_state.current_file is not None:
                        # Get the current wavelength and intensity
                        wavelength = visualization_data[st.session_state.current_stage][st.session_state.current_file]['wavelength']
                        intensity = visualization_data[st.session_state.current_stage][st.session_state.current_file]['intensity']
                        
                        # Create a copy of the intensity
                        processed_intensity = intensity.copy()
                        
                        # Apply baseline correction if requested
                        if apply_baseline:
                            processed_intensity = aa.apply_baseline_correction(wavelength, processed_intensity, polynomial_order)
                        
                        # Apply smoothing if requested
                        if apply_smoothing:
                            processed_intensity = aa.apply_smoothing(processed_intensity, window_length, polyorder)
                        
                        # Create comparison plot
                        comp_fig = aa.compare_before_after_processing(
                            wavelength, 
                            intensity, 
                            processed_intensity,
                            title="Before and After Processing"
                        )
                        st.pyplot(comp_fig)
                        
                        # Add download button for this figure
                        comp_download = utils.get_figure_download_link(
                            comp_fig, 
                            "processed_spectrum.png"
                        )
                        st.markdown(comp_download, unsafe_allow_html=True)
                
                # Derivative analysis
                st.write("#### Derivative Analysis")
                derivative_order = st.radio("Derivative Order", [1, 2], horizontal=True)
                
                if st.button("Calculate Derivative"):
                    if st.session_state.current_stage is not None and st.session_state.current_file is not None:
                        # Get the current wavelength and intensity
                        wavelength = visualization_data[st.session_state.current_stage][st.session_state.current_file]['wavelength']
                        intensity = visualization_data[st.session_state.current_stage][st.session_state.current_file]['intensity']
                        
                        # Calculate derivative
                        derivative = aa.calculate_derivative_spectrum(wavelength, intensity, derivative_order)
                        
                        # Create derivative plot
                        deriv_fig = aa.plot_derivative_spectrum(
                            wavelength, 
                            intensity, 
                            derivative,
                            derivative_order
                        )
                        st.pyplot(deriv_fig)
                        
                        # Add download button for this figure
                        deriv_download = utils.get_figure_download_link(
                            deriv_fig, 
                            f"derivative_{derivative_order}_spectrum.png"
                        )
                        st.markdown(deriv_download, unsafe_allow_html=True)
            
            with adv_col2:
                st.write("#### Peak Detection")
                
                prominence = st.slider("Peak Prominence", min_value=0.01, max_value=1.0, value=0.1, step=0.01)
                width = st.slider("Peak Width", min_value=1, max_value=20, value=5)
                
                if st.button("Detect Peaks"):
                    if st.session_state.current_stage is not None and st.session_state.current_file is not None:
                        # Get the current wavelength and intensity
                        wavelength = visualization_data[st.session_state.current_stage][st.session_state.current_file]['wavelength']
                        intensity = visualization_data[st.session_state.current_stage][st.session_state.current_file]['intensity']
                        
                        # Find peaks
                        peaks, peak_wavelengths, properties = aa.find_spectral_peaks(
                            wavelength, 
                            intensity, 
                            prominence=prominence, 
                            width=width
                        )
                        
                        if len(peaks) > 0:
                            # Plot the spectrum with peaks
                            fig, ax = plt.subplots(figsize=(12, 6))
                            ax.plot(wavelength, intensity)
                            ax.plot(peak_wavelengths, intensity[peaks], "x", color='red', markersize=10)
                            for i, peak_wavelength in enumerate(peak_wavelengths):
                                ax.annotate(f"{i+1}", (peak_wavelength, intensity[peaks[i]]), 
                                            xytext=(5, 5), textcoords='offset points')
                            ax.set_title(f"Detected Peaks (Stage {st.session_state.current_stage}, File {st.session_state.current_file})")
                            ax.set_xlabel("Wavelength (nm)")
                            ax.set_ylabel("Intensity")
                            ax.grid(True, alpha=0.3)
                            st.pyplot(fig)
                            
                            # Display peak metrics
                            peak_metrics = aa.calculate_peak_metrics(wavelength, intensity, peaks, properties)
                            st.write("#### Peak Metrics")
                            st.dataframe(peak_metrics)
                            
                            # Add download button for peak data
                            csv = peak_metrics.to_csv(index=False)
                            b64 = base64.b64encode(csv.encode()).decode()
                            href = f'<a href="data:file/csv;base64,{b64}" download="peak_metrics.csv">Download Peak Data (CSV)</a>'
                            st.markdown(href, unsafe_allow_html=True)
                        else:
                            st.warning("No peaks detected with the current settings. Try adjusting prominence and width parameters.")
                
                # Principal Component Analysis
                st.write("#### Principal Component Analysis (PCA)")
                
                n_components = st.slider("Number of Components", min_value=2, max_value=5, value=3)
                
                if st.button("Run PCA Analysis"):
                    if st.session_state.organized_data is not None:
                        with st.spinner("Running PCA analysis..."):
                            # Perform PCA
                            pca, X_pca, explained_variance, labels = aa.perform_pca_analysis(
                                visualization_data, 
                                n_components=n_components
                            )
                            
                            # Plot PCA results
                            pca_fig = aa.plot_pca_results(
                                X_pca, 
                                explained_variance, 
                                labels,
                                st.session_state.stages
                            )
                            
                            # Display PCA plot
                            st.plotly_chart(pca_fig, use_container_width=True)
                            
                            # Display explained variance
                            st.write("#### Explained Variance")
                            explained_var_df = pd.DataFrame({
                                'Principal Component': [f"PC{i+1}" for i in range(n_components)],
                                'Explained Variance (%)': [ev * 100 for ev in explained_variance]
                            })
                            st.dataframe(explained_var_df)
            
            # Line plot comparing stages
            st.subheader("Spectral Line Plot Comparison")
            line_fig = viz.plot_line_comparison(
                selected_stages_for_comparison, 
                st.session_state.organized_data
            )
            st.pyplot(line_fig)
            
            # Add download button for this figure
            line_download = utils.get_figure_download_link(
                line_fig, 
                "line_comparison.png"
            )
            st.markdown(line_download, unsafe_allow_html=True)
    
    with tab5:
        st.subheader("Machine Learning Anomaly Detection")
        
        if st.session_state.organized_data is not None:
            st.write("""
            This section uses machine learning algorithms to detect anomalies and unusual patterns 
            in your spectral data. Anomalies can indicate contamination, measurement errors, or 
            significant changes between stages.
            """)
            
            # ML Algorithm selection
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("#### Algorithm Settings")
                
                algorithm = st.selectbox(
                    "Select ML Algorithm:",
                    ["Isolation Forest", "One-Class SVM", "DBSCAN Clustering", "All Methods"]
                )
                
                contamination = st.slider(
                    "Expected Contamination Rate (Isolation Forest)",
                    min_value=0.01, max_value=0.5, value=0.1, step=0.01,
                    help="Expected proportion of outliers in the data"
                )
                
                nu = st.slider(
                    "Nu Parameter (One-Class SVM)",
                    min_value=0.01, max_value=0.5, value=0.1, step=0.01,
                    help="Upper bound on the fraction of training errors"
                )
                
                eps = st.slider(
                    "Epsilon (DBSCAN)",
                    min_value=0.1, max_value=2.0, value=0.5, step=0.1,
                    help="Maximum distance between samples in the same cluster"
                )
                min_samples = st.slider(
                    "Min Samples (DBSCAN)",
                    min_value=3, max_value=20, value=5,
                    help="Minimum number of samples in a cluster"
                )
            
            with col2:
                st.write("#### Analysis Options")
                
                use_normalized_data = st.checkbox(
                    "Use Normalized Data for ML",
                    value=True,
                    help="Recommended for better ML performance"
                )
                
                show_detailed_results = st.checkbox(
                    "Show Detailed Results",
                    value=True
                )
                
                generate_report = st.checkbox(
                    "Generate Summary Report",
                    value=True
                )
            
            # Run anomaly detection
            if st.button("Run Anomaly Detection Analysis", type="primary"):
                # Select data source
                if use_normalized_data and st.session_state.normalized_data is not None:
                    analysis_data = st.session_state.normalized_data
                    data_type = "normalized"
                else:
                    analysis_data = st.session_state.organized_data
                    data_type = "original"
                
                with st.spinner("Running machine learning anomaly detection..."):
                    try:
                        if algorithm == "All Methods":
                            # Run comprehensive analysis
                            results = ml_ad.run_comprehensive_anomaly_analysis(
                                analysis_data, 
                                contamination=contamination,
                                nu=nu,
                                eps=eps,
                                min_samples=min_samples
                            )
                            
                            # Display results for each method
                            for method_name, method_results in results.items():
                                st.write(f"### {method_name.replace('_', ' ').title()} Results")
                                
                                anomaly_data = method_results['data']
                                
                                # Summary statistics
                                total_files = len(anomaly_data)
                                anomaly_count = anomaly_data['is_anomaly'].sum()
                                anomaly_rate = anomaly_count / total_files
                                
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Total Files", total_files)
                                with col2:
                                    st.metric("Anomalies Detected", anomaly_count)
                                with col3:
                                    st.metric("Anomaly Rate", f"{anomaly_rate:.1%}")
                                
                                # Visualization
                                if 'anomaly_score' in anomaly_data.columns:
                                    viz_fig = ml_ad.plot_anomaly_detection_results(
                                        anomaly_data, 
                                        method_name.replace('_', ' ').title()
                                    )
                                    st.plotly_chart(viz_fig, use_container_width=True)
                                
                                # Stage comparison
                                if show_detailed_results:
                                    st.write("#### Stage-wise Analysis")
                                    stage_summary = method_results['summary']
                                    st.dataframe(stage_summary)
                                    
                                    # Stage transitions
                                    transitions = ml_ad.identify_stage_transitions(anomaly_data)
                                    st.write("#### Stage Transition Analysis")
                                    st.dataframe(transitions)
                                
                                st.write("---")
                        
                        else:
                            # Run single algorithm
                            data_df = ml_ad.prepare_data_for_ml(analysis_data)
                            
                            if algorithm == "Isolation Forest":
                                anomaly_results, model, scaler = ml_ad.detect_anomalies_isolation_forest(
                                    data_df, contamination
                                )
                            elif algorithm == "One-Class SVM":
                                anomaly_results, model, scaler = ml_ad.detect_anomalies_one_class_svm(
                                    data_df, nu
                                )
                            elif algorithm == "DBSCAN Clustering":
                                anomaly_results, model, scaler = ml_ad.detect_anomalies_dbscan(
                                    data_df, eps, min_samples
                                )
                            
                            # Display results
                            st.write(f"### {algorithm} Results")
                            
                            # Summary metrics
                            total_files = len(anomaly_results)
                            anomaly_count = anomaly_results['is_anomaly'].sum()
                            anomaly_rate = anomaly_count / total_files
                            
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Total Files", total_files)
                            with col2:
                                st.metric("Anomalies Detected", anomaly_count)
                            with col3:
                                st.metric("Anomaly Rate", f"{anomaly_rate:.1%}")
                            
                            # Visualizations
                            if 'anomaly_score' in anomaly_results.columns or algorithm == "DBSCAN Clustering":
                                viz_fig = ml_ad.plot_anomaly_detection_results(anomaly_results, algorithm)
                                st.plotly_chart(viz_fig, use_container_width=True)
                                
                                # Heatmap
                                heatmap_fig = ml_ad.plot_anomaly_heatmap(anomaly_results, analysis_data)
                                st.pyplot(heatmap_fig)
                            
                            # Detailed results
                            if show_detailed_results:
                                st.write("#### Detailed Results")
                                
                                # Stage summary
                                stage_summary = ml_ad.compare_stages_anomalies(anomaly_results)
                                st.write("**Stage-wise Analysis:**")
                                st.dataframe(stage_summary)
                                
                                # Stage transitions
                                transitions = ml_ad.identify_stage_transitions(anomaly_results)
                                st.write("**Stage Transition Analysis:**")
                                st.dataframe(transitions)
                                
                                # Most anomalous files
                                if 'anomaly_score' in anomaly_results.columns:
                                    most_anomalous = anomaly_results.nsmallest(10, 'anomaly_score')[
                                        ['stage_file', 'stage', 'file_number', 'anomaly_score', 'is_anomaly']
                                    ]
                                    st.write("**Most Anomalous Files:**")
                                    st.dataframe(most_anomalous)
                            
                            # Generate report
                            if generate_report:
                                st.write("#### Summary Report")
                                report = ml_ad.generate_anomaly_report(anomaly_results, algorithm)
                                st.text_area("Anomaly Detection Report", report, height=300)
                        
                        st.success(f"Anomaly detection completed using {data_type} data!")
                        
                    except Exception as e:
                        st.error(f"Error during anomaly detection: {str(e)}")
                        st.write("Please check your data and try different parameters.")
            
            # Information about algorithms
            with st.expander("About the Machine Learning Algorithms"):
                st.write("""
                **Isolation Forest:**
                - Best for: General anomaly detection
                - Works by: Isolating anomalies in random subspaces
                - Good for: High-dimensional data, fast processing
                
                **One-Class SVM:**
                - Best for: Complex, non-linear anomalies
                - Works by: Learning a boundary around normal data
                - Good for: Small datasets, complex patterns
                
                **DBSCAN Clustering:**
                - Best for: Density-based anomaly detection
                - Works by: Identifying outliers as noise points
                - Good for: Irregular cluster shapes, varying densities
                
                **Recommendations:**
                - Use normalized data for better performance
                - Start with Isolation Forest for general analysis
                - Try all methods to compare results
                - Adjust parameters based on your data characteristics
                """)
        
        else:
            st.info("Please upload and process your spectral data first to use anomaly detection features.")
    
    with tab6:
        st.subheader("Neural Network Binary Classification")
        
        if st.session_state.organized_data is not None:
            st.write("""
            This section trains neural network models to classify spectra between Stage 0 and Stage 4.
            This binary classification helps identify contamination patterns and stage transitions.
            """)
            
            # Check if both stages are available
            available_stages = list(st.session_state.organized_data.keys())
            has_stage_0 = 0 in available_stages
            has_stage_4 = 4 in available_stages
            
            if not (has_stage_0 and has_stage_4):
                st.warning(f"Binary classification requires both Stage 0 and Stage 4 data. Available stages: {available_stages}")
                st.info("Please ensure your dataset contains both Stage 0 and Stage 4 for binary classification.")
            else:
                # Model configuration
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("#### Model Configuration")
                    
                    model_type = st.selectbox(
                        "Select Model Type:",
                        ["Scikit-learn MLP"]
                    )
                    
                    test_size = st.slider(
                        "Test Set Size (%)",
                        min_value=10, max_value=50, value=20, step=5
                    ) / 100
                    
                    use_normalized_data_nn = st.checkbox(
                        "Use Normalized Data",
                        value=True,
                        help="Recommended for better neural network performance"
                    )
                    
                    perform_cv = st.checkbox(
                        "Perform Cross-Validation",
                        value=True,
                        help="5-fold cross-validation for model evaluation"
                    )
                
                with col2:
                    st.write("#### Advanced Settings")
                    
                    st.write("**Neural Network Configuration:**")
                    sklearn_hidden_layers = st.text_input(
                        "Hidden Layers (comma-separated)",
                        value="100,50",
                        help="e.g., 100,50 for two layers with 100 and 50 neurons"
                    )
                    
                    max_iterations = st.slider(
                        "Maximum Training Iterations",
                        min_value=200, max_value=2000, value=1000, step=100
                    )
                
                # Train models
                if st.button("Train Neural Network Models", type="primary"):
                    # Select data source
                    if use_normalized_data_nn and st.session_state.normalized_data is not None:
                        analysis_data = st.session_state.normalized_data
                        data_type = "normalized"
                    else:
                        analysis_data = st.session_state.organized_data
                        data_type = "original"
                    
                    with st.spinner("Training neural network models..."):
                        try:
                            # Prepare data
                            X, y, file_info = nn_clf.prepare_binary_classification_data(analysis_data)
                            
                            if len(X) == 0:
                                st.error("No data available for classification. Please check your dataset.")
                            else:
                                st.info(f"Training with {len(X)} samples using {data_type} data")
                                
                                # Parse hidden layer configuration
                                try:
                                    sklearn_layers = tuple(map(int, sklearn_hidden_layers.split(',')))
                                except:
                                    sklearn_layers = (100, 50)
                                    st.warning("Invalid layer configuration, using default: (100, 50)")
                                
                                # Train the neural network model
                                st.write("### Training Neural Network Model...")
                                sklearn_results = nn_clf.train_sklearn_model(X, y, test_size=test_size)
                                sklearn_evaluation = nn_clf.evaluate_model_performance(sklearn_results)
                                
                                # Display results
                                st.write("#### Model Performance")
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Accuracy", f"{sklearn_evaluation['accuracy']:.3f}")
                                with col2:
                                    st.metric("ROC AUC", f"{sklearn_evaluation['roc_auc']:.3f}")
                                with col3:
                                    st.metric("Test Samples", len(sklearn_results['y_test']))
                                
                                # Visualization
                                sklearn_plot = nn_clf.plot_model_performance(
                                    sklearn_results, sklearn_evaluation, "Neural Network Classifier"
                                )
                                st.plotly_chart(sklearn_plot, use_container_width=True)
                                
                                # Cross-validation
                                if perform_cv:
                                    st.write("### Cross-Validation Results")
                                    sklearn_cv = nn_clf.cross_validate_model(X, y, model_type='sklearn')
                                    st.write(f"**5-Fold Cross-Validation Accuracy:** {sklearn_cv['mean_accuracy']:.3f} ± {sklearn_cv['std_accuracy']:.3f}")
                                
                                # Classify all spectra
                                st.write("### Classification of All Spectra")
                                
                                # Use the trained model for classification
                                best_model = sklearn_results['model']
                                best_scaler = sklearn_results['scaler']
                                
                                # Classify all spectra
                                predictions_df = nn_clf.classify_unknown_spectra(
                                    best_model, best_scaler, analysis_data
                                )
                                
                                # Display classification results
                                st.write("#### Classification Results Summary")
                                
                                # Summary by stage
                                stage_summary = predictions_df.groupby('actual_stage').agg({
                                    'predicted_stage': lambda x: (x == 4).sum(),
                                    'confidence': 'mean'
                                }).round(3)
                                stage_summary.columns = ['Predicted_as_Stage_4', 'Avg_Confidence']
                                stage_summary['Total_Files'] = predictions_df.groupby('actual_stage').size()
                                stage_summary['Percentage_Stage_4'] = (stage_summary['Predicted_as_Stage_4'] / stage_summary['Total_Files'] * 100).round(1)
                                
                                st.dataframe(stage_summary)
                                
                                # Detailed predictions
                                if st.checkbox("Show Detailed Predictions"):
                                    st.dataframe(predictions_df)
                                
                                # Generate comprehensive report
                                report = nn_clf.generate_classification_report(
                                    sklearn_evaluation, predictions_df, "Neural Network Classifier"
                                )
                                st.text_area("Classification Report", report, height=400)
                                
                                st.success(f"Neural network training completed successfully!")
                                
                        except Exception as e:
                            st.error(f"Error during neural network training: {str(e)}")
                            st.write("Please check your data and try adjusting the parameters.")
            
            # Information about neural networks
            with st.expander("About Neural Network Classification"):
                st.write("""
                **Binary Classification Task:**
                - Classifies spectra as either Stage 0 or Stage 4
                - Useful for contamination detection and stage identification
                - Can help identify transition patterns between clean and contaminated states
                
                **Neural Network Model:**
                - Multi-Layer Perceptron with configurable hidden layers
                - Uses backpropagation for learning spectral patterns
                - Automatic early stopping and adaptive learning rate
                - Built-in regularization to prevent overfitting
                
                **Tips for Better Performance:**
                - Use normalized data for improved convergence
                - Adjust hidden layer sizes based on data complexity
                - Perform cross-validation to assess model generalization
                - Start with 2-3 hidden layers for most datasets
                - Increase training iterations if the model hasn't converged
                """)
        
        else:
            st.info("Please upload and process your spectral data first to use neural network classification.")
    
    with tab7:
        st.subheader("Advanced Visualization Techniques")
        
        if st.session_state.organized_data is not None:
            st.write("""
            This section provides sophisticated visualization methods to explore spectral patterns, 
            relationships, and features that may not be apparent in standard plots.
            """)
            
            # Visualization selection
            adv_viz_type = st.selectbox(
                "Select Advanced Visualization:",
                [
                    "3D Spectral Waterfall",
                    "Correlation Matrix",
                    "Principal Component Analysis (PCA)",
                    "t-SNE Dimensionality Reduction",
                    "Spectral Derivatives",
                    "Peak Analysis",
                    "Spectral Evolution",
                    "Intensity Distribution Heatmap",
                    "Spectral Density Plot",
                    "Interactive Animated Comparison",
                    "Spectral Clustering Analysis",
                    "Advanced Interpolated Heatmap",
                    "Dynamic Range Analysis",
                    "Spectral Fingerprints",
                    "Wavelength Importance Analysis"
                ]
            )
            
            # Use normalized data option
            use_normalized_adv = st.checkbox(
                "Use Normalized Data for Analysis",
                value=True,
                key="adv_viz_normalized"
            )
            
            # Select data source
            if use_normalized_adv and st.session_state.normalized_data is not None:
                viz_data = st.session_state.normalized_data
                data_info = "normalized"
            else:
                viz_data = st.session_state.organized_data
                data_info = "original"
            
            if adv_viz_type == "3D Spectral Waterfall":
                st.write("#### 3D Spectral Waterfall Plot")
                st.write("Shows multiple spectra in 3D space for better pattern visualization.")
                
                waterfall_stage = st.selectbox(
                    "Select Stage for Waterfall:",
                    list(viz_data.keys()),
                    key="waterfall_stage"
                )
                
                max_files = st.slider(
                    "Maximum Files to Display:",
                    min_value=5, max_value=50, value=20
                )
                
                if st.button("Generate 3D Waterfall Plot"):
                    with st.spinner("Creating 3D waterfall visualization..."):
                        waterfall_fig = adv_viz.plot_spectral_waterfall(viz_data, waterfall_stage, max_files)
                        if waterfall_fig:
                            st.plotly_chart(waterfall_fig, use_container_width=True)
                        else:
                            st.error(f"No data found for Stage {waterfall_stage}")
            
            elif adv_viz_type == "Correlation Matrix":
                st.write("#### Spectral Correlation Matrix")
                st.write("Analyze relationships between different files and stages.")
                
                corr_stages = st.multiselect(
                    "Select Stages for Correlation Analysis:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())[:3]
                )
                
                if st.button("Generate Correlation Matrix"):
                    if corr_stages:
                        with st.spinner("Computing correlations..."):
                            corr_fig = adv_viz.plot_correlation_matrix(viz_data, corr_stages)
                            if corr_fig:
                                st.plotly_chart(corr_fig, use_container_width=True)
                                st.info(f"Correlation analysis completed using {data_info} data")
                    else:
                        st.warning("Please select at least one stage for analysis.")
            
            elif adv_viz_type == "Principal Component Analysis (PCA)":
                st.write("#### Principal Component Analysis")
                st.write("Reduce dimensionality and identify the main sources of variation.")
                
                pca_stages = st.multiselect(
                    "Select Stages for PCA:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                n_components = st.slider(
                    "Number of Components:",
                    min_value=2, max_value=3, value=3
                )
                
                if st.button("Run PCA Analysis"):
                    if pca_stages:
                        with st.spinner("Running PCA analysis..."):
                            pca_result = adv_viz.plot_pca_analysis(viz_data, pca_stages, n_components)
                            if pca_result:
                                pca_fig, explained_variance = pca_result
                                st.plotly_chart(pca_fig, use_container_width=True)
                                
                                # Show explained variance
                                st.write("#### Explained Variance Ratio:")
                                for i, var in enumerate(explained_variance):
                                    st.write(f"PC{i+1}: {var:.3f} ({var*100:.1f}%)")
                                total_var = sum(explained_variance)
                                st.write(f"**Total explained variance: {total_var:.3f} ({total_var*100:.1f}%)**")
                    else:
                        st.warning("Please select at least one stage for analysis.")
            
            elif adv_viz_type == "t-SNE Dimensionality Reduction":
                st.write("#### t-SNE Analysis")
                st.write("Non-linear dimensionality reduction to reveal hidden patterns.")
                
                tsne_stages = st.multiselect(
                    "Select Stages for t-SNE:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                perplexity = st.slider(
                    "Perplexity Parameter:",
                    min_value=5, max_value=50, value=30,
                    help="Balance between local and global structure"
                )
                
                if st.button("Run t-SNE Analysis"):
                    if tsne_stages:
                        with st.spinner("Running t-SNE analysis (this may take a moment)..."):
                            tsne_fig = adv_viz.plot_tsne_analysis(viz_data, tsne_stages, perplexity)
                            if tsne_fig:
                                st.plotly_chart(tsne_fig, use_container_width=True)
                                st.info("t-SNE reveals non-linear relationships in your spectral data")
                            else:
                                st.error("Not enough data points for t-SNE analysis (minimum 4 required)")
                    else:
                        st.warning("Please select at least one stage for analysis.")
            
            elif adv_viz_type == "Spectral Derivatives":
                st.write("#### Spectral Derivatives")
                st.write("Highlight spectral features through derivative analysis.")
                
                col1, col2 = st.columns(2)
                with col1:
                    deriv_stage = st.selectbox(
                        "Select Stage:",
                        list(viz_data.keys()),
                        key="deriv_stage"
                    )
                with col2:
                    deriv_file = st.selectbox(
                        "Select File:",
                        list(viz_data[deriv_stage].keys()) if deriv_stage in viz_data else [],
                        key="deriv_file"
                    )
                
                derivative_orders = st.multiselect(
                    "Select Derivative Orders:",
                    [1, 2, 3],
                    default=[1, 2]
                )
                
                if st.button("Generate Derivative Analysis"):
                    if derivative_orders:
                        with st.spinner("Computing spectral derivatives..."):
                            deriv_fig = adv_viz.plot_spectral_derivatives(
                                viz_data, deriv_stage, deriv_file, derivative_orders
                            )
                            if deriv_fig:
                                st.plotly_chart(deriv_fig, use_container_width=True)
                    else:
                        st.warning("Please select at least one derivative order.")
            
            elif adv_viz_type == "Peak Analysis":
                st.write("#### Peak Detection and Analysis")
                st.write("Identify and analyze spectral peaks across files.")
                
                peak_stage = st.selectbox(
                    "Select Stage for Peak Analysis:",
                    list(viz_data.keys()),
                    key="peak_stage"
                )
                
                col1, col2 = st.columns(2)
                with col1:
                    prominence = st.slider(
                        "Peak Prominence:",
                        min_value=0.01, max_value=1.0, value=0.1, step=0.01
                    )
                with col2:
                    distance = st.slider(
                        "Minimum Peak Distance:",
                        min_value=1, max_value=50, value=10
                    )
                
                if st.button("Analyze Peaks"):
                    with st.spinner("Detecting and analyzing peaks..."):
                        peak_fig = adv_viz.plot_peak_analysis(viz_data, peak_stage, prominence, distance)
                        if peak_fig:
                            st.plotly_chart(peak_fig, use_container_width=True)
            
            elif adv_viz_type == "Spectral Evolution":
                st.write("#### Spectral Evolution Across Stages")
                st.write("Track how specific files change across different stages.")
                
                available_stages = sorted(viz_data.keys())
                evolution_stages = st.multiselect(
                    "Select Stages to Track:",
                    available_stages,
                    default=available_stages
                )
                
                if st.button("Generate Evolution Plot"):
                    if len(evolution_stages) > 1:
                        with st.spinner("Analyzing spectral evolution..."):
                            evolution_fig = adv_viz.plot_spectral_evolution(viz_data, stages=evolution_stages)
                            if evolution_fig:
                                st.plotly_chart(evolution_fig, use_container_width=True)
                                st.info("Shows how mean intensity changes across stages for each file")
                    else:
                        st.warning("Please select at least 2 stages for evolution analysis.")
            
            elif adv_viz_type == "Intensity Distribution Heatmap":
                st.write("#### Wavelength vs Intensity Heatmap")
                st.write("Comprehensive view of intensity distributions across all wavelengths.")
                
                heatmap_stages = st.multiselect(
                    "Select Stages for Heatmap:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                bin_size = st.slider(
                    "Histogram Bins:",
                    min_value=20, max_value=100, value=50
                )
                
                if st.button("Generate Distribution Heatmap"):
                    if heatmap_stages:
                        with st.spinner("Creating intensity distribution heatmap..."):
                            heatmap_fig = adv_viz.plot_wavelength_intensity_heatmap(
                                viz_data, heatmap_stages, bin_size
                            )
                            if heatmap_fig:
                                st.plotly_chart(heatmap_fig, use_container_width=True)
                    else:
                        st.warning("Please select at least one stage for the heatmap.")
            
            elif adv_viz_type == "Spectral Density Plot":
                st.write("#### Spectral Density Distribution")
                st.write("2D density plot showing data distribution patterns.")
                
                density_stages = st.multiselect(
                    "Select Stages for Density Plot:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())[:2]
                )
                
                # Wavelength range selection
                if viz_data:
                    sample_stage = list(viz_data.keys())[0]
                    sample_file = list(viz_data[sample_stage].keys())[0]
                    sample_wavelength = viz_data[sample_stage][sample_file]['wavelength']
                    
                    wavelength_range = st.slider(
                        "Wavelength Range:",
                        min_value=float(np.min(sample_wavelength)),
                        max_value=float(np.max(sample_wavelength)),
                        value=(float(np.min(sample_wavelength)), float(np.max(sample_wavelength))),
                        step=1.0
                    )
                else:
                    wavelength_range = None
                
                if st.button("Generate Density Plot"):
                    if density_stages:
                        with st.spinner("Creating spectral density plot..."):
                            density_fig = adv_viz.plot_spectral_density(
                                viz_data, density_stages, wavelength_range
                            )
                            if density_fig:
                                st.plotly_chart(density_fig, use_container_width=True)
                    else:
                        st.warning("Please select at least one stage for the density plot.")
            
            elif adv_viz_type == "Interactive Animated Comparison":
                st.write("#### Interactive Animated Spectral Comparison")
                st.write("Watch your spectra animate through different stages and files with play controls.")
                
                animation_stages = st.multiselect(
                    "Select Stages for Animation:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())[:3]
                )
                
                max_files_per_stage = st.slider(
                    "Max Files per Stage:",
                    min_value=2, max_value=10, value=5
                )
                
                if st.button("Create Interactive Animation"):
                    if animation_stages:
                        with st.spinner("Creating interactive animation..."):
                            animation_fig = enh_viz.plot_interactive_spectra_comparison(
                                viz_data, animation_stages, max_files_per_stage
                            )
                            if animation_fig:
                                st.plotly_chart(animation_fig, use_container_width=True)
                                st.info("Use the play button to animate through your spectral data!")
                    else:
                        st.warning("Please select at least one stage for animation.")
            
            elif adv_viz_type == "Spectral Clustering Analysis":
                st.write("#### Spectral Clustering Analysis")
                st.write("Discover hidden patterns by grouping similar spectra together.")
                
                col1, col2 = st.columns(2)
                with col1:
                    clustering_stages = st.multiselect(
                        "Select Stages for Clustering:",
                        list(viz_data.keys()),
                        default=list(viz_data.keys())
                    )
                    
                    clustering_method = st.selectbox(
                        "Clustering Method:",
                        ["kmeans", "dbscan"]
                    )
                
                with col2:
                    if clustering_method == "kmeans":
                        n_clusters = st.slider(
                            "Number of Clusters:",
                            min_value=2, max_value=8, value=3
                        )
                    else:
                        n_clusters = 3  # Default for display
                
                if st.button("Run Clustering Analysis"):
                    if clustering_stages:
                        with st.spinner("Running clustering analysis..."):
                            clustering_result = enh_viz.plot_spectral_clustering(
                                viz_data, clustering_stages, n_clusters, clustering_method
                            )
                            if clustering_result:
                                cluster_fig, cluster_labels, silhouette = clustering_result
                                st.plotly_chart(cluster_fig, use_container_width=True)
                                st.success(f"Clustering completed! Silhouette score: {silhouette:.3f}")
                            else:
                                st.error("Not enough data for clustering analysis.")
                    else:
                        st.warning("Please select at least one stage for clustering.")
            
            elif adv_viz_type == "Advanced Interpolated Heatmap":
                st.write("#### Advanced Interpolated Heatmap")
                st.write("High-resolution heatmap with interpolation for smooth visualization.")
                
                heatmap_adv_stages = st.multiselect(
                    "Select Stages for Advanced Heatmap:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                if st.button("Generate Advanced Heatmap"):
                    if heatmap_adv_stages:
                        with st.spinner("Creating advanced interpolated heatmap..."):
                            advanced_heatmap = enh_viz.plot_spectral_heatmap_advanced(
                                viz_data, heatmap_adv_stages
                            )
                            if advanced_heatmap:
                                st.plotly_chart(advanced_heatmap, use_container_width=True)
                                st.info("Advanced heatmap with interpolation for smooth visualization")
                    else:
                        st.warning("Please select at least one stage for the heatmap.")
            
            elif adv_viz_type == "Dynamic Range Analysis":
                st.write("#### Dynamic Range and Signal Quality Analysis")
                st.write("Comprehensive analysis of signal quality metrics across your data.")
                
                range_stages = st.multiselect(
                    "Select Stages for Range Analysis:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                if st.button("Analyze Dynamic Range"):
                    if range_stages:
                        with st.spinner("Analyzing dynamic range and signal quality..."):
                            range_result = enh_viz.plot_dynamic_range_analysis(viz_data, range_stages)
                            if range_result:
                                range_fig, stats_df = range_result
                                st.plotly_chart(range_fig, use_container_width=True)
                                
                                # Show summary statistics
                                st.write("#### Summary Statistics")
                                summary_stats = stats_df.groupby('stage').agg({
                                    'range': ['mean', 'std'],
                                    'snr': ['mean', 'std'],
                                    'cv': ['mean', 'std']
                                }).round(3)
                                st.dataframe(summary_stats)
                    else:
                        st.warning("Please select at least one stage for analysis.")
            
            elif adv_viz_type == "Spectral Fingerprints":
                st.write("#### Spectral Fingerprints")
                st.write("Unique polar visualization showing the distinctive pattern of each spectrum.")
                
                fingerprint_stage = st.selectbox(
                    "Select Stage for Fingerprinting:",
                    list(viz_data.keys()),
                    key="fingerprint_stage"
                )
                
                max_fingerprints = st.slider(
                    "Maximum Fingerprints to Display:",
                    min_value=1, max_value=10, value=6
                )
                
                if st.button("Generate Spectral Fingerprints"):
                    with st.spinner("Creating spectral fingerprints..."):
                        fingerprint_fig = enh_viz.plot_spectral_fingerprint(
                            viz_data, fingerprint_stage, max_fingerprints
                        )
                        if fingerprint_fig:
                            st.plotly_chart(fingerprint_fig, use_container_width=True)
                            st.info("Each fingerprint shows the unique spectral signature in polar coordinates")
                        else:
                            st.error(f"No data found for Stage {fingerprint_stage}")
            
            elif adv_viz_type == "Wavelength Importance Analysis":
                st.write("#### Wavelength Importance Analysis")
                st.write("Identify which wavelengths are most important for distinguishing between stages.")
                
                importance_stages = st.multiselect(
                    "Select Stages for Importance Analysis:",
                    list(viz_data.keys()),
                    default=list(viz_data.keys())
                )
                
                importance_method = st.selectbox(
                    "Analysis Method:",
                    ["variance", "range", "stage_separation"],
                    help="Variance: high variation wavelengths, Range: large intensity differences, Stage separation: best for distinguishing stages"
                )
                
                if st.button("Analyze Wavelength Importance"):
                    if len(importance_stages) > 1:
                        with st.spinner("Analyzing wavelength importance..."):
                            importance_result = enh_viz.plot_wavelength_importance(
                                viz_data, importance_stages, importance_method
                            )
                            if importance_result:
                                importance_fig, importance_scores = importance_result
                                st.plotly_chart(importance_fig, use_container_width=True)
                                
                                # Show top wavelengths
                                st.write("#### Top 10 Most Important Wavelengths")
                                top_wavelengths = list(importance_scores.items())[:10]
                                top_df = pd.DataFrame(top_wavelengths, columns=['Wavelength', 'Importance Score'])
                                st.dataframe(top_df)
                    else:
                        st.warning("Please select at least 2 stages for importance analysis.")
            
            # Information about advanced visualizations
            with st.expander("About Advanced Visualizations"):
                st.write("""
                **Basic Advanced Visualizations:**
                - **3D Spectral Waterfall:** Multiple spectra displayed in 3D space
                - **Correlation Matrix:** Relationships between different files and stages
                - **PCA Analysis:** Dimensionality reduction to identify main variation sources
                - **t-SNE Analysis:** Non-linear dimensionality reduction for pattern discovery
                - **Spectral Derivatives:** Mathematical derivatives to emphasize features
                - **Peak Analysis:** Detection and analysis of prominent spectral peaks
                - **Spectral Evolution:** Track changes across contamination stages
                - **Distribution Heatmap:** Comprehensive intensity distribution view
                - **Density Plot:** 2D density visualization of data patterns
                
                **Enhanced Visualizations:**
                - **Interactive Animated Comparison:** Watch spectra animate with play controls
                - **Spectral Clustering Analysis:** Discover hidden patterns through grouping
                - **Advanced Interpolated Heatmap:** High-resolution heatmap with smooth interpolation
                - **Dynamic Range Analysis:** Signal quality metrics and statistical analysis
                - **Spectral Fingerprints:** Unique polar visualizations of spectral signatures
                - **Wavelength Importance Analysis:** Identify most discriminative wavelengths
                
                These techniques reveal insights that standard plots might miss and provide deeper understanding of contamination patterns.
                """)
        
        else:
            st.info("Please upload and process your spectral data first to use advanced visualizations.")
    
    with tab9:
        st.markdown("""
        <div class="analysis-section">
            <h2>🤖 AI Stage Prediction Simulator</h2>
            <p>Interactive machine learning system for predicting contamination stages with real-time analysis</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.organized_data is not None:
            # Initialize AI predictor in session state
            if 'ai_predictor' not in st.session_state:
                st.session_state.ai_predictor = ai_pred.AIStagePredictor()
            
            predictor = st.session_state.ai_predictor
            
            # Model Training Section
            st.write("### 🎯 Model Training & Setup")
            
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.write("#### Training Configuration")
                
                # Training parameters
                test_size = st.slider("Test Data Percentage", 10, 50, 30) / 100
                n_features = st.selectbox("Number of Spectral Features", [50, 100, 200, 500], index=1)
                
                # Wavelength range selection
                all_wavelengths = []
                for stage_data in st.session_state.organized_data.values():
                    for file_data in stage_data.values():
                        all_wavelengths.extend(file_data['wavelength'])
                
                min_wav = min(all_wavelengths)
                max_wav = max(all_wavelengths)
                
                wavelength_range = st.slider(
                    "Wavelength Range for Training",
                    float(min_wav), float(max_wav),
                    (float(min_wav), float(max_wav)),
                    step=1.0
                )
            
            with col2:
                st.write("#### Model Status")
                if predictor.is_trained:
                    st.success("✅ Models Trained")
                    summary = predictor.get_model_summary()
                    st.metric("Best Model", summary['best_model'])
                    st.metric("Feature Count", summary['feature_count'])
                else:
                    st.warning("⏳ Models Not Trained")
                
                # Train models button
                if st.button("🚀 Train AI Models", type="primary"):
                    with st.spinner("Training AI models... This may take a few minutes."):
                        try:
                            # Prepare training data
                            X, y, labels = predictor.prepare_training_data(
                                st.session_state.organized_data,
                                target_wavelength_range=wavelength_range,
                                n_features=n_features
                            )
                            
                            # Train models
                            performance = predictor.train_models(X, y, test_size=test_size)
                            
                            st.success("🎉 AI models trained successfully!")
                            
                            # Display training results
                            st.write("#### Training Results")
                            perf_df = pd.DataFrame({
                                'Model': list(performance.keys()),
                                'Test Accuracy': [p['accuracy'] for p in performance.values()],
                                'CV Score': [f"{p['cv_mean']:.3f} ± {p['cv_std']:.3f}" for p in performance.values()]
                            })
                            st.dataframe(perf_df)
                            
                        except Exception as e:
                            st.error(f"Training failed: {str(e)}")
            
            # Model Performance Section
            if predictor.is_trained:
                st.markdown("---")
                st.write("### 📊 Model Performance Analysis")
                
                # Model comparison
                comparison_fig = predictor.create_model_comparison_plot()
                if comparison_fig:
                    st.plotly_chart(comparison_fig, use_container_width=True)
                
                # Confusion matrix
                selected_model = st.selectbox(
                    "Select model for detailed analysis:",
                    list(predictor.models.keys())
                )
                
                col1, col2 = st.columns(2)
                
                with col1:
                    confusion_fig = predictor.create_confusion_matrix_plot(selected_model)
                    if confusion_fig:
                        st.plotly_chart(confusion_fig, use_container_width=True)
                
                with col2:
                    # Feature importance analysis
                    importance_analysis = predictor.get_feature_importance_analysis(selected_model)
                    if importance_analysis:
                        st.write("#### Most Important Wavelengths")
                        importance_df = pd.DataFrame({
                            'Wavelength': importance_analysis['wavelengths'][:10],
                            'Importance': importance_analysis['importance_scores'][:10]
                        })
                        st.dataframe(importance_df)
                
                # Interactive Prediction Section
                st.markdown("---")
                st.write("### 🎮 Interactive Stage Prediction")
                
                # Select spectrum for prediction
                prediction_stage = st.selectbox(
                    "Select stage for prediction test:",
                    list(st.session_state.organized_data.keys())
                )
                
                available_files = list(st.session_state.organized_data[prediction_stage].keys())
                prediction_file = st.selectbox(
                    "Select file for prediction:",
                    available_files
                )
                
                if st.button("🔮 Predict Stage", type="secondary"):
                    spectrum_data = st.session_state.organized_data[prediction_stage][prediction_file]
                    
                    try:
                        # Create prediction visualization
                        pred_fig, prediction, probabilities = predictor.create_prediction_visualization(
                            spectrum_data, selected_model
                        )
                        
                        # Display results
                        col1, col2, col3 = st.columns(3)
                        col1.metric("Actual Stage", prediction_stage)
                        col2.metric("Predicted Stage", prediction)
                        col3.metric("Confidence", f"{max(probabilities.values()):.1%}")
                        
                        # Show prediction accuracy
                        if prediction == prediction_stage:
                            st.success("✅ Correct Prediction!")
                        else:
                            st.error("❌ Incorrect Prediction")
                        
                        # Display visualization
                        st.plotly_chart(pred_fig, use_container_width=True)
                        
                        # Probability breakdown
                        st.write("#### Prediction Probabilities")
                        prob_df = pd.DataFrame({
                            'Stage': list(probabilities.keys()),
                            'Probability': [f"{p:.1%}" for p in probabilities.values()]
                        })
                        st.dataframe(prob_df, use_container_width=True)
                        
                    except Exception as e:
                        st.error(f"Prediction failed: {str(e)}")
                
                # Interactive Simulation Section
                st.markdown("---")
                st.write("### 🧪 Contamination Simulation")
                
                st.write("""
                Simulate how spectral modifications affect stage predictions. 
                Adjust parameters to see how the AI model responds to different contamination scenarios.
                """)
                
                # Simulation controls
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    intensity_scale = st.slider("Intensity Scale Factor", 0.5, 2.0, 1.0, 0.1)
                
                with col2:
                    noise_level = st.slider("Noise Level", 0.0, 0.5, 0.0, 0.05)
                
                with col3:
                    wavelength_shift = st.slider("Wavelength Shift", -10.0, 10.0, 0.0, 1.0)
                
                if st.button("🔬 Run Simulation", type="secondary"):
                    # Use clean spectrum (stage 0 if available)
                    base_stage = 0 if 0 in st.session_state.organized_data else list(st.session_state.organized_data.keys())[0]
                    base_file = list(st.session_state.organized_data[base_stage].keys())[0]
                    base_spectrum = st.session_state.organized_data[base_stage][base_file]
                    
                    # Create modification parameters
                    modifications = [{
                        'intensity_scale': intensity_scale,
                        'noise_level': noise_level,
                        'wavelength_shift': wavelength_shift
                    }]
                    
                    try:
                        # Run simulation
                        results = predictor.simulate_interactive_prediction(base_spectrum, modifications)
                        
                        if results:
                            result = results[0]
                            
                            # Show simulation results
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.metric("Original Stage", base_stage)
                                st.metric("Simulated Prediction", result['prediction'])
                                
                                max_prob = max(result['probabilities'].values())
                                st.metric("Prediction Confidence", f"{max_prob:.1%}")
                            
                            with col2:
                                # Create prediction visualization for simulated spectrum
                                sim_fig, _, _ = predictor.create_prediction_visualization(
                                    result['spectrum'], selected_model
                                )
                                st.plotly_chart(sim_fig, use_container_width=True)
                    
                    except Exception as e:
                        st.error(f"Simulation failed: {str(e)}")
                
                # Model Insights Section
                with st.expander("🧠 AI Model Insights"):
                    st.markdown("""
                    **How the AI Stage Predictor Works:**
                    
                    - **Random Forest**: Uses ensemble of decision trees, robust to noise
                    - **Gradient Boosting**: Sequential learning, excellent for complex patterns
                    - **Neural Network**: Deep learning approach, captures non-linear relationships
                    - **SVM**: Support Vector Machine, effective for high-dimensional data
                    
                    **Prediction Confidence:**
                    - High confidence (>90%): Strong spectral signature
                    - Medium confidence (70-90%): Moderate indicators
                    - Low confidence (<70%): Unclear or transitional spectra
                    
                    **Feature Importance:**
                    - Shows which wavelengths are most critical for classification
                    - Higher importance = more discriminative for stage identification
                    - Use for targeted monitoring and quality control
                    """)
            
            else:
                st.info("Please train the AI models first to use prediction and simulation features.")
        
        else:
            st.info("Please upload and process your spectral data first to use the AI prediction simulator.")
    
    with tab10:
        st.markdown("""
        <div class="analysis-section">
            <h2>🔍 Peak Detection & Analysis</h2>
            <p>Advanced spectral peak identification and comprehensive feature analysis across contamination stages</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.organized_data is not None:
            # Initialize peak analyzer in session state
            if 'peak_analyzer' not in st.session_state:
                st.session_state.peak_analyzer = peak_analyzer.SpectralPeakAnalyzer()
            
            analyzer = st.session_state.peak_analyzer
            
            # Peak Detection Configuration
            st.write("### 🎯 Peak Detection Configuration")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                prominence = st.slider("Peak Prominence", 0.01, 1.0, 0.1, 0.01, 
                                     help="Minimum prominence required for peak detection")
            
            with col2:
                width = st.slider("Minimum Peak Width", 1, 20, 2, 1,
                                help="Minimum width in data points for peak detection")
            
            with col3:
                distance = st.slider("Minimum Distance", 1, 50, 5, 1,
                                   help="Minimum distance between peaks in data points")
            
            # Single Spectrum Peak Analysis
            st.markdown("---")
            st.write("### 🔬 Single Spectrum Peak Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                analysis_stage = st.selectbox(
                    "Select stage for peak analysis:",
                    list(st.session_state.organized_data.keys()),
                    key="peak_analysis_stage"
                )
            
            with col2:
                available_files = list(st.session_state.organized_data[analysis_stage].keys())
                analysis_file = st.selectbox(
                    "Select file for peak analysis:",
                    available_files,
                    key="peak_analysis_file"
                )
            
            if st.button("🔍 Analyze Peaks in Selected Spectrum", type="primary"):
                with st.spinner("Detecting and analyzing peaks..."):
                    try:
                        # Get spectrum data
                        spectrum_data = st.session_state.organized_data[analysis_stage][analysis_file]
                        wavelength = spectrum_data['wavelength']
                        intensity = spectrum_data['intensity']
                        
                        # Analyze peaks
                        spectrum_id = f"Stage_{analysis_stage}_File_{analysis_file}"
                        properties_df = analyzer.analyze_spectrum_peaks(
                            wavelength, intensity, spectrum_id, prominence, width
                        )
                        
                        if not properties_df.empty:
                            # Display results
                            st.success(f"✅ Found {len(properties_df)} peaks!")
                            
                            # Create peak detection visualization
                            peak_info = analyzer.peak_data[spectrum_id]['peak_info']
                            detection_fig = analyzer.create_peak_detection_plot(
                                wavelength, intensity, peak_info,
                                f"Peak Detection - Stage {analysis_stage}, File {analysis_file}"
                            )
                            st.plotly_chart(detection_fig, use_container_width=True)
                            
                            # Display peak properties table
                            st.write("#### 📊 Peak Properties")
                            
                            # Format the dataframe for better display
                            display_df = properties_df.copy()
                            display_df['wavelength'] = display_df['wavelength'].round(2)
                            display_df['intensity'] = display_df['intensity'].round(4)
                            display_df['fwhm'] = display_df['fwhm'].round(2)
                            display_df['area'] = display_df['area'].round(2)
                            display_df['snr'] = display_df['snr'].round(2)
                            display_df['prominence'] = display_df['prominence'].round(4)
                            
                            st.dataframe(display_df, use_container_width=True)
                            
                            # Peak statistics summary
                            col1, col2, col3, col4 = st.columns(4)
                            col1.metric("Total Peaks", len(properties_df))
                            col2.metric("Avg Intensity", f"{properties_df['intensity'].mean():.4f}")
                            col3.metric("Avg FWHM", f"{properties_df['fwhm'].mean():.2f}")
                            col4.metric("Avg SNR", f"{properties_df['snr'].mean():.2f}")
                        
                        else:
                            st.warning("No peaks detected with current parameters. Try adjusting the detection settings.")
                    
                    except Exception as e:
                        st.error(f"Peak analysis failed: {str(e)}")
            
            # Multi-Stage Peak Comparison
            st.markdown("---")
            st.write("### 📈 Multi-Stage Peak Comparison")
            
            if st.button("🚀 Analyze Peaks Across All Stages", type="secondary"):
                with st.spinner("Analyzing peaks across all stages... This may take a few minutes."):
                    try:
                        # Perform comprehensive peak analysis
                        stage_peak_data = analyzer.compare_peaks_across_stages(
                            st.session_state.organized_data, prominence, width
                        )
                        
                        # Calculate statistics
                        stage_stats = analyzer.calculate_stage_peak_statistics(stage_peak_data)
                        
                        # Identify persistent peaks
                        persistent_peaks = analyzer.identify_persistent_peaks(stage_peak_data)
                        
                        # Track peak evolution
                        peak_trends = analyzer.track_peak_evolution(stage_peak_data, persistent_peaks)
                        
                        st.success("✅ Multi-stage peak analysis completed!")
                        
                        # Display stage comparison plot
                        comparison_fig = analyzer.create_peak_comparison_plot(stage_stats)
                        if comparison_fig:
                            st.plotly_chart(comparison_fig, use_container_width=True)
                        
                        # Display persistent peaks
                        if not persistent_peaks.empty:
                            st.write("#### 🎯 Persistent Peaks (Across Multiple Stages)")
                            
                            # Format persistent peaks for display
                            display_persistent = persistent_peaks.copy()
                            display_persistent['avg_wavelength'] = display_persistent['avg_wavelength'].round(2)
                            display_persistent['wavelength_std'] = display_persistent['wavelength_std'].round(3)
                            display_persistent['occurrence_rate'] = (display_persistent['occurrence_rate'] * 100).round(1)
                            
                            # Rename columns for better display
                            display_persistent = display_persistent.rename(columns={
                                'avg_wavelength': 'Wavelength (nm)',
                                'wavelength_std': 'Wavelength Std',
                                'occurrence_count': 'Occurrences',
                                'occurrence_rate': 'Occurrence Rate (%)',
                                'cluster_size': 'Cluster Size'
                            })
                            
                            st.dataframe(display_persistent, use_container_width=True)
                        
                        # Peak evolution plot
                        if peak_trends:
                            evolution_fig = analyzer.create_peak_evolution_plot(peak_trends)
                            if evolution_fig:
                                st.write("#### 📊 Peak Evolution Across Stages")
                                st.plotly_chart(evolution_fig, use_container_width=True)
                        
                        # Peak distribution heatmap
                        heatmap_fig = analyzer.create_peak_heatmap(stage_peak_data)
                        if heatmap_fig:
                            st.write("#### 🌡️ Peak Distribution Heatmap")
                            st.plotly_chart(heatmap_fig, use_container_width=True)
                        
                        # Stage-by-stage statistics
                        st.write("#### 📋 Stage-by-Stage Peak Statistics")
                        
                        stats_data = []
                        for stage, stats in stage_stats.items():
                            stage_info = stats['statistics']
                            stats_data.append({
                                'Stage': stage,
                                'Total Peaks': stage_info['total_peaks'],
                                'Avg Peaks/File': f"{stage_info['avg_peaks_per_file']:.1f}",
                                'Avg Intensity': f"{stage_info['avg_intensity']:.4f}",
                                'Avg FWHM': f"{stage_info['avg_fwhm']:.2f}",
                                'Avg SNR': f"{stage_info['avg_snr']:.2f}",
                                'Wavelength Range': f"{stage_info['peak_wavelength_range'][0]:.1f} - {stage_info['peak_wavelength_range'][1]:.1f}"
                            })
                        
                        stats_df = pd.DataFrame(stats_data)
                        st.dataframe(stats_df, use_container_width=True)
                        
                        # Store results in session state for further analysis
                        st.session_state.peak_analysis_results = {
                            'stage_peak_data': stage_peak_data,
                            'stage_stats': stage_stats,
                            'persistent_peaks': persistent_peaks,
                            'peak_trends': peak_trends
                        }
                    
                    except Exception as e:
                        st.error(f"Multi-stage peak analysis failed: {str(e)}")
            
            # Peak Analysis Summary Report
            if 'peak_analysis_results' in st.session_state:
                st.markdown("---")
                st.write("### 📄 Peak Analysis Summary Report")
                
                if st.button("📋 Generate Peak Analysis Report"):
                    try:
                        report = analyzer.generate_peak_report(
                            st.session_state.organized_data, prominence, width
                        )
                        
                        # Display text summary
                        st.write("#### Executive Summary")
                        st.text(report['summary'])
                        
                        # Show key findings
                        st.write("#### Key Findings")
                        
                        total_peaks = sum(
                            stats['statistics']['total_peaks'] 
                            for stats in report['stage_statistics'].values()
                        )
                        
                        persistent_count = len(report['persistent_peaks'])
                        
                        col1, col2, col3 = st.columns(3)
                        col1.metric("Total Peaks Detected", total_peaks)
                        col2.metric("Persistent Peaks", persistent_count)
                        col3.metric("Stages Analyzed", len(report['stage_statistics']))
                        
                        # Download report data
                        st.write("#### 💾 Export Peak Analysis Data")
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            if st.button("📊 Download Detailed Peak Data (CSV)"):
                                # Create comprehensive CSV export
                                import io
                                
                                # Combine all peak data from all stages
                                all_peaks_data = []
                                
                                for stage, stage_results in report['stage_peak_data'].items():
                                    for file_num, properties_df in stage_results.items():
                                        if not properties_df.empty:
                                            # Add stage and file information
                                            properties_df_copy = properties_df.copy()
                                            properties_df_copy['stage'] = stage
                                            properties_df_copy['file_number'] = file_num
                                            properties_df_copy['spectrum_id'] = f"Stage_{stage}_File_{file_num}"
                                            all_peaks_data.append(properties_df_copy)
                                
                                if all_peaks_data:
                                    combined_peaks = pd.concat(all_peaks_data, ignore_index=True)
                                    
                                    # Reorder columns for better readability
                                    column_order = ['spectrum_id', 'stage', 'file_number', 'wavelength', 'intensity', 
                                                  'fwhm', 'area', 'prominence', 'snr', 'asymmetry', 'sharpness',
                                                  'left_base', 'right_base', 'peak_index']
                                    combined_peaks = combined_peaks[column_order]
                                    
                                    # Create CSV
                                    csv_buffer = io.StringIO()
                                    combined_peaks.to_csv(csv_buffer, index=False, float_format='%.6f')
                                    
                                    st.download_button(
                                        label="📄 Download Complete Peak Analysis (CSV)",
                                        data=csv_buffer.getvalue(),
                                        file_name=f"complete_peak_analysis_{len(combined_peaks)}_peaks.csv",
                                        mime="text/csv"
                                    )
                                    
                                    st.success(f"✅ Prepared {len(combined_peaks)} peaks from {len(all_peaks_data)} spectra for download")
                                else:
                                    st.warning("No peak data available for export")
                        
                        with col2:
                            if st.button("📈 Download Peak Statistics (CSV)"):
                                # Create stage statistics export
                                import io
                                
                                # Prepare stage statistics data
                                stats_export_data = []
                                for stage, stats in report['stage_statistics'].items():
                                    stage_info = stats['statistics']
                                    stats_export_data.append({
                                        'Stage': stage,
                                        'Total_Peaks': stage_info['total_peaks'],
                                        'Avg_Peaks_Per_File': stage_info['avg_peaks_per_file'],
                                        'Min_Wavelength': stage_info['peak_wavelength_range'][0],
                                        'Max_Wavelength': stage_info['peak_wavelength_range'][1],
                                        'Avg_Intensity': stage_info['avg_intensity'],
                                        'Intensity_Std': stage_info['intensity_std'],
                                        'Avg_FWHM': stage_info['avg_fwhm'],
                                        'Avg_Area': stage_info['avg_area'],
                                        'Avg_Prominence': stage_info['avg_prominence'],
                                        'Avg_SNR': stage_info['avg_snr'],
                                        'Wavelength_Std': stage_info['wavelength_std']
                                    })
                                
                                stats_df = pd.DataFrame(stats_export_data)
                                
                                # Create CSV
                                csv_buffer = io.StringIO()
                                stats_df.to_csv(csv_buffer, index=False, float_format='%.6f')
                                
                                st.download_button(
                                    label="📊 Download Stage Statistics (CSV)",
                                    data=csv_buffer.getvalue(),
                                    file_name="peak_stage_statistics.csv",
                                    mime="text/csv"
                                )
                        
                        # Persistent peaks export
                        if not report['persistent_peaks'].empty:
                            st.write("##### 🎯 Persistent Peaks Export")
                            
                            # Create persistent peaks CSV
                            csv_buffer = io.StringIO()
                            persistent_export = report['persistent_peaks'].copy()
                            persistent_export.to_csv(csv_buffer, index=False, float_format='%.6f')
                            
                            st.download_button(
                                label="🔗 Download Persistent Peaks (CSV)",
                                data=csv_buffer.getvalue(),
                                file_name="persistent_peaks_analysis.csv",
                                mime="text/csv"
                            )
                        
                        # Excel export (comprehensive workbook)
                        st.write("##### 📗 Excel Export (All Data)")
                        
                        if st.button("📗 Generate Excel Workbook", type="secondary"):
                            try:
                                # Create Excel workbook with multiple sheets
                                import io
                                from io import BytesIO
                                
                                # Create Excel buffer
                                excel_buffer = BytesIO()
                                
                                with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                                    # Sheet 1: All peak data
                                    all_peaks_data = []
                                    for stage, stage_results in report['stage_peak_data'].items():
                                        for file_num, properties_df in stage_results.items():
                                            if not properties_df.empty:
                                                properties_df_copy = properties_df.copy()
                                                properties_df_copy['stage'] = stage
                                                properties_df_copy['file_number'] = file_num
                                                properties_df_copy['spectrum_id'] = f"Stage_{stage}_File_{file_num}"
                                                all_peaks_data.append(properties_df_copy)
                                    
                                    if all_peaks_data:
                                        combined_peaks = pd.concat(all_peaks_data, ignore_index=True)
                                        column_order = ['spectrum_id', 'stage', 'file_number', 'wavelength', 'intensity', 
                                                      'fwhm', 'area', 'prominence', 'snr', 'asymmetry', 'sharpness',
                                                      'left_base', 'right_base', 'peak_index']
                                        combined_peaks = combined_peaks[column_order]
                                        combined_peaks.to_excel(writer, sheet_name='All_Peaks', index=False)
                                    
                                    # Sheet 2: Stage statistics
                                    stats_export_data = []
                                    for stage, stats in report['stage_statistics'].items():
                                        stage_info = stats['statistics']
                                        stats_export_data.append({
                                            'Stage': stage,
                                            'Total_Peaks': stage_info['total_peaks'],
                                            'Avg_Peaks_Per_File': stage_info['avg_peaks_per_file'],
                                            'Min_Wavelength': stage_info['peak_wavelength_range'][0],
                                            'Max_Wavelength': stage_info['peak_wavelength_range'][1],
                                            'Avg_Intensity': stage_info['avg_intensity'],
                                            'Intensity_Std': stage_info['intensity_std'],
                                            'Avg_FWHM': stage_info['avg_fwhm'],
                                            'Avg_Area': stage_info['avg_area'],
                                            'Avg_Prominence': stage_info['avg_prominence'],
                                            'Avg_SNR': stage_info['avg_snr'],
                                            'Wavelength_Std': stage_info['wavelength_std']
                                        })
                                    
                                    stats_df = pd.DataFrame(stats_export_data)
                                    stats_df.to_excel(writer, sheet_name='Stage_Statistics', index=False)
                                    
                                    # Sheet 3: Persistent peaks
                                    if not report['persistent_peaks'].empty:
                                        persistent_export = report['persistent_peaks'].copy()
                                        persistent_export.to_excel(writer, sheet_name='Persistent_Peaks', index=False)
                                    
                                    # Sheet 4: Peak evolution data
                                    if report['peak_trends']:
                                        evolution_data = []
                                        for wavelength, evolution in report['peak_trends'].items():
                                            for stage, stage_data in evolution.items():
                                                evolution_data.append({
                                                    'Peak_Wavelength': wavelength,
                                                    'Stage': stage,
                                                    'Avg_Intensity': stage_data['avg_intensity'],
                                                    'Std_Intensity': stage_data['std_intensity'],
                                                    'Avg_Area': stage_data['avg_area'],
                                                    'Avg_FWHM': stage_data['avg_fwhm'],
                                                    'Detection_Rate': stage_data['detection_rate']
                                                })
                                        
                                        evolution_df = pd.DataFrame(evolution_data)
                                        evolution_df.to_excel(writer, sheet_name='Peak_Evolution', index=False)
                                
                                excel_buffer.seek(0)
                                
                                st.download_button(
                                    label="📗 Download Complete Excel Workbook",
                                    data=excel_buffer.getvalue(),
                                    file_name="peak_analysis_complete_workbook.xlsx",
                                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                )
                                
                                st.success("✅ Excel workbook with multiple sheets created successfully!")
                                
                            except Exception as e:
                                st.error(f"Excel export failed: {str(e)}")
                                st.info("Note: Excel export requires openpyxl package. CSV exports are still available.")
                    
                    except Exception as e:
                        st.error(f"Report generation failed: {str(e)}")
            
            # Peak Analysis Insights
            with st.expander("🧠 Peak Analysis Insights"):
                st.markdown("""
                **Peak Detection Parameters:**
                
                - **Prominence**: How much a peak stands out from surrounding baseline
                - **Width**: Minimum width required for peak detection
                - **Distance**: Minimum separation between detected peaks
                
                **Peak Properties Explained:**
                
                - **FWHM**: Full Width at Half Maximum - measure of peak sharpness
                - **Area**: Integrated area under the peak - related to concentration
                - **SNR**: Signal-to-Noise Ratio - peak quality indicator
                - **Asymmetry**: Peak shape asymmetry factor
                
                **Analysis Applications:**
                
                - **Quality Control**: Monitor peak characteristics for consistency
                - **Contamination Detection**: Track peak changes across stages
                - **Feature Identification**: Identify characteristic spectral signatures
                - **Trend Analysis**: Monitor how contamination affects peak properties
                
                **Interpretation Guidelines:**
                
                - High occurrence rate peaks (>70%) indicate stable spectral features
                - Decreasing peak intensity may indicate signal degradation
                - Peak shifts can indicate chemical changes or instrument drift
                - New peaks appearing in later stages may indicate contamination products
                """)
        
        else:
            st.info("Please upload and process your spectral data first to use peak detection and analysis.")
    
    with tab11:
        st.markdown("""
        <div class="analysis-section">
            <h2>⚡ Batch Processing for Large Datasets</h2>
            <p>Efficient parallel processing with progress tracking for handling large spectral datasets</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.organized_data is not None:
            # Initialize batch processor in session state
            if 'batch_processor' not in st.session_state:
                st.session_state.batch_processor = batch_proc.BatchProcessor()
            
            processor = st.session_state.batch_processor
            
            # Dataset Overview
            st.write("### 📊 Dataset Overview")
            
            total_stages = len(st.session_state.organized_data)
            total_files = sum(len(stage_data) for stage_data in st.session_state.organized_data.values())
            
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Total Stages", total_stages)
            col2.metric("Total Files", total_files)
            col3.metric("Batch Size", processor.batch_size)
            col4.metric("Max Workers", processor.max_workers)
            
            # Processing Configuration
            st.markdown("---")
            st.write("### ⚙️ Processing Configuration")
            
            col1, col2 = st.columns(2)
            
            with col1:
                batch_size = st.slider("Batch Size", 1, 50, processor.batch_size, 1,
                                     help="Number of files to process simultaneously in each batch")
                
                max_workers = st.slider("Max Workers", 1, 8, processor.max_workers, 1,
                                      help="Maximum number of parallel processing threads")
            
            with col2:
                # Processing time estimation
                time_estimate = processor.estimate_processing_time(st.session_state.organized_data)
                
                st.write("#### ⏱️ Processing Time Estimate")
                st.metric("Estimated Time", f"{time_estimate['estimated_minutes']:.1f} minutes")
                st.metric("Files to Process", time_estimate['total_files'])
                st.write(f"Using {time_estimate['parallel_workers']} parallel workers")
            
            # Update processor configuration
            processor.set_batch_size(batch_size)
            processor.set_max_workers(max_workers)
            
            # Batch Processing Options
            st.markdown("---")
            st.write("### 🚀 Batch Processing Operations")
            
            # Progress tracking
            progress_placeholder = st.empty()
            status_placeholder = st.empty()
            
            def update_progress(message):
                """Update progress display"""
                progress_placeholder.info(message)
            
            # Peak Analysis Batch Processing
            st.write("#### 🔍 Batch Peak Analysis")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                peak_prominence = st.slider("Peak Prominence", 0.01, 1.0, 0.1, 0.01, key="batch_prominence")
            
            with col2:
                peak_width = st.slider("Peak Width", 1, 20, 2, 1, key="batch_width")
            
            with col3:
                if st.button("🚀 Run Batch Peak Analysis", type="primary"):
                    if 'peak_analyzer' not in st.session_state:
                        st.session_state.peak_analyzer = peak_analyzer.SpectralPeakAnalyzer()
                    
                    with st.spinner("Running batch peak analysis..."):
                        try:
                            start_time = time.time()
                            
                            # Run batch peak analysis
                            results = processor.batch_peak_analysis(
                                st.session_state.organized_data,
                                st.session_state.peak_analyzer,
                                prominence=peak_prominence,
                                width=peak_width,
                                progress_callback=update_progress
                            )
                            
                            processing_time = time.time() - start_time
                            
                            # Display results
                            st.success(f"✅ Batch peak analysis completed in {processing_time:.1f} seconds!")
                            
                            # Show processing statistics
                            overall_stats = results['overall_stats']
                            
                            col1, col2, col3, col4 = st.columns(4)
                            col1.metric("Total Files", overall_stats['total_files'])
                            col2.metric("Successful", overall_stats['successful'])
                            col3.metric("Failed", overall_stats['failed'])
                            col4.metric("Success Rate", f"{overall_stats['success_rate']:.1%}")
                            
                            # Create summary table
                            summary_df = processor.create_processing_summary(results)
                            st.write("#### Processing Summary by Stage")
                            st.dataframe(summary_df, use_container_width=True)
                            
                            # Store results for export
                            st.session_state.batch_peak_results = results
                            
                        except Exception as e:
                            st.error(f"Batch peak analysis failed: {str(e)}")
            
            # Statistical Analysis Batch Processing
            st.write("#### 📊 Batch Statistical Analysis")
            
            if st.button("📈 Run Batch Statistical Analysis", type="secondary"):
                with st.spinner("Running batch statistical analysis..."):
                    try:
                        start_time = time.time()
                        
                        # Run batch statistical analysis
                        results = processor.batch_statistical_analysis(
                            st.session_state.organized_data,
                            None,  # stats_analyzer not needed for basic stats
                            progress_callback=update_progress
                        )
                        
                        processing_time = time.time() - start_time
                        
                        # Display results
                        st.success(f"✅ Batch statistical analysis completed in {processing_time:.1f} seconds!")
                        
                        # Show processing statistics
                        overall_stats = results['overall_stats']
                        
                        col1, col2, col3, col4 = st.columns(4)
                        col1.metric("Total Files", overall_stats['total_files'])
                        col2.metric("Successful", overall_stats['successful'])
                        col3.metric("Failed", overall_stats['failed'])
                        col4.metric("Success Rate", f"{overall_stats['success_rate']:.1%}")
                        
                        # Create summary table
                        summary_df = processor.create_processing_summary(results)
                        st.write("#### Processing Summary by Stage")
                        st.dataframe(summary_df, use_container_width=True)
                        
                        # Store results for export
                        st.session_state.batch_stats_results = results
                        
                    except Exception as e:
                        st.error(f"Batch statistical analysis failed: {str(e)}")
            
            # Anomaly Detection Batch Processing
            st.write("#### 🔍 Batch Anomaly Detection")
            
            col1, col2 = st.columns(2)
            
            with col1:
                contamination_level = st.slider("Contamination Level", 0.01, 0.5, 0.1, 0.01,
                                               help="Expected proportion of anomalies in the dataset")
            
            with col2:
                if st.button("🔎 Run Batch Anomaly Detection"):
                    with st.spinner("Running batch anomaly detection..."):
                        try:
                            start_time = time.time()
                            
                            # Run batch anomaly detection
                            results = processor.batch_anomaly_detection(
                                st.session_state.organized_data,
                                None,  # anomaly_detector not needed for basic detection
                                contamination=contamination_level,
                                progress_callback=update_progress
                            )
                            
                            processing_time = time.time() - start_time
                            
                            # Display results
                            st.success(f"✅ Batch anomaly detection completed in {processing_time:.1f} seconds!")
                            
                            # Show processing statistics
                            overall_stats = results['overall_stats']
                            
                            col1, col2, col3, col4 = st.columns(4)
                            col1.metric("Total Files", overall_stats['total_files'])
                            col2.metric("Successful", overall_stats['successful'])
                            col3.metric("Failed", overall_stats['failed'])
                            col4.metric("Success Rate", f"{overall_stats['success_rate']:.1%}")
                            
                            # Create summary table
                            summary_df = processor.create_processing_summary(results)
                            st.write("#### Processing Summary by Stage")
                            st.dataframe(summary_df, use_container_width=True)
                            
                            # Store results for export
                            st.session_state.batch_anomaly_results = results
                            
                        except Exception as e:
                            st.error(f"Batch anomaly detection failed: {str(e)}")
            
            # Data Preprocessing Batch Processing
            st.write("#### 🔧 Batch Data Preprocessing")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("##### Normalization Options")
                enable_normalization = st.checkbox("Enable Normalization")
                if enable_normalization:
                    norm_method = st.selectbox("Normalization Method", 
                                             ["min_max", "z_score"], 
                                             help="min_max: scales to [0,1], z_score: standardizes to mean=0, std=1")
            
            with col2:
                st.write("##### Smoothing Options")
                enable_smoothing = st.checkbox("Enable Smoothing")
                if enable_smoothing:
                    smooth_window = st.slider("Smoothing Window", 3, 21, 11, 2)
                    smooth_polyorder = st.slider("Polynomial Order", 1, 5, 3, 1)
            
            if st.button("🔧 Run Batch Preprocessing"):
                preprocessing_params = {
                    'normalize': enable_normalization,
                    'norm_method': norm_method if enable_normalization else 'min_max',
                    'smooth': enable_smoothing,
                    'window_length': smooth_window if enable_smoothing else 11,
                    'polyorder': smooth_polyorder if enable_smoothing else 3
                }
                
                with st.spinner("Running batch preprocessing..."):
                    try:
                        start_time = time.time()
                        
                        # Run batch preprocessing
                        results = processor.batch_preprocessing(
                            st.session_state.organized_data,
                            preprocessing_params,
                            progress_callback=update_progress
                        )
                        
                        processing_time = time.time() - start_time
                        
                        # Display results
                        st.success(f"✅ Batch preprocessing completed in {processing_time:.1f} seconds!")
                        
                        # Show processing statistics
                        overall_stats = results['overall_stats']
                        
                        col1, col2, col3, col4 = st.columns(4)
                        col1.metric("Total Files", overall_stats['total_files'])
                        col2.metric("Successful", overall_stats['successful'])
                        col3.metric("Failed", overall_stats['failed'])
                        col4.metric("Success Rate", f"{overall_stats['success_rate']:.1%}")
                        
                        # Store results for export
                        st.session_state.batch_preprocessing_results = results
                        
                    except Exception as e:
                        st.error(f"Batch preprocessing failed: {str(e)}")
            
            # Export Batch Results
            st.markdown("---")
            st.write("### 💾 Export Batch Processing Results")
            
            export_options = []
            if 'batch_peak_results' in st.session_state:
                export_options.append("Peak Analysis Results")
            if 'batch_stats_results' in st.session_state:
                export_options.append("Statistical Analysis Results")
            if 'batch_anomaly_results' in st.session_state:
                export_options.append("Anomaly Detection Results")
            if 'batch_preprocessing_results' in st.session_state:
                export_options.append("Preprocessing Results")
            
            if export_options:
                selected_export = st.selectbox("Select results to export:", export_options)
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("📄 Export as CSV"):
                        try:
                            # Determine which results to export
                            if selected_export == "Peak Analysis Results":
                                results = st.session_state.batch_peak_results
                            elif selected_export == "Statistical Analysis Results":
                                results = st.session_state.batch_stats_results
                            elif selected_export == "Anomaly Detection Results":
                                results = st.session_state.batch_anomaly_results
                            elif selected_export == "Preprocessing Results":
                                results = st.session_state.batch_preprocessing_results
                            
                            # Create CSV export
                            import io
                            summary_df = processor.create_processing_summary(results)
                            csv_buffer = io.StringIO()
                            summary_df.to_csv(csv_buffer, index=False)
                            
                            st.download_button(
                                label="📄 Download Processing Summary (CSV)",
                                data=csv_buffer.getvalue(),
                                file_name=f"batch_{selected_export.lower().replace(' ', '_')}_summary.csv",
                                mime="text/csv"
                            )
                            
                        except Exception as e:
                            st.error(f"CSV export failed: {str(e)}")
                
                with col2:
                    if st.button("📗 Export as Excel"):
                        try:
                            # Determine which results to export
                            if selected_export == "Peak Analysis Results":
                                results = st.session_state.batch_peak_results
                            elif selected_export == "Statistical Analysis Results":
                                results = st.session_state.batch_stats_results
                            elif selected_export == "Anomaly Detection Results":
                                results = st.session_state.batch_anomaly_results
                            elif selected_export == "Preprocessing Results":
                                results = st.session_state.batch_preprocessing_results
                            
                            # Create Excel export
                            from io import BytesIO
                            excel_buffer = BytesIO()
                            
                            success = processor.save_batch_results(
                                results, 
                                excel_buffer, 
                                'excel'
                            )
                            
                            if success:
                                st.download_button(
                                    label="📗 Download Complete Results (Excel)",
                                    data=excel_buffer.getvalue(),
                                    file_name=f"batch_{selected_export.lower().replace(' ', '_')}_complete.xlsx",
                                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                )
                            else:
                                st.error("Excel export failed")
                            
                        except Exception as e:
                            st.error(f"Excel export failed: {str(e)}")
            
            else:
                st.info("Run batch processing operations first to generate exportable results.")
            
            # Performance Insights
            with st.expander("🚀 Batch Processing Insights"):
                st.markdown("""
                **Performance Optimization:**
                
                - **Batch Size**: Larger batches use more memory but may be faster
                - **Max Workers**: More workers increase parallelism but consume more CPU
                - **Memory Management**: Automatic garbage collection between batches
                - **Progress Tracking**: Real-time updates on processing status
                
                **Processing Types:**
                
                - **Peak Analysis**: Detect and analyze spectral peaks across all files
                - **Statistical Analysis**: Calculate basic statistics for each spectrum
                - **Anomaly Detection**: Identify unusual spectra based on intensity patterns
                - **Data Preprocessing**: Apply normalization and smoothing filters
                
                **Export Capabilities:**
                
                - **CSV Format**: Processing summaries and stage-by-stage results
                - **Excel Format**: Multi-sheet workbooks with detailed data
                - **Progress Reports**: Success rates and error tracking
                
                **Best Practices:**
                
                - Start with smaller batch sizes for large datasets
                - Monitor memory usage during processing
                - Use preprocessing for data cleaning before analysis
                - Export results regularly to avoid data loss
                """)
        
        else:
            st.info("Please upload and process your spectral data first to use batch processing features.")
    
    with tab12:
        st.markdown("""
        <div class="analysis-section">
            <h2>📊 Interactive Data Loading Progress</h2>
            <p>Real-time visualization of data processing steps with detailed progress tracking</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Initialize progress visualizer
        if 'progress_visualizer' not in st.session_state:
            st.session_state.progress_visualizer = prog_viz.InteractiveProgressVisualizer()
        
        progress_viz = st.session_state.progress_visualizer
        
        # Progress Demo Section
        st.write("### 🚀 Progress Visualization Demo")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔄 Start Data Processing Demo", type="primary"):
                # Simulate data loading process
                steps = [
                    "Initializing Upload",
                    "Validating File Format", 
                    "Reading CSV Files",
                    "Extracting Spectral Data",
                    "Organizing by Stages",
                    "Processing Wavelengths",
                    "Calculating Statistics",
                    "Generating Visualizations"
                ]
                
                progress_viz.initialize_progress(len(steps), steps)
                
                # Create progress containers
                dashboard_container = st.empty()
                chart_container = st.empty()
                timeline_container = st.empty()
                
                # Simulate processing with real-time updates
                for i, step in enumerate(steps):
                    step_start = time.time()
                    progress_viz.update_step(i, 'processing', f"Executing {step.lower()}...")
                    
                    # Update dashboard display
                    progress_viz.create_progress_dashboard(dashboard_container)
                    
                    # Simulate different processing times
                    if i == 0:  # Initialization
                        time.sleep(0.5)
                    elif i == 2:  # Reading files
                        # Simulate file processing
                        for file_num in range(1, 16):
                            progress_viz.update_file_progress(file_num, 15, 0)
                            time.sleep(0.1)
                        time.sleep(0.3)
                    elif i == 3:  # Extracting data
                        # Simulate data extraction with some errors
                        for file_num in range(1, 21):
                            errors = 1 if file_num == 13 else 0  # Simulate one error
                            progress_viz.update_file_progress(file_num, 20, errors)
                            time.sleep(0.08)
                        time.sleep(0.4)
                    else:
                        time.sleep(0.6)
                    
                    step_duration = time.time() - step_start
                    progress_viz.update_step(i, 'completed', f"Successfully completed {step.lower()}", step_duration)
                    
                    # Update displays
                    progress_viz.create_progress_dashboard(dashboard_container)
                    progress_viz.create_real_time_chart(chart_container)
                    progress_viz.create_step_timeline(timeline_container)
                
                progress_viz.finish_processing()
                
                # Final update
                progress_viz.create_progress_dashboard(dashboard_container)
                progress_viz.create_real_time_chart(chart_container) 
                progress_viz.create_step_timeline(timeline_container)
                
                # Show completion summary
                summary_container = st.container()
                progress_viz.create_progress_summary(summary_container)
        
        with col2:
            if st.button("⚡ Quick Progress Test"):
                # Quick test with minimal steps
                quick_steps = ["Upload", "Validate", "Process", "Complete"]
                progress_viz.initialize_progress(len(quick_steps), quick_steps)
                
                for i, step in enumerate(quick_steps):
                    progress_viz.update_step(i, 'processing', f"Running {step}...")
                    time.sleep(0.3)
                    progress_viz.update_step(i, 'completed', f"Finished {step}", 0.3)
                
                progress_viz.finish_processing()
                st.success("Quick test completed!")
        
        with col3:
            if st.button("🔄 Reset Progress"):
                st.session_state.progress_visualizer = prog_viz.InteractiveProgressVisualizer()
                st.rerun()
        
        # Real-time Progress Display Areas
        st.markdown("---")
        st.write("### 📈 Live Progress Dashboard")
        
        if progress_viz.is_processing or any(step['status'] == 'completed' for step in progress_viz.step_details.values()):
            # Create containers for real-time updates
            dashboard_container = st.container()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("#### ⏱️ Real-Time Metrics")
                chart_container = st.container()
            
            with col2:
                st.write("#### 📊 Processing Timeline")
                timeline_container = st.container()
            
            # Update displays
            progress_viz.create_progress_dashboard(dashboard_container)
            progress_viz.create_real_time_chart(chart_container)
            progress_viz.create_step_timeline(timeline_container)
            
            # Show summary if processing is complete
            if not progress_viz.is_processing and progress_viz.step_details:
                st.markdown("---")
                summary_container = st.container()
                progress_viz.create_progress_summary(summary_container)
        
        else:
            st.info("Click 'Start Data Processing Demo' to see the interactive progress visualization in action.")
        
        # Enhanced Upload Section with Progress Tracking
        st.markdown("---")
        st.write("### 📁 Enhanced Data Upload with Progress Tracking")
        
        st.info("""
        **Interactive Progress Features:**
        
        - **Real-Time Step Tracking**: Monitor each processing phase with live status updates
        - **File Processing Metrics**: Track individual file processing with success/error rates
        - **Performance Analytics**: View processing speed, ETA, and efficiency metrics
        - **Visual Timeline**: See step-by-step progress with duration tracking
        - **Live Charts**: Real-time graphs showing processing speed and cumulative progress
        - **Error Handling**: Detailed error reporting with step-specific failure information
        - **Completion Summary**: Comprehensive overview of processing results and statistics
        """)
        
        # Progress Configuration
        with st.expander("⚙️ Progress Tracking Configuration"):
            st.write("**Customize Progress Tracking Behavior:**")
            
            col1, col2 = st.columns(2)
            
            with col1:
                show_detailed_steps = st.checkbox("Show Detailed Step Information", value=True)
                show_file_progress = st.checkbox("Track Individual File Progress", value=True)
                show_error_details = st.checkbox("Display Error Details", value=True)
            
            with col2:
                auto_refresh = st.checkbox("Auto-Refresh Progress Display", value=True)
                show_performance_metrics = st.checkbox("Show Performance Metrics", value=True)
                enable_sound_notifications = st.checkbox("Enable Completion Sounds", value=False)
        
        # Integration Guide
        with st.expander("🔗 Integration with Existing Features"):
            st.markdown("""
            **The interactive progress system integrates with:**
            
            1. **Data Upload Process**: Real-time tracking of file uploads and validation
            2. **Batch Processing**: Progress monitoring for large dataset operations
            3. **AI Model Training**: Step-by-step tracking of machine learning processes
            4. **Peak Analysis**: Progress visualization for spectral peak detection
            5. **Report Generation**: Live updates during PDF and export creation
            6. **Database Operations**: Monitoring of data storage and retrieval operations
            
            **Benefits:**
            - Enhanced user experience with clear feedback
            - Better understanding of processing time requirements
            - Early detection of errors and issues
            - Improved workflow efficiency tracking
            - Professional presentation of complex operations
            """)
    
    with tab13:
        # Create the batch job management dashboard
        job_mgr.create_batch_job_dashboard()
    
    with tab14:
        # Create the interactive job performance heatmap visualization
        perf_heatmap.create_job_performance_heatmap_dashboard()
    
    with tab15:
        # Create the one-click job complexity analyzer
        complexity_analyzer.create_job_complexity_analyzer_dashboard()
    
    with tab16:
        # Create the gamified achievement system
        achievement_system.create_gamified_achievement_dashboard()
    
    # Download all visualizations as a ZIP file
    if st.button("Generate and Download All Visualizations"):
        with st.spinner("Generating visualizations..."):
            # Create a temporary directory to store the visualizations
            with tempfile.TemporaryDirectory() as temp_dir:
                # Generate all visualizations
                viz.generate_all_visualizations(
                    st.session_state.organized_data, 
                    temp_dir
                )
                
                # Create a ZIP file containing all visualizations
                zip_buffer = BytesIO()
                with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
                    for root, _, files in os.walk(temp_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            zip_file.write(
                                file_path, 
                                os.path.relpath(file_path, temp_dir)
                            )
                
                # Provide download link for the ZIP file
                zip_buffer.seek(0)
                b64 = base64.b64encode(zip_buffer.read()).decode()
                href = f'<a href="data:application/zip;base64,{b64}" download="spectral_visualizations.zip">Download All Visualizations</a>'
                st.markdown(href, unsafe_allow_html=True)
                st.success("Visualizations generated successfully!")

else:
    # Display instructions if no data is loaded
    st.info("Please upload data to begin analysis.")
    
    st.markdown("""
    ## Instructions
    
    1. Use the sidebar to upload your data:
       - **Upload data directory**: Upload a ZIP file containing the spectral data files in CSV format.
       - **Upload extracted NPZ file**: Upload a previously extracted NPZ file.
    
    2. Once data is loaded, use the visualization controls in the sidebar to:
       - Select a stage and file to analyze
       - Choose which visualization types to display
       - Set wavelength range for zoomed plots
    
    3. Explore the visualizations in the tabs:
       - **Single File Analysis**: View individual spectrum plots
       - **Stage Analysis**: View overview plots, heatmaps, and 3D surfaces for a stage
       - **Multi-Stage Comparison**: Compare multiple stages with histograms, box plots, and KDE plots
    
    4. Download individual visualizations using the download links below each plot
    
    5. Download all visualizations as a ZIP file using the button at the bottom of the page
    """)
