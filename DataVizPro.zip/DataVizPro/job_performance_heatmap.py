import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import seaborn as sns
import matplotlib.pyplot as plt
from typing import Dict, List, Optional, Any
import batch_job_manager as job_mgr

class JobPerformanceHeatmapVisualizer:
    def __init__(self):
        self.color_schemes = {
            'Runtime': 'Viridis',
            'Success Rate': 'RdYlGn',
            'Resource Usage': 'Plasma',
            'Error Rate': 'Reds',
            'Efficiency': 'Blues'
        }
    
    def generate_sample_performance_data(self, days=14, jobs_per_day=10):
        """Generate sample performance data for demonstration"""
        np.random.seed(42)  # For consistent demo data
        
        data = []
        job_types = ['peak_analysis', 'statistical_analysis', 'anomaly_detection', 'data_preprocessing', 'model_training']
        priorities = ['Low', 'Normal', 'High', 'Urgent']
        
        for day in range(days):
            date = datetime.now() - timedelta(days=days-day-1)
            
            for hour in range(0, 24, 2):  # Every 2 hours
                for job_type in job_types:
                    # Simulate realistic performance patterns
                    base_runtime = {
                        'peak_analysis': 45,
                        'statistical_analysis': 60,
                        'anomaly_detection': 90,
                        'data_preprocessing': 30,
                        'model_training': 120
                    }[job_type]
                    
                    # Add time-of-day variation
                    time_factor = 1.0 + 0.3 * np.sin(2 * np.pi * hour / 24)
                    
                    # Add random variation
                    runtime = base_runtime * time_factor * np.random.uniform(0.7, 1.5)
                    
                    # Success rate varies by job type and time
                    base_success = 0.85 + 0.1 * np.sin(2 * np.pi * hour / 24)
                    success_rate = np.clip(base_success + np.random.normal(0, 0.1), 0.5, 1.0)
                    
                    # Resource usage patterns
                    cpu_usage = np.random.uniform(20, 85)
                    memory_usage = np.random.uniform(30, 75)
                    
                    # Priority distribution
                    priority = np.random.choice(priorities, p=[0.3, 0.4, 0.2, 0.1])
                    
                    data.append({
                        'datetime': date.replace(hour=hour, minute=0, second=0),
                        'date': date.date(),
                        'hour': hour,
                        'day_of_week': date.strftime('%A'),
                        'job_type': job_type,
                        'priority': priority,
                        'runtime_seconds': runtime,
                        'success_rate': success_rate,
                        'cpu_usage': cpu_usage,
                        'memory_usage': memory_usage,
                        'efficiency_score': (success_rate * 100) / (runtime / 60),  # Success per minute
                        'error_rate': 1 - success_rate,
                        'jobs_completed': np.random.poisson(3) + 1
                    })
        
        return pd.DataFrame(data)
    
    def create_time_based_heatmap(self, data, metric='runtime_seconds'):
        """Create heatmap showing metric over time periods"""
        # Prepare data for heatmap
        pivot_data = data.pivot_table(
            values=metric,
            index='day_of_week',
            columns='hour',
            aggfunc='mean'
        )
        
        # Reorder days
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        pivot_data = pivot_data.reindex(day_order)
        
        # Create heatmap
        fig = go.Figure(data=go.Heatmap(
            z=pivot_data.values,
            x=[f"{h:02d}:00" for h in pivot_data.columns],
            y=pivot_data.index,
            colorscale=self.color_schemes.get(metric, 'Viridis'),
            hoverongaps=False,
            hovertemplate='<b>%{y}</b><br>' +
                         'Hour: %{x}<br>' +
                         f'{metric}: %{{z:.2f}}<br>' +
                         '<extra></extra>'
        ))
        
        fig.update_layout(
            title=f'{metric.replace("_", " ").title()} by Day and Hour',
            xaxis_title='Hour of Day',
            yaxis_title='Day of Week',
            height=400,
            font=dict(size=12)
        )
        
        return fig
    
    def create_job_type_performance_heatmap(self, data, metrics=['runtime_seconds', 'success_rate', 'cpu_usage']):
        """Create multi-metric heatmap for job types"""
        job_performance = data.groupby('job_type').agg({
            'runtime_seconds': 'mean',
            'success_rate': 'mean',
            'cpu_usage': 'mean',
            'memory_usage': 'mean',
            'efficiency_score': 'mean',
            'error_rate': 'mean',
            'jobs_completed': 'sum'
        }).round(2)
        
        # Normalize values for better comparison
        normalized_data = job_performance.copy()
        for col in normalized_data.columns:
            if col in ['success_rate', 'efficiency_score']:
                # Higher is better, so invert normalization
                normalized_data[col] = (normalized_data[col] - normalized_data[col].min()) / (normalized_data[col].max() - normalized_data[col].min())
            else:
                # Lower is better for runtime, error_rate, resource usage
                normalized_data[col] = 1 - (normalized_data[col] - normalized_data[col].min()) / (normalized_data[col].max() - normalized_data[col].min())
        
        # Create subplot with multiple heatmaps
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Runtime Performance', 'Success & Efficiency', 'Resource Usage', 'Overall Score'),
            specs=[[{"type": "xy"}, {"type": "xy"}],
                   [{"type": "xy"}, {"type": "xy"}]]
        )
        
        # Runtime heatmap
        runtime_data = job_performance[['runtime_seconds']].T
        fig.add_trace(
            go.Heatmap(
                z=runtime_data.values,
                x=runtime_data.columns,
                y=runtime_data.index,
                colorscale='Viridis_r',
                showscale=False,
                hovertemplate='Job Type: %{x}<br>Metric: %{y}<br>Value: %{z:.2f}<extra></extra>'
            ),
            row=1, col=1
        )
        
        # Success & Efficiency heatmap
        success_data = job_performance[['success_rate', 'efficiency_score']].T
        fig.add_trace(
            go.Heatmap(
                z=success_data.values,
                x=success_data.columns,
                y=success_data.index,
                colorscale='RdYlGn',
                showscale=False,
                hovertemplate='Job Type: %{x}<br>Metric: %{y}<br>Value: %{z:.2f}<extra></extra>'
            ),
            row=1, col=2
        )
        
        # Resource Usage heatmap
        resource_data = job_performance[['cpu_usage', 'memory_usage']].T
        fig.add_trace(
            go.Heatmap(
                z=resource_data.values,
                x=resource_data.columns,
                y=resource_data.index,
                colorscale='Plasma_r',
                showscale=False,
                hovertemplate='Job Type: %{x}<br>Metric: %{y}<br>Value: %{z:.2f}<extra></extra>'
            ),
            row=2, col=1
        )
        
        # Overall normalized score
        overall_data = normalized_data.T
        fig.add_trace(
            go.Heatmap(
                z=overall_data.values,
                x=overall_data.columns,
                y=overall_data.index,
                colorscale='Blues',
                showscale=True,
                hovertemplate='Job Type: %{x}<br>Metric: %{y}<br>Normalized Score: %{z:.2f}<extra></extra>'
            ),
            row=2, col=2
        )
        
        fig.update_layout(
            title='Job Type Performance Analysis',
            height=600,
            font=dict(size=10)
        )
        
        return fig, job_performance
    
    def create_priority_performance_heatmap(self, data):
        """Create heatmap showing performance by priority levels"""
        priority_performance = data.groupby(['priority', 'job_type']).agg({
            'runtime_seconds': 'mean',
            'success_rate': 'mean',
            'efficiency_score': 'mean'
        }).round(2)
        
        # Create separate heatmaps for each metric
        metrics = ['runtime_seconds', 'success_rate', 'efficiency_score']
        
        fig = make_subplots(
            rows=1, cols=3,
            subplot_titles=[m.replace('_', ' ').title() for m in metrics],
            specs=[[{"type": "xy"}, {"type": "xy"}, {"type": "xy"}]]
        )
        
        for i, metric in enumerate(metrics):
            pivot_data = data.pivot_table(
                values=metric,
                index='priority',
                columns='job_type',
                aggfunc='mean'
            )
            
            # Order priorities
            priority_order = ['Low', 'Normal', 'High', 'Urgent']
            pivot_data = pivot_data.reindex(priority_order)
            
            colorscale = 'Viridis_r' if metric == 'runtime_seconds' else 'RdYlGn'
            
            fig.add_trace(
                go.Heatmap(
                    z=pivot_data.values,
                    x=pivot_data.columns,
                    y=pivot_data.index,
                    colorscale=colorscale,
                    showscale=(i == 2),
                    hovertemplate='Priority: %{y}<br>Job Type: %{x}<br>' + 
                                f'{metric}: %{{z:.2f}}<extra></extra>'
                ),
                row=1, col=i+1
            )
        
        fig.update_layout(
            title='Performance by Priority Level',
            height=400,
            font=dict(size=11)
        )
        
        return fig
    
    def create_correlation_heatmap(self, data):
        """Create correlation matrix heatmap"""
        # Select numeric columns for correlation
        numeric_cols = ['runtime_seconds', 'success_rate', 'cpu_usage', 'memory_usage', 
                       'efficiency_score', 'error_rate', 'jobs_completed']
        
        correlation_matrix = data[numeric_cols].corr()
        
        fig = go.Figure(data=go.Heatmap(
            z=correlation_matrix.values,
            x=correlation_matrix.columns,
            y=correlation_matrix.index,
            colorscale='RdBu',
            zmid=0,
            text=correlation_matrix.round(2).values,
            texttemplate="%{text}",
            textfont={"size": 10},
            hovertemplate='%{y} vs %{x}<br>Correlation: %{z:.3f}<extra></extra>'
        ))
        
        fig.update_layout(
            title='Performance Metrics Correlation Matrix',
            height=500,
            font=dict(size=11)
        )
        
        return fig
    
    def create_trend_heatmap(self, data):
        """Create heatmap showing trends over time"""
        # Group by date and calculate daily averages
        daily_metrics = data.groupby('date').agg({
            'runtime_seconds': 'mean',
            'success_rate': 'mean',
            'cpu_usage': 'mean',
            'memory_usage': 'mean',
            'efficiency_score': 'mean',
            'jobs_completed': 'sum'
        }).reset_index()
        
        # Calculate rolling averages and trends
        for col in ['runtime_seconds', 'success_rate', 'cpu_usage', 'memory_usage', 'efficiency_score']:
            daily_metrics[f'{col}_trend'] = daily_metrics[col].rolling(window=3).mean()
        
        # Prepare data for heatmap (transpose for better visualization)
        trend_data = daily_metrics.set_index('date')[
            ['runtime_seconds_trend', 'success_rate_trend', 'cpu_usage_trend', 
             'memory_usage_trend', 'efficiency_score_trend']
        ].T
        
        # Rename index for better labels
        trend_data.index = [idx.replace('_trend', '').replace('_', ' ').title() for idx in trend_data.index]
        
        fig = go.Figure(data=go.Heatmap(
            z=trend_data.values,
            x=[d.strftime('%m/%d') for d in trend_data.columns],
            y=trend_data.index,
            colorscale='Spectral',
            hovertemplate='Date: %{x}<br>Metric: %{y}<br>Value: %{z:.2f}<extra></extra>'
        ))
        
        fig.update_layout(
            title='Performance Trends Over Time (3-day Rolling Average)',
            xaxis_title='Date',
            yaxis_title='Metrics',
            height=400,
            font=dict(size=11)
        )
        
        return fig
    
    def create_interactive_performance_dashboard(self, job_manager=None):
        """Create comprehensive interactive performance dashboard"""
        
        st.markdown("""
        <div class="analysis-section">
            <h2>📊 Interactive Job Performance Heatmap Visualization</h2>
            <p>Comprehensive visual analysis of batch job performance patterns and resource utilization</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Data source selection
        col1, col2 = st.columns([2, 1])
        
        with col1:
            data_source = st.radio(
                "Select data source:",
                ["Demo Data (Sample Performance)", "Live Job Data (Current Session)"],
                help="Choose between sample data for demonstration or live data from current job manager session"
            )
        
        with col2:
            if data_source == "Demo Data (Sample Performance)":
                days_range = st.slider("Demo data range (days)", 7, 30, 14)
                data = self.generate_sample_performance_data(days=days_range)
            else:
                if job_manager and len(job_manager.get_all_jobs()) > 0:
                    # Convert job manager data to performance data
                    jobs = job_manager.get_all_jobs()
                    job_data = []
                    for job in jobs:
                        if job.completed_at:
                            job_data.append({
                                'datetime': job.completed_at,
                                'date': job.completed_at.date(),
                                'hour': job.completed_at.hour,
                                'day_of_week': job.completed_at.strftime('%A'),
                                'job_type': job.job_type,
                                'priority': job.priority.name,
                                'runtime_seconds': job.get_runtime(),
                                'success_rate': 1.0 if job.status.value == 'completed' else 0.0,
                                'cpu_usage': job.resource_usage.get('cpu_usage', 0),
                                'memory_usage': job.resource_usage.get('memory_usage', 0),
                                'efficiency_score': (100 if job.status.value == 'completed' else 0) / max(1, job.get_runtime()/60),
                                'error_rate': 0.0 if job.status.value == 'completed' else 1.0,
                                'jobs_completed': 1
                            })
                    
                    if job_data:
                        data = pd.DataFrame(job_data)
                    else:
                        st.warning("No completed jobs found. Showing demo data instead.")
                        data = self.generate_sample_performance_data(days=7)
                else:
                    st.warning("No job manager data available. Showing demo data instead.")
                    data = self.generate_sample_performance_data(days=7)
        
        # Performance overview metrics
        st.write("### 📈 Performance Overview")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            avg_runtime = data['runtime_seconds'].mean()
            st.metric("Avg Runtime", f"{avg_runtime:.1f}s")
        
        with col2:
            avg_success = data['success_rate'].mean() * 100
            st.metric("Success Rate", f"{avg_success:.1f}%")
        
        with col3:
            avg_cpu = data['cpu_usage'].mean()
            st.metric("Avg CPU Usage", f"{avg_cpu:.1f}%")
        
        with col4:
            avg_efficiency = data['efficiency_score'].mean()
            st.metric("Efficiency Score", f"{avg_efficiency:.1f}")
        
        with col5:
            total_jobs = data['jobs_completed'].sum()
            st.metric("Total Jobs", f"{total_jobs:,}")
        
        # Interactive heatmap controls
        st.write("### 🎛️ Heatmap Controls")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            heatmap_type = st.selectbox(
                "Heatmap Type:",
                ["Time-based Analysis", "Job Type Performance", "Priority Analysis", 
                 "Correlation Matrix", "Trend Analysis"],
                help="Select the type of performance analysis to visualize"
            )
        
        with col2:
            if heatmap_type == "Time-based Analysis":
                metric_for_time = st.selectbox(
                    "Metric:",
                    ["runtime_seconds", "success_rate", "cpu_usage", "memory_usage", "efficiency_score"],
                    help="Select metric to analyze over time"
                )
        
        with col3:
            color_scheme = st.selectbox(
                "Color Scheme:",
                ["Viridis", "Plasma", "RdYlGn", "RdBu", "Blues", "Reds", "Spectral"],
                help="Choose color scheme for the heatmap"
            )
        
        # Generate and display heatmaps
        st.write("### 🔥 Performance Heatmaps")
        
        if heatmap_type == "Time-based Analysis":
            st.write(f"#### {metric_for_time.replace('_', ' ').title()} by Time Period")
            
            # Update color scheme
            self.color_schemes[metric_for_time] = color_scheme
            
            fig = self.create_time_based_heatmap(data, metric_for_time)
            st.plotly_chart(fig, use_container_width=True)
            
            # Additional insights
            st.write("**Insights:**")
            peak_day = data.groupby('day_of_week')[metric_for_time].mean().idxmax()
            peak_hour = data.groupby('hour')[metric_for_time].mean().idxmax()
            st.write(f"- Peak {metric_for_time.replace('_', ' ')}: {peak_day} at {peak_hour:02d}:00")
            
        elif heatmap_type == "Job Type Performance":
            st.write("#### Multi-Metric Job Type Analysis")
            
            fig, performance_df = self.create_job_type_performance_heatmap(data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Performance summary table
            st.write("**Performance Summary:**")
            st.dataframe(performance_df.round(2), use_container_width=True)
            
        elif heatmap_type == "Priority Analysis":
            st.write("#### Performance by Priority Level")
            
            fig = self.create_priority_performance_heatmap(data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Priority insights
            st.write("**Priority Insights:**")
            priority_summary = data.groupby('priority').agg({
                'runtime_seconds': 'mean',
                'success_rate': 'mean',
                'efficiency_score': 'mean'
            }).round(2)
            st.dataframe(priority_summary, use_container_width=True)
            
        elif heatmap_type == "Correlation Matrix":
            st.write("#### Performance Metrics Correlation")
            
            fig = self.create_correlation_heatmap(data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Correlation insights
            st.write("**Key Correlations:**")
            corr_matrix = data[['runtime_seconds', 'success_rate', 'cpu_usage', 'memory_usage', 'efficiency_score']].corr()
            
            # Find strongest correlations
            correlations = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    correlations.append({
                        'Metric 1': corr_matrix.columns[i],
                        'Metric 2': corr_matrix.columns[j],
                        'Correlation': corr_matrix.iloc[i, j]
                    })
            
            corr_df = pd.DataFrame(correlations).sort_values('Correlation', key=abs, ascending=False)
            st.dataframe(corr_df.head(5), use_container_width=True)
            
        elif heatmap_type == "Trend Analysis":
            st.write("#### Performance Trends Over Time")
            
            fig = self.create_trend_heatmap(data)
            st.plotly_chart(fig, use_container_width=True)
            
            # Trend insights
            st.write("**Trend Analysis:**")
            daily_summary = data.groupby('date').agg({
                'runtime_seconds': 'mean',
                'success_rate': 'mean',
                'efficiency_score': 'mean'
            }).round(2)
            
            # Calculate trend direction
            for col in daily_summary.columns:
                trend = "Improving" if daily_summary[col].iloc[-1] > daily_summary[col].iloc[0] else "Declining"
                change = ((daily_summary[col].iloc[-1] / daily_summary[col].iloc[0]) - 1) * 100
                st.write(f"- {col.replace('_', ' ').title()}: {trend} ({change:+.1f}%)")
        
        # Performance recommendations
        st.write("### 💡 Performance Recommendations")
        
        with st.expander("Optimization Suggestions"):
            # Analyze data for recommendations
            high_runtime_jobs = data[data['runtime_seconds'] > data['runtime_seconds'].quantile(0.8)]
            low_success_jobs = data[data['success_rate'] < 0.8]
            high_resource_jobs = data[(data['cpu_usage'] > 70) | (data['memory_usage'] > 70)]
            
            if not high_runtime_jobs.empty:
                problematic_types = high_runtime_jobs['job_type'].value_counts().head(3)
                st.write("**High Runtime Jobs:**")
                for job_type, count in problematic_types.items():
                    avg_runtime = high_runtime_jobs[high_runtime_jobs['job_type'] == job_type]['runtime_seconds'].mean()
                    st.write(f"- {job_type}: {count} jobs averaging {avg_runtime:.1f}s")
            
            if not low_success_jobs.empty:
                st.write("**Low Success Rate Issues:**")
                failing_types = low_success_jobs['job_type'].value_counts().head(3)
                for job_type, count in failing_types.items():
                    avg_success = low_success_jobs[low_success_jobs['job_type'] == job_type]['success_rate'].mean()
                    st.write(f"- {job_type}: {avg_success:.1%} success rate")
            
            if not high_resource_jobs.empty:
                st.write("**Resource Usage Optimization:**")
                resource_intensive = high_resource_jobs['job_type'].value_counts().head(3)
                for job_type, count in resource_intensive.items():
                    avg_cpu = high_resource_jobs[high_resource_jobs['job_type'] == job_type]['cpu_usage'].mean()
                    avg_mem = high_resource_jobs[high_resource_jobs['job_type'] == job_type]['memory_usage'].mean()
                    st.write(f"- {job_type}: {avg_cpu:.1f}% CPU, {avg_mem:.1f}% Memory")
        
        # Export options
        st.write("### 📁 Export Options")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📊 Export Performance Data"):
                csv_data = data.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv_data,
                    file_name=f"job_performance_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            if st.button("📈 Export Summary Report"):
                summary_report = self.generate_performance_report(data)
                st.download_button(
                    label="Download Report",
                    data=summary_report,
                    file_name=f"performance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )
        
        with col3:
            st.write("**Chart Export:**")
            st.caption("Use the download button on individual charts to save as PNG")
        
        return data
    
    def generate_performance_report(self, data):
        """Generate text-based performance report"""
        report = []
        report.append("JOB PERFORMANCE ANALYSIS REPORT")
        report.append("=" * 40)
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Data Period: {data['date'].min()} to {data['date'].max()}")
        report.append(f"Total Records: {len(data)}")
        report.append("")
        
        report.append("OVERALL PERFORMANCE METRICS")
        report.append("-" * 30)
        report.append(f"Average Runtime: {data['runtime_seconds'].mean():.2f} seconds")
        report.append(f"Success Rate: {data['success_rate'].mean():.1%}")
        report.append(f"Average CPU Usage: {data['cpu_usage'].mean():.1f}%")
        report.append(f"Average Memory Usage: {data['memory_usage'].mean():.1f}%")
        report.append(f"Efficiency Score: {data['efficiency_score'].mean():.2f}")
        report.append("")
        
        report.append("PERFORMANCE BY JOB TYPE")
        report.append("-" * 25)
        job_performance = data.groupby('job_type').agg({
            'runtime_seconds': 'mean',
            'success_rate': 'mean',
            'efficiency_score': 'mean'
        }).round(2)
        
        for job_type, metrics in job_performance.iterrows():
            report.append(f"{job_type}:")
            report.append(f"  Runtime: {metrics['runtime_seconds']} seconds")
            report.append(f"  Success Rate: {metrics['success_rate']:.1%}")
            report.append(f"  Efficiency: {metrics['efficiency_score']:.2f}")
            report.append("")
        
        return "\n".join(report)

def create_job_performance_heatmap_dashboard():
    """Main function to create the heatmap dashboard"""
    
    # Initialize the visualizer
    visualizer = JobPerformanceHeatmapVisualizer()
    
    # Get job manager if available
    job_manager = st.session_state.get('batch_job_manager', None)
    
    # Create the dashboard
    performance_data = visualizer.create_interactive_performance_dashboard(job_manager)
    
    return visualizer, performance_data