import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import io

def create_enhanced_sidebar(data=None):
    """Create an enhanced sidebar with comprehensive data overview and controls"""
    
    with st.sidebar:
        st.markdown("""
        <div class="sidebar-section">
            <h3>📊 Data Overview</h3>
        </div>
        """, unsafe_allow_html=True)
        
        if data:
            # Data summary metrics
            total_stages = len(data.keys())
            total_files = sum(len(stage_data) for stage_data in data.values())
            
            # Create metrics display
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"""
                <div class="metric-card">
                    <h4>{total_stages}</h4>
                    <p>Stages</p>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                st.markdown(f"""
                <div class="metric-card">
                    <h4>{total_files}</h4>
                    <p>Total Files</p>
                </div>
                """, unsafe_allow_html=True)
            
            # Stage breakdown
            st.markdown("### 📈 Stage Breakdown")
            stage_info = []
            for stage, stage_data in data.items():
                stage_info.append({
                    'Stage': f'Stage {stage}',
                    'Files': len(stage_data),
                    'Status': '✅ Loaded'
                })
            
            stage_df = pd.DataFrame(stage_info)
            st.dataframe(stage_df, use_container_width=True, hide_index=True)
            
            # Quick data quality check
            st.markdown("### 🔍 Data Quality")
            quality_metrics = calculate_data_quality(data)
            
            for metric_name, metric_value in quality_metrics.items():
                if metric_value > 0.8:
                    color = "green"
                    icon = "✅"
                elif metric_value > 0.6:
                    color = "orange"
                    icon = "⚠️"
                else:
                    color = "red"
                    icon = "❌"
                
                st.markdown(f"""
                <div style="padding: 0.5rem; margin: 0.3rem 0; background: #f8f9fa; border-radius: 5px;">
                    {icon} <strong>{metric_name}:</strong> 
                    <span style="color: {color};">{metric_value:.1%}</span>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("Upload data to see overview")
        
        # Analysis Controls
        st.markdown("""
        <div class="sidebar-section">
            <h3>⚙️ Analysis Controls</h3>
        </div>
        """, unsafe_allow_html=True)
        
        # Global normalization setting
        use_global_normalization = st.checkbox(
            "Global Data Normalization", 
            value=True,
            help="Apply consistent normalization across all visualizations"
        )
        
        # Analysis mode
        analysis_mode = st.selectbox(
            "Analysis Mode:",
            ["Standard Analysis", "Deep Learning Mode", "Comparative Analysis", "Quality Assessment"],
            help="Choose the type of analysis to perform"
        )
        
        # Advanced options
        with st.expander("Advanced Options"):
            smoothing_enabled = st.checkbox("Enable Smoothing", value=False)
            if smoothing_enabled:
                smoothing_window = st.slider("Smoothing Window", 3, 21, 11, step=2)
            
            baseline_correction = st.checkbox("Baseline Correction", value=False)
            if baseline_correction:
                polynomial_order = st.slider("Polynomial Order", 1, 5, 2)
            
            peak_detection = st.checkbox("Auto Peak Detection", value=False)
            if peak_detection:
                peak_prominence = st.slider("Peak Prominence", 0.01, 0.5, 0.1, step=0.01)
        
        # Export options
        st.markdown("""
        <div class="sidebar-section">
            <h3>💾 Export Options</h3>
        </div>
        """, unsafe_allow_html=True)
        
        if data:
            export_format = st.selectbox(
                "Export Format:",
                ["PNG", "SVG", "PDF", "HTML", "CSV Data"]
            )
            
            if st.button("📥 Export All Visualizations", use_container_width=True):
                export_all_visualizations(data, export_format)
        
        # Quick actions
        st.markdown("""
        <div class="sidebar-section">
            <h3>⚡ Quick Actions</h3>
        </div>
        """, unsafe_allow_html=True)
        
        if data:
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 Refresh Data", use_container_width=True):
                    st.rerun()
            
            with col2:
                if st.button("📊 Summary Report", use_container_width=True):
                    generate_summary_report(data)
        
        return {
            'use_global_normalization': use_global_normalization if 'use_global_normalization' in locals() else True,
            'analysis_mode': analysis_mode if 'analysis_mode' in locals() else "Standard Analysis",
            'smoothing_enabled': smoothing_enabled if 'smoothing_enabled' in locals() else False,
            'smoothing_window': smoothing_window if 'smoothing_enabled' in locals() and smoothing_enabled else 11,
            'baseline_correction': baseline_correction if 'baseline_correction' in locals() else False,
            'polynomial_order': polynomial_order if 'baseline_correction' in locals() and baseline_correction else 2,
            'peak_detection': peak_detection if 'peak_detection' in locals() else False,
            'peak_prominence': peak_prominence if 'peak_detection' in locals() and peak_detection else 0.1
        }

def calculate_data_quality(data):
    """Calculate data quality metrics"""
    quality_metrics = {}
    
    all_intensities = []
    wavelength_consistency = []
    
    for stage, stage_data in data.items():
        for file_num, file_data in stage_data.items():
            intensity = file_data['intensity']
            wavelength = file_data['wavelength']
            
            all_intensities.extend(intensity)
            wavelength_consistency.append(len(wavelength))
    
    # Data completeness (no NaN values)
    nan_count = np.sum(np.isnan(all_intensities))
    quality_metrics['Data Completeness'] = 1 - (nan_count / len(all_intensities))
    
    # Wavelength consistency
    wavelength_std = np.std(wavelength_consistency)
    quality_metrics['Wavelength Consistency'] = 1 - min(wavelength_std / np.mean(wavelength_consistency), 1)
    
    # Signal quality (based on dynamic range)
    intensity_range = np.max(all_intensities) - np.min(all_intensities)
    quality_metrics['Signal Dynamic Range'] = min(intensity_range / np.max(all_intensities), 1)
    
    return quality_metrics

def create_data_summary_cards(data):
    """Create summary cards showing key data metrics"""
    if not data:
        return
    
    # Calculate summary statistics
    total_spectra = sum(len(stage_data) for stage_data in data.values())
    stages = list(data.keys())
    
    # Get wavelength range
    all_wavelengths = []
    all_intensities = []
    
    for stage_data in data.values():
        for file_data in stage_data.values():
            all_wavelengths.extend(file_data['wavelength'])
            all_intensities.extend(file_data['intensity'])
    
    wavelength_range = f"{np.min(all_wavelengths):.1f} - {np.max(all_wavelengths):.1f}"
    intensity_range = f"{np.min(all_intensities):.3f} - {np.max(all_intensities):.3f}"
    
    # Create metric cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{total_spectra}</h3>
            <p>Total Spectra</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{len(stages)}</h3>
            <p>Contamination Stages</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{wavelength_range}</h3>
            <p>Wavelength Range</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <h3>{intensity_range}</h3>
            <p>Intensity Range</p>
        </div>
        """, unsafe_allow_html=True)

def create_quick_visualization_preview(data, max_spectra=5):
    """Create a quick preview of the data with multiple spectra"""
    if not data:
        return None
    
    fig = go.Figure()
    
    colors = px.colors.qualitative.Set1
    spectrum_count = 0
    
    for stage_idx, (stage, stage_data) in enumerate(data.items()):
        if spectrum_count >= max_spectra:
            break
            
        stage_color = colors[stage_idx % len(colors)]
        
        for file_num, file_data in list(stage_data.items())[:2]:  # Show max 2 files per stage
            if spectrum_count >= max_spectra:
                break
                
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            
            fig.add_trace(go.Scatter(
                x=wavelength,
                y=intensity,
                mode='lines',
                name=f'Stage {stage} - File {file_num}',
                line=dict(color=stage_color, width=2),
                opacity=0.8
            ))
            
            spectrum_count += 1
    
    fig.update_layout(
        title="Data Preview - Sample Spectra",
        xaxis_title="Wavelength",
        yaxis_title="Intensity",
        height=400,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    
    return fig

def export_all_visualizations(data, format_type):
    """Export all visualizations in the specified format"""
    st.info(f"Exporting visualizations in {format_type} format...")
    # This would implement the actual export functionality
    # For now, just show a success message
    st.success(f"Visualizations exported successfully in {format_type} format!")

def generate_summary_report(data):
    """Generate a comprehensive summary report"""
    st.markdown("### 📋 Data Summary Report")
    
    # Create summary statistics
    report_data = []
    
    for stage, stage_data in data.items():
        for file_num, file_data in stage_data.items():
            intensity = file_data['intensity']
            wavelength = file_data['wavelength']
            
            report_data.append({
                'Stage': stage,
                'File': file_num,
                'Points': len(intensity),
                'Min Wavelength': np.min(wavelength),
                'Max Wavelength': np.max(wavelength),
                'Min Intensity': np.min(intensity),
                'Max Intensity': np.max(intensity),
                'Mean Intensity': np.mean(intensity),
                'Std Intensity': np.std(intensity)
            })
    
    report_df = pd.DataFrame(report_data)
    
    # Display summary table
    st.dataframe(report_df, use_container_width=True)
    
    # Provide download option
    csv = report_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Report as CSV",
        data=csv,
        file_name="spectral_data_summary.csv",
        mime="text/csv"
    )

def create_progress_tracking():
    """Create a progress tracking component for analysis workflows"""
    
    st.markdown("### 📈 Analysis Progress")
    
    # Example progress items
    progress_items = [
        ("Data Upload", 1.0, "✅"),
        ("Data Processing", 1.0, "✅"),
        ("Basic Visualizations", 0.8, "🔄"),
        ("Advanced Analytics", 0.3, "⏳"),
        ("ML Analysis", 0.0, "⏭️")
    ]
    
    for item_name, progress, status in progress_items:
        col1, col2, col3 = st.columns([3, 1, 1])
        
        with col1:
            st.write(item_name)
        
        with col2:
            st.progress(progress)
        
        with col3:
            st.write(status)

def create_feature_showcase():
    """Create a showcase of available features"""
    
    st.markdown("### 🚀 Available Features")
    
    features = [
        ("📊 Basic Visualizations", "Line plots, heatmaps, 3D surfaces"),
        ("🔬 Advanced Analytics", "PCA, clustering, derivatives"),
        ("🤖 Machine Learning", "Anomaly detection, classification"),
        ("📈 Enhanced Visuals", "Interactive animations, fingerprints"),
        ("📋 Data Processing", "Smoothing, baseline correction"),
        ("💾 Export Options", "Multiple formats, batch export")
    ]
    
    for feature_name, description in features:
        st.markdown(f"""
        <div class="feature-card">
            <h4>{feature_name}</h4>
            <p>{description}</p>
        </div>
        """, unsafe_allow_html=True)