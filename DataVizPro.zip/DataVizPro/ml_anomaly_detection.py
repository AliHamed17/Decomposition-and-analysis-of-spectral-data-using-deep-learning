import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

def prepare_data_for_ml(organized_data):
    """
    Prepare spectral data for machine learning analysis
    Returns a DataFrame with flattened spectral data and metadata
    """
    data_rows = []
    
    for stage, stage_data in organized_data.items():
        for file_num, file_data in stage_data.items():
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            
            # Create a row with intensity values and metadata
            row = {
                'stage': stage,
                'file_number': file_num,
                'stage_file': f"Stage_{stage}_File_{file_num}"
            }
            
            # Add intensity values as features
            for i, (wl, intens) in enumerate(zip(wavelength, intensity)):
                row[f'intensity_{i}'] = intens
            
            data_rows.append(row)
    
    df = pd.DataFrame(data_rows)
    return df

def detect_anomalies_isolation_forest(data_df, contamination=0.1):
    """
    Detect anomalies using Isolation Forest algorithm
    Returns anomaly scores and predictions
    """
    # Prepare feature matrix (only intensity columns)
    feature_cols = [col for col in data_df.columns if col.startswith('intensity_')]
    X = data_df[feature_cols].values
    
    # Handle missing values
    X = np.nan_to_num(X, nan=0.0)
    
    # Standardize the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Apply Isolation Forest
    iso_forest = IsolationForest(contamination=contamination, random_state=42)
    anomaly_pred = iso_forest.fit_predict(X_scaled)
    anomaly_scores = iso_forest.decision_function(X_scaled)
    
    # Add results to dataframe
    results_df = data_df.copy()
    results_df['anomaly_score'] = anomaly_scores
    results_df['is_anomaly'] = anomaly_pred == -1
    results_df['anomaly_method'] = 'Isolation Forest'
    
    return results_df, iso_forest, scaler

def detect_anomalies_one_class_svm(data_df, nu=0.1):
    """
    Detect anomalies using One-Class SVM algorithm
    Returns anomaly scores and predictions
    """
    # Prepare feature matrix
    feature_cols = [col for col in data_df.columns if col.startswith('intensity_')]
    X = data_df[feature_cols].values
    
    # Handle missing values
    X = np.nan_to_num(X, nan=0.0)
    
    # Standardize the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Apply One-Class SVM
    svm_model = OneClassSVM(nu=nu, kernel='rbf', gamma='scale')
    anomaly_pred = svm_model.fit_predict(X_scaled)
    anomaly_scores = svm_model.decision_function(X_scaled)
    
    # Add results to dataframe
    results_df = data_df.copy()
    results_df['anomaly_score'] = anomaly_scores
    results_df['is_anomaly'] = anomaly_pred == -1
    results_df['anomaly_method'] = 'One-Class SVM'
    
    return results_df, svm_model, scaler

def detect_anomalies_dbscan(data_df, eps=0.5, min_samples=5):
    """
    Detect anomalies using DBSCAN clustering
    Points in small clusters or noise are considered anomalies
    """
    # Prepare feature matrix
    feature_cols = [col for col in data_df.columns if col.startswith('intensity_')]
    X = data_df[feature_cols].values
    
    # Handle missing values
    X = np.nan_to_num(X, nan=0.0)
    
    # Standardize the data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Apply DBSCAN
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    cluster_labels = dbscan.fit_predict(X_scaled)
    
    # Calculate cluster sizes
    unique_labels, counts = np.unique(cluster_labels[cluster_labels != -1], return_counts=True)
    cluster_sizes = dict(zip(unique_labels, counts))
    
    # Consider points in noise (-1) or small clusters as anomalies
    min_cluster_size = min_samples * 2  # Threshold for small clusters
    
    results_df = data_df.copy()
    results_df['cluster_label'] = cluster_labels
    results_df['is_anomaly'] = (cluster_labels == -1) | \
                               np.array([cluster_sizes.get(label, 0) < min_cluster_size 
                                        for label in cluster_labels])
    results_df['anomaly_method'] = 'DBSCAN'
    
    return results_df, dbscan, scaler

def compare_stages_anomalies(anomaly_results):
    """
    Compare anomaly detection results across different stages
    Returns summary statistics and visualizations
    """
    stage_summary = anomaly_results.groupby('stage').agg({
        'is_anomaly': ['count', 'sum', 'mean'],
        'anomaly_score': ['mean', 'std', 'min', 'max']
    }).round(4)
    
    # Flatten column names
    stage_summary.columns = ['_'.join(col).strip() for col in stage_summary.columns.values]
    stage_summary = stage_summary.rename(columns={
        'is_anomaly_count': 'total_files',
        'is_anomaly_sum': 'anomaly_count',
        'is_anomaly_mean': 'anomaly_rate',
        'anomaly_score_mean': 'avg_anomaly_score',
        'anomaly_score_std': 'std_anomaly_score',
        'anomaly_score_min': 'min_anomaly_score',
        'anomaly_score_max': 'max_anomaly_score'
    })
    
    return stage_summary

def plot_anomaly_detection_results(anomaly_results, method_name="Anomaly Detection"):
    """
    Create visualizations for anomaly detection results
    """
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            'Anomaly Scores by Stage',
            'Anomaly Distribution',
            'PCA Visualization with Anomalies',
            'Anomaly Count by Stage'
        ],
        specs=[[{"secondary_y": False}, {"secondary_y": False}],
               [{"secondary_y": False}, {"secondary_y": False}]]
    )
    
    # Plot 1: Anomaly scores by stage
    for stage in sorted(anomaly_results['stage'].unique()):
        stage_data = anomaly_results[anomaly_results['stage'] == stage]
        fig.add_trace(
            go.Box(
                y=stage_data['anomaly_score'],
                name=f'Stage {stage}',
                boxpoints='outliers'
            ),
            row=1, col=1
        )
    
    # Plot 2: Anomaly distribution
    anomaly_counts = anomaly_results['is_anomaly'].value_counts()
    fig.add_trace(
        go.Pie(
            labels=['Normal', 'Anomaly'],
            values=[anomaly_counts.get(False, 0), anomaly_counts.get(True, 0)],
            name="Anomaly Distribution"
        ),
        row=1, col=2
    )
    
    # Plot 3: PCA visualization
    feature_cols = [col for col in anomaly_results.columns if col.startswith('intensity_')]
    if len(feature_cols) > 1:
        X = anomaly_results[feature_cols].values
        X = np.nan_to_num(X, nan=0.0)
        
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(StandardScaler().fit_transform(X))
        
        colors = ['red' if anomaly else 'blue' for anomaly in anomaly_results['is_anomaly']]
        
        fig.add_trace(
            go.Scatter(
                x=X_pca[:, 0],
                y=X_pca[:, 1],
                mode='markers',
                marker=dict(
                    color=colors,
                    size=8,
                    opacity=0.7
                ),
                text=anomaly_results['stage_file'],
                name="PCA Projection"
            ),
            row=2, col=1
        )
    
    # Plot 4: Anomaly count by stage
    stage_anomaly_counts = anomaly_results.groupby('stage')['is_anomaly'].sum()
    fig.add_trace(
        go.Bar(
            x=[f'Stage {stage}' for stage in stage_anomaly_counts.index],
            y=stage_anomaly_counts.values,
            name='Anomaly Count',
            marker_color='red'
        ),
        row=2, col=2
    )
    
    fig.update_layout(
        title=f'{method_name} Results',
        height=800,
        showlegend=True
    )
    
    return fig

def plot_anomaly_heatmap(anomaly_results, organized_data):
    """
    Create a heatmap showing anomaly scores across stages and files
    """
    # Create pivot table for heatmap
    if 'anomaly_score' in anomaly_results.columns:
        pivot_data = anomaly_results.pivot(index='stage', columns='file_number', values='anomaly_score')
    else:
        # For DBSCAN, use cluster labels
        pivot_data = anomaly_results.pivot(index='stage', columns='file_number', values='is_anomaly')
        pivot_data = pivot_data.astype(float)
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Create heatmap
    sns.heatmap(
        pivot_data,
        annot=True,
        fmt='.3f',
        cmap='RdYlBu_r',
        center=0,
        ax=ax,
        cbar_kws={'label': 'Anomaly Score'}
    )
    
    ax.set_title('Anomaly Scores Heatmap\n(Red = More Anomalous, Blue = More Normal)')
    ax.set_xlabel('File Number')
    ax.set_ylabel('Stage')
    
    return fig

def identify_stage_transitions(anomaly_results):
    """
    Identify potential contamination or changes between stages
    """
    stage_summary = compare_stages_anomalies(anomaly_results)
    
    # Calculate stage-to-stage changes
    stages = sorted(anomaly_results['stage'].unique())
    transitions = []
    
    for i in range(len(stages) - 1):
        current_stage = stages[i]
        next_stage = stages[i + 1]
        
        current_anomaly_rate = stage_summary.loc[current_stage, 'anomaly_rate']
        next_anomaly_rate = stage_summary.loc[next_stage, 'anomaly_rate']
        
        change = next_anomaly_rate - current_anomaly_rate
        
        transitions.append({
            'from_stage': current_stage,
            'to_stage': next_stage,
            'anomaly_rate_change': change,
            'current_anomaly_rate': current_anomaly_rate,
            'next_anomaly_rate': next_anomaly_rate,
            'significance': 'High' if abs(change) > 0.3 else 'Medium' if abs(change) > 0.1 else 'Low'
        })
    
    transitions_df = pd.DataFrame(transitions)
    return transitions_df

def generate_anomaly_report(anomaly_results, method_name="Anomaly Detection"):
    """
    Generate a comprehensive report of anomaly detection results
    """
    report = []
    
    report.append(f"# {method_name} Report\n")
    
    # Overall statistics
    total_files = len(anomaly_results)
    anomaly_count = anomaly_results['is_anomaly'].sum()
    anomaly_rate = anomaly_count / total_files
    
    report.append(f"## Overall Statistics")
    report.append(f"- Total files analyzed: {total_files}")
    report.append(f"- Anomalies detected: {anomaly_count}")
    report.append(f"- Overall anomaly rate: {anomaly_rate:.2%}\n")
    
    # Stage-wise analysis
    stage_summary = compare_stages_anomalies(anomaly_results)
    report.append(f"## Stage-wise Analysis")
    report.append(stage_summary.to_string())
    report.append("\n")
    
    # Stage transitions
    transitions = identify_stage_transitions(anomaly_results)
    report.append(f"## Stage Transition Analysis")
    report.append(transitions.to_string(index=False))
    report.append("\n")
    
    # Most anomalous files
    if 'anomaly_score' in anomaly_results.columns:
        most_anomalous = anomaly_results.nsmallest(5, 'anomaly_score')[['stage_file', 'stage', 'file_number', 'anomaly_score']]
        report.append(f"## Most Anomalous Files")
        report.append(most_anomalous.to_string(index=False))
        report.append("\n")
    
    return "\n".join(report)

def run_comprehensive_anomaly_analysis(organized_data, contamination=0.1, nu=0.1, eps=0.5, min_samples=5):
    """
    Run comprehensive anomaly detection using multiple algorithms
    """
    # Prepare data
    data_df = prepare_data_for_ml(organized_data)
    
    results = {}
    
    # Isolation Forest
    try:
        iso_results, iso_model, iso_scaler = detect_anomalies_isolation_forest(data_df, contamination)
        results['isolation_forest'] = {
            'data': iso_results,
            'model': iso_model,
            'scaler': iso_scaler,
            'summary': compare_stages_anomalies(iso_results)
        }
    except Exception as e:
        print(f"Isolation Forest failed: {e}")
    
    # One-Class SVM
    try:
        svm_results, svm_model, svm_scaler = detect_anomalies_one_class_svm(data_df, nu)
        results['one_class_svm'] = {
            'data': svm_results,
            'model': svm_model,
            'scaler': svm_scaler,
            'summary': compare_stages_anomalies(svm_results)
        }
    except Exception as e:
        print(f"One-Class SVM failed: {e}")
    
    # DBSCAN
    try:
        dbscan_results, dbscan_model, dbscan_scaler = detect_anomalies_dbscan(data_df, eps, min_samples)
        results['dbscan'] = {
            'data': dbscan_results,
            'model': dbscan_model,
            'scaler': dbscan_scaler,
            'summary': compare_stages_anomalies(dbscan_results)
        }
    except Exception as e:
        print(f"DBSCAN failed: {e}")
    
    return results