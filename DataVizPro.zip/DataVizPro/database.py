import os
import numpy as np
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, Float, String, LargeBinary, ForeignKey, Table, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from io import BytesIO

# Get database URL from environment variable
DATABASE_URL = os.environ.get('DATABASE_URL')
DB_AVAILABLE = False

try:
    if DATABASE_URL is None:
        # Fallback for testing
        DATABASE_URL = "sqlite:///spectral_data.db"
    
    # Create SQLAlchemy engine and session
    engine = create_engine(DATABASE_URL)
    Session = sessionmaker(bind=engine)
    Base = declarative_base()
    DB_AVAILABLE = True
except Exception as e:
    print(f"Database connection failed: {e}")
    print("Application will run without database features")
    engine = None
    Session = None
    Base = None

# Define models only if database is available
if DB_AVAILABLE and Base is not None:
    class Stage(Base):
        __tablename__ = 'stages'
        
        id = Column(Integer, primary_key=True)
        stage_number = Column(Integer, unique=True, nullable=False)
        description = Column(String, nullable=True)
        
        spectra = relationship("Spectrum", back_populates="stage")
        
        def __repr__(self):
            return f"<Stage(stage_number={self.stage_number})>"

    class Spectrum(Base):
        __tablename__ = 'spectra'
        
        id = Column(Integer, primary_key=True)
        file_number = Column(Integer, nullable=False)
        stage_id = Column(Integer, ForeignKey('stages.id'), nullable=False)
        wavelength_data = Column(LargeBinary, nullable=False)  # Store as compressed NumPy array
        intensity_data = Column(LargeBinary, nullable=False)   # Store as compressed NumPy array
        
        stage = relationship("Stage", back_populates="spectra")
        
        def __repr__(self):
            return f"<Spectrum(stage_id={self.stage_id}, file_number={self.file_number})>"
        
        def get_wavelength(self):
            """Get wavelength as NumPy array"""
            return np.load(BytesIO(self.wavelength_data))
        
        def get_intensity(self):
            """Get intensity as NumPy array"""
            return np.load(BytesIO(self.intensity_data))
else:
    # Create dummy classes if database is not available
    class Stage:
        pass
    
    class Spectrum:
        pass

# Initialize database
def init_db():
    if not DB_AVAILABLE or Base is None or engine is None:
        print("Database not available - running without database features")
        return False
    
    try:
        Base.metadata.create_all(engine)
        print("Database tables created")
        return True
    except Exception as e:
        print(f"Database initialization failed: {e}")
        print("Application will run without database features")
        return False

# Functions for data operations
def save_data_to_db(organized_data):
    """
    Save organized data to the database
    Input is organized_data from data_processor.organize_data()
    """
    if not DB_AVAILABLE or Session is None:
        print("Database not available - cannot save data")
        return False
    
    session = Session()
    
    try:
        # For each stage in the data
        for stage_num, stage_data in organized_data.items():
            # Check if stage exists
            stage = session.query(Stage).filter_by(stage_number=stage_num).first()
            if not stage:
                # Create new stage
                stage = Stage(stage_number=stage_num)
                session.add(stage)
                session.flush()  # To get the stage ID
            
            # For each file in this stage
            for file_num, file_data in stage_data.items():
                # Check if spectrum exists
                spectrum = session.query(Spectrum).filter_by(
                    stage_id=stage.id, 
                    file_number=file_num
                ).first()
                
                # Compress wavelength and intensity arrays
                wavelength_buffer = BytesIO()
                np.save(wavelength_buffer, file_data['wavelength'])
                wavelength_bytes = wavelength_buffer.getvalue()
                
                intensity_buffer = BytesIO()
                np.save(intensity_buffer, file_data['intensity'])
                intensity_bytes = intensity_buffer.getvalue()
                
                if spectrum:
                    # Update existing spectrum
                    spectrum.wavelength_data = wavelength_bytes
                    spectrum.intensity_data = intensity_bytes
                else:
                    # Create new spectrum
                    spectrum = Spectrum(
                        file_number=file_num,
                        stage_id=stage.id,
                        wavelength_data=wavelength_bytes,
                        intensity_data=intensity_bytes
                    )
                    session.add(spectrum)
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Error saving data to database: {str(e)}")
        return False
    finally:
        session.close()

def load_data_from_db():
    """
    Load all data from the database
    Returns organized_data in the same format as data_processor.organize_data()
    """
    if not DB_AVAILABLE or Session is None:
        return None
    
    session = Session()
    organized_data = {}
    
    try:
        # Get all stages
        stages = session.query(Stage).all()
        
        for stage in stages:
            stage_num = stage.stage_number
            organized_data[stage_num] = {}
            
            # Get all spectra for this stage
            spectra = session.query(Spectrum).filter_by(stage_id=stage.id).all()
            
            for spectrum in spectra:
                file_num = spectrum.file_number
                organized_data[stage_num][file_num] = {
                    'wavelength': spectrum.get_wavelength(),
                    'intensity': spectrum.get_intensity()
                }
        
        return organized_data
    except Exception as e:
        print(f"Error loading data from database: {str(e)}")
        return None
    finally:
        session.close()

def get_available_stages():
    """Get a list of all stage numbers in the database"""
    if not DB_AVAILABLE or Session is None:
        return []
    
    session = Session()
    try:
        stages = session.query(Stage.stage_number).all()
        return [stage[0] for stage in stages]
    except Exception as e:
        print(f"Error getting stages from database: {str(e)}")
        return []
    finally:
        session.close()

def get_files_for_stage(stage_num):
    """Get a list of all file numbers for a specific stage"""
    if not DB_AVAILABLE or Session is None:
        return []
    
    session = Session()
    try:
        stage = session.query(Stage).filter_by(stage_number=stage_num).first()
        if not stage:
            return []
        
        files = session.query(Spectrum.file_number).filter_by(stage_id=stage.id).all()
        return [file[0] for file in files]
    except Exception as e:
        print(f"Error getting files for stage {stage_num}: {str(e)}")
        return []
    finally:
        session.close()

def delete_stage(stage_num):
    """Delete a stage and all its associated spectra from the database"""
    session = Session()
    try:
        stage = session.query(Stage).filter_by(stage_number=stage_num).first()
        if not stage:
            return False
        
        # This will also delete all associated spectra due to cascade relationship
        session.delete(stage)
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        print(f"Error deleting stage {stage_num}: {str(e)}")
        return False
    finally:
        session.close()

def get_stage_summary():
    """
    Get a summary of data stored in the database
    Returns a DataFrame with stage number and file count
    """
    session = Session()
    try:
        # Get all stages
        stages = session.query(Stage).all()
        
        summary_data = []
        for stage in stages:
            # Count spectra for this stage
            file_count = session.query(Spectrum).filter_by(stage_id=stage.id).count()
            
            summary_data.append({
                'Stage': stage.stage_number,
                'Description': stage.description or '',
                'Files': file_count
            })
        
        # Convert to DataFrame
        if summary_data:
            return pd.DataFrame(summary_data)
        else:
            return pd.DataFrame(columns=['Stage', 'Description', 'Files'])
    except Exception as e:
        print(f"Error getting stage summary: {str(e)}")
        return pd.DataFrame(columns=['Stage', 'Description', 'Files'])
    finally:
        session.close()

# Only run if this script is executed directly
if __name__ == "__main__":
    init_db()