import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
from mpl_toolkits.mplot3d import Axes3D

def plot_single_spectrum(stage, file_num, data):
    """
    Plot a single spectrum for a specific stage and file
    Returns the figure object
    """
    if stage not in data or file_num not in data[stage]:
        print(f"Error: Data for stage {stage}, file {file_num} not found.")
        return None
    
    wavelength = data[stage][file_num]['wavelength']
    intensity = data[stage][file_num]['intensity']
    
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(wavelength, intensity)
    ax.set_title(f'Spectrum for Stage {stage}, File {file_num:03d}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Intensity')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def plot_zoomed_spectrum(stage, file_num, data, zoom_range):
    """
    Plot a zoomed spectrum for a specific stage and file
    Returns the figure object
    """
    if stage not in data or file_num not in data[stage]:
        print(f"Error: Data for stage {stage}, file {file_num} not found.")
        return None
    
    wavelength = data[stage][file_num]['wavelength']
    intensity = data[stage][file_num]['intensity']
    
    # Filter data to zoom range
    mask = (wavelength >= zoom_range[0]) & (wavelength <= zoom_range[1])
    zoomed_wavelength = wavelength[mask]
    zoomed_intensity = intensity[mask]
    
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(zoomed_wavelength, zoomed_intensity)
    ax.set_title(f'Zoomed Spectrum for Stage {stage}, File {file_num:03d} ({zoom_range[0]}-{zoom_range[1]} nm)')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Intensity')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def plot_stage_overview(stage, data):
    """
    Plot an overview of selected spectra in a stage
    Returns the figure object
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    fig, ax = plt.subplots(figsize=(15, 8))
    
    # Plot every 10th spectrum to avoid overcrowding
    for i, file_num in enumerate(file_nums):
        if i % 10 == 0:  # Plot every 10th spectrum
            wavelength = data[stage][file_num]['wavelength']
            intensity = data[stage][file_num]['intensity']
            ax.plot(wavelength, intensity, label=f'File {file_num:03d}')
    
    ax.set_title(f'Selected Spectra for Stage {stage}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Intensity')
    ax.grid(True, alpha=0.3)
    ax.legend(loc='best')
    plt.tight_layout()
    
    return fig

def plot_heatmap(stage, data):
    """
    Create a heatmap visualization of all spectra in a stage
    Returns the figure object
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Get the wavelength from the first file
    wavelength = data[stage][file_nums[0]]['wavelength']
    
    # Create a 2D array for the heatmap
    intensity_matrix = np.zeros((len(file_nums), len(wavelength)))
    
    for i, file_num in enumerate(file_nums):
        intensity_matrix[i, :] = data[stage][file_num]['intensity']
    
    fig, ax = plt.subplots(figsize=(15, 10))
    im = ax.imshow(
        intensity_matrix, 
        aspect='auto', 
        cmap='viridis',
        extent=[wavelength[0], wavelength[-1], file_nums[-1], file_nums[0]]
    )
    cbar = plt.colorbar(im, ax=ax, label='Intensity')
    ax.set_title(f'Heatmap of Spectra for Stage {stage}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('File Number')
    plt.tight_layout()
    
    return fig

def plot_3d_surface(stage, data):
    """
    Create a 3D surface plot of all spectra in a stage using Matplotlib
    Returns the figure object
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Get the wavelength from the first file
    wavelength = data[stage][file_nums[0]]['wavelength']
    
    # Create a 2D array for the surface
    intensity_matrix = np.zeros((len(file_nums), len(wavelength)))
    
    for i, file_num in enumerate(file_nums):
        intensity_matrix[i, :] = data[stage][file_num]['intensity']
    
    # Create the meshgrid for the 3D plot
    X, Y = np.meshgrid(wavelength, file_nums)
    
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot the surface
    surf = ax.plot_surface(X, Y, intensity_matrix, cmap='viridis', edgecolor='none', alpha=0.8)
    
    ax.set_title(f'3D Surface Plot of Spectra for Stage {stage}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('File Number')
    ax.set_zlabel('Intensity')
    
    # Add a color bar
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5, label='Intensity')
    
    return fig

def plot_3d_surface_plotly(stage, data):
    """
    Create an interactive 3D surface plot of all spectra in a stage using Plotly
    Returns the plotly figure object
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Get the wavelength from the first file
    wavelength = data[stage][file_nums[0]]['wavelength']
    
    # Create a 2D array for the surface
    intensity_matrix = np.zeros((len(file_nums), len(wavelength)))
    
    for i, file_num in enumerate(file_nums):
        intensity_matrix[i, :] = data[stage][file_num]['intensity']
    
    # Create the plotly figure
    fig = go.Figure(data=[
        go.Surface(
            z=intensity_matrix,
            x=wavelength,
            y=file_nums,
            colorscale='Viridis',
            colorbar=dict(title='Intensity')
        )
    ])
    
    fig.update_layout(
        title=f'3D Surface Plot of Spectra for Stage {stage}',
        scene=dict(
            xaxis_title='Wavelength (nm)',
            yaxis_title='File Number',
            zaxis_title='Intensity',
            aspectratio=dict(x=1, y=1, z=0.7)
        ),
        width=900,
        height=700,
        margin=dict(l=0, r=0, b=0, t=40)
    )
    
    return fig

def plot_histogram(stages, data):
    """
    Plot a histogram of spectral intensities for multiple stages
    Returns the figure object
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    for stage in stages:
        if stage not in data:
            continue
        
        # Get all file numbers in this stage
        file_nums = sorted(data[stage].keys())
        
        # Collect all intensities from this stage
        all_intensities = []
        for file_num in file_nums:
            all_intensities.extend(data[stage][file_num]['intensity'])
        
        # Plot histogram
        ax.hist(all_intensities, bins=50, alpha=0.5, label=f'Stage {stage}')
    
    ax.set_title("Histogram of Spectral Intensities by Contamination Stage")
    ax.set_xlabel("Intensity")
    ax.set_ylabel("Frequency")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def plot_box_plot(stages, data):
    """
    Plot a box plot of intensity distributions for multiple stages
    Returns the figure object
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Collect intensity data for each stage
    intensity_data = []
    stage_labels = []
    
    for stage in stages:
        if stage not in data:
            continue
        
        # Get all file numbers in this stage
        file_nums = sorted(data[stage].keys())
        
        # Collect sample of intensities from this stage (to avoid memory issues)
        stage_intensities = []
        for file_num in file_nums:
            # Take a sample of intensities
            intensities = data[stage][file_num]['intensity']
            sample_size = min(1000, len(intensities))
            sample_indices = np.linspace(0, len(intensities)-1, sample_size, dtype=int)
            stage_intensities.extend(intensities[sample_indices])
        
        intensity_data.append(stage_intensities)
        stage_labels.append(f'Stage {stage}')
    
    # Plot box plot
    ax.boxplot(intensity_data, labels=stage_labels)
    ax.set_title("Boxplot of Intensity Distributions by Contamination Stage")
    ax.set_ylabel("Intensity")
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def plot_kde(stages, data):
    """
    Plot a KDE of intensity distributions for multiple stages
    Returns the figure object
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    for stage in stages:
        if stage not in data:
            continue
        
        # Get all file numbers in this stage
        file_nums = sorted(data[stage].keys())
        
        # Collect sample of intensities from this stage (to avoid memory issues)
        stage_intensities = []
        for file_num in file_nums:
            # Take a sample of intensities
            intensities = data[stage][file_num]['intensity']
            sample_size = min(1000, len(intensities))
            sample_indices = np.linspace(0, len(intensities)-1, sample_size, dtype=int)
            stage_intensities.extend(intensities[sample_indices])
        
        # Plot KDE
        sns.kdeplot(stage_intensities, label=f'Stage {stage}', fill=True, alpha=0.4, ax=ax)
    
    ax.set_title("Kernel Density Estimate (KDE) of Intensities by Stage")
    ax.set_xlabel("Intensity")
    ax.set_ylabel("Density")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def plot_line_comparison(stages, data):
    """
    Plot a line comparison of spectra across multiple stages
    Returns the figure object
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    for stage in stages:
        if stage not in data:
            continue
        
        # Get a representative file (middle file)
        file_nums = sorted(data[stage].keys())
        if not file_nums:
            continue
        
        middle_file = file_nums[len(file_nums) // 2]
        
        wavelength = data[stage][middle_file]['wavelength']
        intensity = data[stage][middle_file]['intensity']
        
        ax.plot(wavelength, intensity, label=f'Stage {stage}')
    
    ax.set_title("Spectral Line Plot Across Contamination Stages")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("Intensity")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return fig

def generate_all_visualizations(data, output_dir):
    """
    Generate all visualizations and save to the output directory
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get all stages
    stages = sorted(data.keys())
    
    # Generate visualizations for each stage
    for stage in stages:
        print(f"Generating visualizations for Stage {stage}...")
        
        # Get all file numbers in this stage
        file_nums = sorted(data[stage].keys())
        
        # Generate stage overview
        overview_fig = plot_stage_overview(stage, data)
        if overview_fig:
            overview_fig.savefig(os.path.join(output_dir, f'stage{stage}_overview.png'), dpi=300)
            plt.close(overview_fig)
        
        # Generate heatmap
        heatmap_fig = plot_heatmap(stage, data)
        if heatmap_fig:
            heatmap_fig.savefig(os.path.join(output_dir, f'stage{stage}_heatmap.png'), dpi=300)
            plt.close(heatmap_fig)
        
        # Generate 3D surface plot
        surface_fig = plot_3d_surface(stage, data)
        if surface_fig:
            surface_fig.savefig(os.path.join(output_dir, f'stage{stage}_3dsurface.png'), dpi=300)
            plt.close(surface_fig)
        
        # Generate sample individual spectra (first, middle, last)
        if file_nums:
            first_file = file_nums[0]
            middle_file = file_nums[len(file_nums) // 2]
            last_file = file_nums[-1]
            
            for file_num in [first_file, middle_file, last_file]:
                spectrum_fig = plot_single_spectrum(stage, file_num, data)
                if spectrum_fig:
                    spectrum_fig.savefig(os.path.join(output_dir, f'spectrum_stage{stage}_file{file_num:03d}.png'), dpi=300)
                    plt.close(spectrum_fig)
    
    # Generate multi-stage comparisons
    if len(stages) > 1:
        # Histogram
        hist_fig = plot_histogram(stages, data)
        if hist_fig:
            hist_fig.savefig(os.path.join(output_dir, 'histogram_comparison.png'), dpi=300)
            plt.close(hist_fig)
        
        # Box plot
        box_fig = plot_box_plot(stages, data)
        if box_fig:
            box_fig.savefig(os.path.join(output_dir, 'boxplot_comparison.png'), dpi=300)
            plt.close(box_fig)
        
        # KDE plot
        kde_fig = plot_kde(stages, data)
        if kde_fig:
            kde_fig.savefig(os.path.join(output_dir, 'kde_comparison.png'), dpi=300)
            plt.close(kde_fig)
        
        # Line comparison
        line_fig = plot_line_comparison(stages, data)
        if line_fig:
            line_fig.savefig(os.path.join(output_dir, 'line_comparison.png'), dpi=300)
            plt.close(line_fig)
    
    print(f"All visualizations saved to '{output_dir}'")
