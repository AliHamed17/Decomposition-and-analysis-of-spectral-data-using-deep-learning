import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# === Load Sample Spectra from Each Contamination Stage ===
base_path = "realData_final_project"
stages = ["stage0", "stage1", "stage2", "stage3"]

# Count files in each stage
stage_file_counts = {stage: len(os.listdir(os.path.join(base_path, stage))) for stage in stages}
print("📊 Number of CSV files in each stage folder:")
for stage, count in stage_file_counts.items():
    print(f"{stage}: {count} files")

# Load the first sample from each stage
sample_files = {
    stage: os.path.join(base_path, stage, sorted(os.listdir(os.path.join(base_path, stage)))[0])
    for stage in stages
}

def load_spectrum(path):
    df = pd.read_csv(path, header=None)
    df.columns = ['Wavelength', 'Intensity']
    df = df.drop(index=0)
    df['Wavelength'] = df['Wavelength'].astype(float)
    df['Intensity'] = df['Intensity'].astype(float)
    return df

spectra = {stage: load_spectrum(path) for stage, path in sample_files.items()}

# Report shape
print("\n📐 Shape of each loaded sample (rows = wavelength points):")
for stage, df in spectra.items():
    print(f"{stage}: {df.shape}")

# === Create output directory ===
output_dir = "real_data_plots"
os.makedirs(output_dir, exist_ok=True)

# === Script 1: Line Plot ===
plt.figure(figsize=(12, 6))
for stage, df in spectra.items():
    plt.plot(df['Wavelength'], df['Intensity'], label=f"{stage}")
plt.title("Spectral Line Plot Across Contamination Stages")
plt.xlabel("Wavelength")
plt.ylabel("Intensity")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, "line_plot.png"))
plt.show()

# === Script 2: Histogram ===
plt.figure(figsize=(12, 6))
for stage, df in spectra.items():
    plt.hist(df['Intensity'], bins=50, alpha=0.5, label=stage)
plt.title("Histogram of Spectral Intensities by Contamination Stage")
plt.xlabel("Intensity")
plt.ylabel("Frequency")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, "histogram.png"))
plt.show()

# === Script 3: Box Plot ===
plt.figure(figsize=(10, 6))
intensity_data = [df['Intensity'].values for df in spectra.values()]
plt.boxplot(intensity_data, labels=spectra.keys())
plt.title("Boxplot of Intensity Distributions by Contamination Stage")
plt.ylabel("Intensity")
plt.grid(True)
plt.savefig(os.path.join(output_dir, "boxplot.png"))
plt.show()

# === Script 4: KDE Plot ===
plt.figure(figsize=(12, 6))
for stage, df in spectra.items():
    sns.kdeplot(df['Intensity'], label=stage, fill=True, alpha=0.4)
plt.title("Kernel Density Estimate (KDE) of Intensities by Stage")
plt.xlabel("Intensity")
plt.ylabel("Density")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, "kde_plot.png"))
plt.show()

# === Script 5: Zoomed Line Plot ===
plt.figure(figsize=(12, 6))
zoom_range = (850, 875)
for stage, df in spectra.items():
    df_zoomed = df[(df['Wavelength'] >= zoom_range[0]) & (df['Wavelength'] <= zoom_range[1])]
    plt.plot(df_zoomed['Wavelength'], df_zoomed['Intensity'], label=stage)
plt.title(f"Zoomed-In Spectral Comparison ({zoom_range[0]}–{zoom_range[1]} nm)")
plt.xlabel("Wavelength")
plt.ylabel("Intensity")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, "zoomed_line_plot.png"))
plt.show()

# === Script 6: Scatter Plot ===
plt.figure(figsize=(12, 6))
colors = {'stage0': 'blue', 'stage1': 'green', 'stage2': 'orange', 'stage3': 'red'}
for stage, df in spectra.items():
    plt.scatter(df['Wavelength'], df['Intensity'], s=10, alpha=0.5, label=stage, color=colors[stage])
plt.title("Scatter Plot of Spectral Data Points")
plt.xlabel("Wavelength")
plt.ylabel("Intensity")
plt.legend()
plt.grid(True)
plt.savefig(os.path.join(output_dir, "scatter_plot.png"))
plt.show()
