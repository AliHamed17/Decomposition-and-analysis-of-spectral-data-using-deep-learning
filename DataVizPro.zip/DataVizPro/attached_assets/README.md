# Real Data Final Project - Data Extraction and Visualization

This project contains scripts to extract and visualize spectral data from the `realData_final_project` directory.

## Setup

1. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Step 1: Extract Data

Run the data extraction script to process all CSV files from all stages:

```bash
python extract_data.py
```

This will create an `extracted_data.npz` file containing all the compressed data.

### Step 2: Visualize Data

Run the visualization script to generate various plots:

```bash
python visualize_data.py
```

This will create multiple visualization types for each stage in the `plots` directory:

- Individual spectrum plots
- Stage overview plots (showing selected spectra)
- Heatmap visualizations
- 3D surface plots

## Visualizations Explained

1. **Individual Spectrum Plots**: Show the wavelength vs. intensity for a single file
2. **Stage Overview**: Shows multiple spectra from the same stage to compare patterns
3. **Heatmap**: 2D color map showing intensity across all files and wavelengths
4. **3D Surface**: 3D visualization showing the intensity surface across files and wavelengths

## Files Structure

- `extract_data.py`: Script to extract data from CSV files
- `visualize_data.py`: Script to generate visualizations
- `requirements.txt`: Required Python dependencies
- `extracted_data.npz`: Compressed data file (created by extract_data.py)
- `plots/`: Directory containing generated visualizations 