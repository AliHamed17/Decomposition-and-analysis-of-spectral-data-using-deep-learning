import os
import pandas as pd
import numpy as np

def extract_data_from_stage(stage_folder):
    """
    Extract data from all CSV files in a stage folder
    Returns a dictionary with file number as key and DataFrame as value
    """
    data_dict = {}
    
    # Get all CSV files in the stage folder
    csv_files = [f for f in os.listdir(stage_folder) if f.endswith('.csv')]
    
    # Sort files numerically
    csv_files.sort(key=lambda x: int(x.split('.')[0]))
    
    for csv_file in csv_files:
        file_path = os.path.join(stage_folder, csv_file)
        file_number = int(csv_file.split('.')[0])
        
        # Read CSV
        df = pd.read_csv(file_path)
        data_dict[file_number] = df
    
    return data_dict

def extract_all_data():
    """
    Extract data from all stages
    Returns a dictionary with stage number as key and another dictionary as value
    The inner dictionary has file number as key and DataFrame as value
    """
    base_folder = 'realData_final_project'
    all_data = {}
    
    # Get all stage folders
    stage_folders = [f for f in os.listdir(base_folder) if f.startswith('stage')]
    
    # Sort stage folders
    stage_folders.sort(key=lambda x: int(x[5:]))
    
    for stage_folder in stage_folders:
        stage_number = int(stage_folder[5:])
        stage_path = os.path.join(base_folder, stage_folder)
        
        # Extract data from stage
        stage_data = extract_data_from_stage(stage_path)
        all_data[stage_number] = stage_data
    
    return all_data

def save_extracted_data(data, output_file='extracted_data.npz'):
    """
    Save extracted data to a compressed NumPy file
    """
    # Convert dictionary of DataFrames to dictionary of arrays
    processed_data = {}
    
    for stage, stage_data in data.items():
        for file_num, df in stage_data.items():
            key = f'stage{stage}_file{file_num}'
            # Save wavelength and intensity as separate arrays
            processed_data[f'{key}_wavelength'] = df['Wavelength'].values
            processed_data[f'{key}_intensity'] = df['Intensity'].values
    
    # Save to compressed file
    np.savez_compressed(output_file, **processed_data)
    print(f'Data saved to {output_file}')

if __name__ == "__main__":
    # Extract all data
    print("Extracting data from all stages...")
    all_data = extract_all_data()
    
    # Save extracted data
    save_extracted_data(all_data)
    
    # Print summary
    total_files = sum(len(stage_data) for stage_data in all_data.values())
    print(f"Extracted data from {len(all_data)} stages, {total_files} files total") 