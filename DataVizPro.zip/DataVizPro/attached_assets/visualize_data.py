import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

def load_data(file_path='extracted_data.npz'):
    """
    Load data from the saved NPZ file
    """
    if not os.path.exists(file_path):
        print(f"Error: Data file {file_path} not found. Run extract_data.py first.")
        return None
    
    # Load the compressed data
    data = np.load(file_path)
    return data

def organize_data(data):
    """
    Organize data by stage and file number
    Returns a dictionary with stage -> file number -> {'wavelength', 'intensity'}
    """
    organized_data = {}
    
    # Get all keys in the data
    keys = list(data.keys())
    
    for key in keys:
        if 'wavelength' in key:
            # Parse stage and file from key name (format: stage{stage}_file{file}_wavelength)
            parts = key.split('_')
            stage = int(parts[0][5:])
            file_num = int(parts[1][4:])
            
            # Initialize dictionaries if they don't exist
            if stage not in organized_data:
                organized_data[stage] = {}
            if file_num not in organized_data[stage]:
                organized_data[stage][file_num] = {}
            
            # Add wavelength data
            organized_data[stage][file_num]['wavelength'] = data[key]
            
            # Add intensity data
            intensity_key = key.replace('wavelength', 'intensity')
            organized_data[stage][file_num]['intensity'] = data[intensity_key]
    
    return organized_data

def plot_single_spectrum(stage, file_num, data):
    """
    Plot a single spectrum for a specific stage and file
    """
    if stage not in data or file_num not in data[stage]:
        print(f"Error: Data for stage {stage}, file {file_num} not found.")
        return
    
    wavelength = data[stage][file_num]['wavelength']
    intensity = data[stage][file_num]['intensity']
    
    plt.figure(figsize=(12, 6))
    plt.plot(wavelength, intensity)
    plt.title(f'Spectrum for Stage {stage}, File {file_num:03d}')
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('Intensity')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    # Save the plot
    os.makedirs('plots', exist_ok=True)
    plt.savefig(f'plots/spectrum_stage{stage}_file{file_num:03d}.png', dpi=300)
    plt.close()

def plot_stage_overview(stage, data):
    """
    Plot an overview of all spectra in a stage
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    plt.figure(figsize=(15, 8))
    
    # Plot every 10th spectrum to avoid overcrowding
    for i, file_num in enumerate(file_nums):
        if i % 10 == 0:  # Plot every 10th spectrum
            wavelength = data[stage][file_num]['wavelength']
            intensity = data[stage][file_num]['intensity']
            plt.plot(wavelength, intensity, label=f'File {file_num:03d}')
    
    plt.title(f'Selected Spectra for Stage {stage}')
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('Intensity')
    plt.grid(True, alpha=0.3)
    plt.legend(loc='best')
    plt.tight_layout()
    
    # Save the plot
    os.makedirs('plots', exist_ok=True)
    plt.savefig(f'plots/stage{stage}_overview.png', dpi=300)
    plt.close()

def plot_heatmap(stage, data):
    """
    Create a heatmap visualization of all spectra in a stage
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Get the wavelength from the first file
    wavelength = data[stage][file_nums[0]]['wavelength']
    
    # Create a 2D array for the heatmap
    intensity_matrix = np.zeros((len(file_nums), len(wavelength)))
    
    for i, file_num in enumerate(file_nums):
        intensity_matrix[i, :] = data[stage][file_num]['intensity']
    
    plt.figure(figsize=(15, 10))
    plt.imshow(
        intensity_matrix, 
        aspect='auto', 
        cmap='viridis',
        extent=[wavelength[0], wavelength[-1], file_nums[-1], file_nums[0]]
    )
    plt.colorbar(label='Intensity')
    plt.title(f'Heatmap of Spectra for Stage {stage}')
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('File Number')
    plt.tight_layout()
    
    # Save the plot
    os.makedirs('plots', exist_ok=True)
    plt.savefig(f'plots/stage{stage}_heatmap.png', dpi=300)
    plt.close()

def plot_3d_surface(stage, data):
    """
    Create a 3D surface plot of all spectra in a stage
    """
    if stage not in data:
        print(f"Error: Data for stage {stage} not found.")
        return
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Get the wavelength from the first file
    wavelength = data[stage][file_nums[0]]['wavelength']
    
    # Create a 2D array for the surface
    intensity_matrix = np.zeros((len(file_nums), len(wavelength)))
    
    for i, file_num in enumerate(file_nums):
        intensity_matrix[i, :] = data[stage][file_num]['intensity']
    
    # Create the meshgrid for the 3D plot
    X, Y = np.meshgrid(wavelength, file_nums)
    
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot the surface
    surf = ax.plot_surface(X, Y, intensity_matrix, cmap='viridis', edgecolor='none', alpha=0.8)
    
    ax.set_title(f'3D Surface Plot of Spectra for Stage {stage}')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('File Number')
    ax.set_zlabel('Intensity')
    
    # Add a color bar
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5, label='Intensity')
    
    # Save the plot
    os.makedirs('plots', exist_ok=True)
    plt.savefig(f'plots/stage{stage}_3dsurface.png', dpi=300)
    plt.close()

def run_visualizations():
    """
    Run all visualizations
    """
    # Load data
    data_file = load_data()
    if data_file is None:
        return
    
    # Organize data
    organized_data = organize_data(data_file)
    
    # Get all stages
    stages = sorted(organized_data.keys())
    
    for stage in stages:
        print(f"Generating visualizations for Stage {stage}...")
        
        # Plot stage overview
        plot_stage_overview(stage, organized_data)
        
        # Plot heatmap
        plot_heatmap(stage, organized_data)
        
        # Plot 3D surface
        plot_3d_surface(stage, organized_data)
        
        # Plot a few individual spectra (first, middle, last)
        file_nums = sorted(organized_data[stage].keys())
        plot_single_spectrum(stage, file_nums[0], organized_data)
        plot_single_spectrum(stage, file_nums[len(file_nums)//2], organized_data)
        plot_single_spectrum(stage, file_nums[-1], organized_data)
    
    print("All visualizations completed and saved to 'plots' directory.")

if __name__ == "__main__":
    run_visualizations() 