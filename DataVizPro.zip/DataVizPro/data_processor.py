import os
import numpy as np
import pandas as pd
from io import BytesIO

def extract_data_from_stage(stage_folder):
    """
    Extract data from all CSV files in a stage folder
    Returns a dictionary with file number as key and DataFrame as value
    """
    data_dict = {}
    
    # Get all CSV files in the stage folder
    csv_files = [f for f in os.listdir(stage_folder) if f.endswith('.csv')]
    
    # Sort files numerically
    csv_files.sort(key=lambda x: int(x.split('.')[0]))
    
    for csv_file in csv_files:
        file_path = os.path.join(stage_folder, csv_file)
        file_number = int(csv_file.split('.')[0])
        
        # Read CSV
        try:
            df = pd.read_csv(file_path, header=None)
            # Check if the first row contains headers
            if isinstance(df.iloc[0, 0], str) and isinstance(df.iloc[0, 1], str):
                # Use first row as header and skip it
                df.columns = ['Wavelength', 'Intensity']
                df = df.iloc[1:]
            else:
                # No header, add column names
                df.columns = ['Wavelength', 'Intensity']
            
            # Convert to numeric
            df['Wavelength'] = pd.to_numeric(df['Wavelength'], errors='coerce')
            df['Intensity'] = pd.to_numeric(df['Intensity'], errors='coerce')
            
            # Drop any rows with NaN values
            df = df.dropna()
            
            data_dict[file_number] = df
        except Exception as e:
            print(f"Error reading file {file_path}: {str(e)}")
    
    return data_dict

def extract_all_data(base_folder='realData_final_project'):
    """
    Extract data from all stages
    Returns a dictionary with stage number as key and another dictionary as value
    The inner dictionary has file number as key and DataFrame as value
    """
    all_data = {}
    
    # Get all stage folders
    stage_folders = [f for f in os.listdir(base_folder) if f.startswith('stage')]
    
    # Sort stage folders
    stage_folders.sort(key=lambda x: int(x[5:]))
    
    for stage_folder in stage_folders:
        stage_number = int(stage_folder[5:])
        stage_path = os.path.join(base_folder, stage_folder)
        
        # Extract data from stage
        stage_data = extract_data_from_stage(stage_path)
        all_data[stage_number] = stage_data
    
    return all_data

def save_extracted_data(data, output_file='extracted_data.npz'):
    """
    Save extracted data to a compressed NumPy file
    output_file can be a string path or a BytesIO object
    """
    # Convert dictionary of DataFrames to dictionary of arrays
    processed_data = {}
    
    for stage, stage_data in data.items():
        for file_num, df in stage_data.items():
            key = f'stage{stage}_file{file_num}'
            # Save wavelength and intensity as separate arrays
            processed_data[f'{key}_wavelength'] = df['Wavelength'].values
            processed_data[f'{key}_intensity'] = df['Intensity'].values
    
    # Save to compressed file
    np.savez_compressed(output_file, **processed_data)
    
    if isinstance(output_file, str):
        print(f'Data saved to {output_file}')

def organize_data(data):
    """
    Organize data by stage and file number
    Returns a dictionary with stage -> file number -> {'wavelength', 'intensity'}
    """
    organized_data = {}
    
    # Check if data is in DataFrame format (from extract_all_data) or NPZ format (from loaded file)
    if isinstance(data, dict) and data:
        # Get first value to check format
        first_key = list(data.keys())[0]
        first_value = data[first_key]
        
        if isinstance(first_value, dict) and all(isinstance(v, pd.DataFrame) for v in first_value.values()):
            # DataFrame format from extract_all_data
            for stage, stage_data in data.items():
                organized_data[stage] = {}
                for file_num, df in stage_data.items():
                    organized_data[stage][file_num] = {
                        'wavelength': df['Wavelength'].values,
                        'intensity': df['Intensity'].values
                    }
        else:
            # NPZ format with string keys like 'stage0_file1_wavelength'
            keys = list(data.keys())
            
            for key in keys:
                if isinstance(key, str) and 'wavelength' in key:
                    # Parse stage and file from key name (format: stage{stage}_file{file}_wavelength)
                    parts = key.split('_')
                    stage = int(parts[0][5:])
                    file_num = int(parts[1][4:])
                    
                    # Initialize dictionaries if they don't exist
                    if stage not in organized_data:
                        organized_data[stage] = {}
                    if file_num not in organized_data[stage]:
                        organized_data[stage][file_num] = {}
                    
                    # Add wavelength data
                    organized_data[stage][file_num]['wavelength'] = data[key]
                    
                    # Add intensity data
                    intensity_key = key.replace('wavelength', 'intensity')
                    if intensity_key in data:
                        organized_data[stage][file_num]['intensity'] = data[intensity_key]
    
    return organized_data
