import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def calculate_stage_statistics(data, stage):
    """
    Calculate statistics for a specific stage
    Returns a DataFrame with statistics for each file
    """
    if stage not in data:
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Calculate statistics for each file
    stats_data = []
    for file_num in file_nums:
        intensity = data[stage][file_num]['intensity']
        
        stats = {
            'File': file_num,
            'Min': np.min(intensity),
            'Max': np.max(intensity),
            'Mean': np.mean(intensity),
            'Median': np.median(intensity),
            'Std Dev': np.std(intensity)
        }
        
        stats_data.append(stats)
    
    # Convert to DataFrame
    stats_df = pd.DataFrame(stats_data)
    
    # Calculate overall statistics
    overall_stats = {
        'File': 'Overall',
        'Min': stats_df['Min'].min(),
        'Max': stats_df['Max'].max(),
        'Mean': stats_df['Mean'].mean(),
        'Median': stats_df['Median'].median(),
        'Std Dev': stats_df['Std Dev'].mean()
    }
    
    # Append overall statistics
    stats_df = pd.concat([stats_df, pd.DataFrame([overall_stats])], ignore_index=True)
    
    return stats_df

def plot_stage_statistics(data, stage):
    """
    Plot statistics for a specific stage
    Returns a figure object
    """
    if stage not in data:
        return None
    
    # Get all file numbers in this stage
    file_nums = sorted(data[stage].keys())
    
    # Calculate statistics for each file
    min_vals = []
    max_vals = []
    mean_vals = []
    median_vals = []
    std_vals = []
    
    for file_num in file_nums:
        intensity = data[stage][file_num]['intensity']
        
        min_vals.append(np.min(intensity))
        max_vals.append(np.max(intensity))
        mean_vals.append(np.mean(intensity))
        median_vals.append(np.median(intensity))
        std_vals.append(np.std(intensity))
    
    # Create figure
    fig, axs = plt.subplots(2, 2, figsize=(15, 10))
    
    # Plot min, max, mean, median
    axs[0, 0].plot(file_nums, min_vals, 'b-', label='Min')
    axs[0, 0].plot(file_nums, max_vals, 'r-', label='Max')
    axs[0, 0].set_title('Min and Max Intensity')
    axs[0, 0].set_xlabel('File Number')
    axs[0, 0].set_ylabel('Intensity')
    axs[0, 0].legend()
    axs[0, 0].grid(True, alpha=0.3)
    
    axs[0, 1].plot(file_nums, mean_vals, 'g-', label='Mean')
    axs[0, 1].plot(file_nums, median_vals, 'm-', label='Median')
    axs[0, 1].set_title('Mean and Median Intensity')
    axs[0, 1].set_xlabel('File Number')
    axs[0, 1].set_ylabel('Intensity')
    axs[0, 1].legend()
    axs[0, 1].grid(True, alpha=0.3)
    
    # Plot standard deviation
    axs[1, 0].plot(file_nums, std_vals, 'k-')
    axs[1, 0].set_title('Standard Deviation of Intensity')
    axs[1, 0].set_xlabel('File Number')
    axs[1, 0].set_ylabel('Standard Deviation')
    axs[1, 0].grid(True, alpha=0.3)
    
    # Plot histogram of mean values
    sns.histplot(mean_vals, kde=True, ax=axs[1, 1])
    axs[1, 1].set_title('Distribution of Mean Intensity')
    axs[1, 1].set_xlabel('Mean Intensity')
    axs[1, 1].set_ylabel('Frequency')
    axs[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    return fig

def calculate_summary_statistics(data):
    """
    Calculate summary statistics for all stages
    Returns a DataFrame with statistics for each stage
    """
    # Get all stages
    stages = sorted(data.keys())
    
    # Calculate statistics for each stage
    stats_data = []
    for stage in stages:
        # Get all file numbers in this stage
        file_nums = sorted(data[stage].keys())
        
        # Collect all intensities from this stage
        all_intensities = []
        for file_num in file_nums:
            all_intensities.extend(data[stage][file_num]['intensity'])
        
        stats = {
            'Stage': stage,
            'Files': len(file_nums),
            'Min': np.min(all_intensities),
            'Max': np.max(all_intensities),
            'Mean': np.mean(all_intensities),
            'Median': np.median(all_intensities),
            'Std Dev': np.std(all_intensities)
        }
        
        stats_data.append(stats)
    
    # Convert to DataFrame
    stats_df = pd.DataFrame(stats_data)
    
    return stats_df