import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.io as pio
from datetime import datetime
import io
import base64
from PIL import Image
import warnings
warnings.filterwarnings('ignore')

class StageComparisonReportGenerator:
    def __init__(self):
        self.setup_matplotlib_style()
    
    def setup_matplotlib_style(self):
        """Setup matplotlib style for professional reports"""
        plt.style.use('default')
        plt.rcParams['figure.figsize'] = (12, 8)
        plt.rcParams['font.size'] = 10
        plt.rcParams['axes.titlesize'] = 14
        plt.rcParams['axes.labelsize'] = 12
        plt.rcParams['xtick.labelsize'] = 10
        plt.rcParams['ytick.labelsize'] = 10
        plt.rcParams['legend.fontsize'] = 10
        plt.rcParams['figure.titlesize'] = 16
    
    def generate_comprehensive_report(self, organized_data, comparison_results, sensitivity_data=None, reference_stage=0):
        """
        Generate a comprehensive PDF report with all stage comparison analysis
        """
        # Create buffer for PDF
        pdf_buffer = io.BytesIO()
        
        with PdfPages(pdf_buffer) as pdf:
            # Title page
            self.create_title_page(pdf, reference_stage)
            
            # Executive summary
            self.create_executive_summary(pdf, organized_data, comparison_results, reference_stage)
            
            # Data overview
            self.create_data_overview(pdf, organized_data)
            
            # Comparison metrics summary
            self.create_comparison_metrics_summary(pdf, comparison_results)
            
            # Statistical significance analysis
            self.create_statistical_analysis(pdf, comparison_results)
            
            # Spectral difference visualizations
            self.create_spectral_difference_plots(pdf, organized_data, comparison_results, reference_stage)
            
            # Wavelength sensitivity analysis
            if sensitivity_data:
                self.create_wavelength_sensitivity_analysis(pdf, sensitivity_data)
            
            # Detailed comparison for each stage pair
            self.create_detailed_comparisons(pdf, comparison_results)
            
            # Recommendations and conclusions
            self.create_conclusions_page(pdf, comparison_results, reference_stage)
        
        pdf_buffer.seek(0)
        return pdf_buffer
    
    def create_title_page(self, pdf, reference_stage):
        """Create professional title page"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        # Title
        ax.text(0.5, 0.8, 'Spectral Data Stage Comparison Report', 
                fontsize=24, weight='bold', ha='center', transform=ax.transAxes)
        
        # Subtitle
        ax.text(0.5, 0.75, f'Reference Stage: {reference_stage}', 
                fontsize=16, ha='center', transform=ax.transAxes)
        
        # Date
        current_date = datetime.now().strftime("%B %d, %Y")
        ax.text(0.5, 0.7, f'Generated on: {current_date}', 
                fontsize=12, ha='center', transform=ax.transAxes)
        
        # Report description
        description = """
        This report provides comprehensive analysis of spectral data differences
        across contamination stages. It includes statistical comparisons,
        visualization of spectral changes, wavelength sensitivity analysis,
        and detailed metrics for contamination detection.
        """
        ax.text(0.5, 0.5, description, fontsize=12, ha='center', va='center',
                transform=ax.transAxes, wrap=True, 
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightblue", alpha=0.3))
        
        # Footer
        ax.text(0.5, 0.1, 'Advanced Spectral Data Analyzer Pro', 
                fontsize=10, ha='center', transform=ax.transAxes, style='italic')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_executive_summary(self, pdf, organized_data, comparison_results, reference_stage):
        """Create executive summary page"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        ax.text(0.5, 0.95, 'Executive Summary', 
                fontsize=20, weight='bold', ha='center', transform=ax.transAxes)
        
        # Calculate summary statistics
        total_stages = len(organized_data)
        total_comparisons = len(comparison_results)
        
        # Find most significant comparison
        most_significant = self.find_most_significant_comparison(comparison_results)
        
        # Create summary text
        summary_text = f"""
        DATA OVERVIEW:
        • Total Contamination Stages Analyzed: {total_stages}
        • Reference Stage: {reference_stage}
        • Stage Comparisons Performed: {total_comparisons}
        
        KEY FINDINGS:
        • Most Significant Difference: {most_significant['comparison']}
        • Highest RMSE: {most_significant['rmse']:.4f}
        • Lowest Correlation: {most_significant['correlation']:.4f}
        • Largest Effect Size: {most_significant['effect_size']:.4f}
        
        STATISTICAL SIGNIFICANCE:
        • Significant Comparisons (p < 0.05): {self.count_significant_comparisons(comparison_results)}
        • Average Effect Size: {self.calculate_average_effect_size(comparison_results):.4f}
        
        CONTAMINATION INDICATORS:
        • Clear spectral evolution patterns detected
        • Wavelength-specific sensitivity identified
        • Contamination progression quantified
        • Statistical significance confirmed for major transitions
        """
        
        ax.text(0.1, 0.8, summary_text, fontsize=11, va='top', transform=ax.transAxes,
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightyellow", alpha=0.5))
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_data_overview(self, pdf, organized_data):
        """Create data overview with sample counts and basic statistics"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        # Stage distribution
        stages = list(organized_data.keys())
        file_counts = [len(organized_data[stage]) for stage in stages]
        
        ax1.bar(stages, file_counts, color='skyblue', alpha=0.7)
        ax1.set_title('Files per Stage', fontsize=14, weight='bold')
        ax1.set_xlabel('Stage Number')
        ax1.set_ylabel('Number of Files')
        ax1.grid(axis='y', alpha=0.3)
        
        # Sample spectrum from each stage
        ax2.set_title('Sample Spectra Overview', fontsize=14, weight='bold')
        colors = plt.cm.tab10(np.linspace(0, 1, len(stages)))
        
        for i, stage in enumerate(stages[:5]):  # Limit to first 5 stages
            if stage in organized_data:
                first_file = list(organized_data[stage].keys())[0]
                wavelength = organized_data[stage][first_file]['wavelength']
                intensity = organized_data[stage][first_file]['intensity']
                ax2.plot(wavelength, intensity, color=colors[i], label=f'Stage {stage}', alpha=0.7)
        
        ax2.set_xlabel('Wavelength')
        ax2.set_ylabel('Intensity')
        ax2.legend()
        ax2.grid(alpha=0.3)
        
        # Data quality metrics
        quality_metrics = self.calculate_data_quality_metrics(organized_data)
        metrics_df = pd.DataFrame(list(quality_metrics.items()), columns=['Metric', 'Value'])
        
        ax3.axis('tight')
        ax3.axis('off')
        table = ax3.table(cellText=metrics_df.values, colLabels=metrics_df.columns,
                         cellLoc='center', loc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1.2, 1.5)
        ax3.set_title('Data Quality Metrics', fontsize=14, weight='bold', pad=20)
        
        # Wavelength range distribution
        wavelength_ranges = []
        for stage_data in organized_data.values():
            for file_data in stage_data.values():
                wavelength = file_data['wavelength']
                wavelength_ranges.append([np.min(wavelength), np.max(wavelength)])
        
        wavelength_ranges = np.array(wavelength_ranges)
        ax4.scatter(wavelength_ranges[:, 0], wavelength_ranges[:, 1], alpha=0.6)
        ax4.set_title('Wavelength Coverage', fontsize=14, weight='bold')
        ax4.set_xlabel('Minimum Wavelength')
        ax4.set_ylabel('Maximum Wavelength')
        ax4.grid(alpha=0.3)
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_comparison_metrics_summary(self, pdf, comparison_results):
        """Create summary of comparison metrics"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        # Extract metrics for all comparisons
        metrics_data = []
        for comp_name, comp_data in comparison_results.items():
            if 'aggregate_metrics' in comp_data and comp_data['aggregate_metrics']:
                agg = comp_data['aggregate_metrics']
                metrics_data.append({
                    'Comparison': comp_name,
                    'RMSE': agg.get('rmse', {}).get('mean', 0),
                    'Correlation': agg.get('correlation', {}).get('mean', 0),
                    'Max_Diff': agg.get('max_absolute_diff', {}).get('mean', 0),
                    'Spectral_Angle': agg.get('spectral_angle', {}).get('mean', 0)
                })
        
        if not metrics_data:
            ax1.text(0.5, 0.5, 'No comparison data available', ha='center', va='center')
            return
        
        df = pd.DataFrame(metrics_data)
        
        # RMSE comparison
        ax1.bar(range(len(df)), df['RMSE'], color='red', alpha=0.7)
        ax1.set_title('RMSE by Comparison', fontsize=14, weight='bold')
        ax1.set_xlabel('Comparison')
        ax1.set_ylabel('RMSE')
        ax1.set_xticks(range(len(df)))
        ax1.set_xticklabels(df['Comparison'], rotation=45, ha='right')
        ax1.grid(axis='y', alpha=0.3)
        
        # Correlation comparison
        ax2.bar(range(len(df)), df['Correlation'], color='blue', alpha=0.7)
        ax2.set_title('Correlation by Comparison', fontsize=14, weight='bold')
        ax2.set_xlabel('Comparison')
        ax2.set_ylabel('Correlation')
        ax2.set_xticks(range(len(df)))
        ax2.set_xticklabels(df['Comparison'], rotation=45, ha='right')
        ax2.grid(axis='y', alpha=0.3)
        
        # Max difference
        ax3.bar(range(len(df)), df['Max_Diff'], color='green', alpha=0.7)
        ax3.set_title('Maximum Difference by Comparison', fontsize=14, weight='bold')
        ax3.set_xlabel('Comparison')
        ax3.set_ylabel('Max Difference')
        ax3.set_xticks(range(len(df)))
        ax3.set_xticklabels(df['Comparison'], rotation=45, ha='right')
        ax3.grid(axis='y', alpha=0.3)
        
        # Spectral angle
        ax4.bar(range(len(df)), df['Spectral_Angle'], color='orange', alpha=0.7)
        ax4.set_title('Spectral Angle by Comparison', fontsize=14, weight='bold')
        ax4.set_xlabel('Comparison')
        ax4.set_ylabel('Spectral Angle (degrees)')
        ax4.set_xticks(range(len(df)))
        ax4.set_xticklabels(df['Comparison'], rotation=45, ha='right')
        ax4.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_statistical_analysis(self, pdf, comparison_results):
        """Create statistical significance analysis"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        # Extract statistical data
        p_values = []
        effect_sizes = []
        comparison_names = []
        
        for comp_name, comp_data in comparison_results.items():
            stats_tests = comp_data.get('statistical_tests', {})
            p_val = stats_tests.get('t_test', {}).get('p_value', 1.0)
            effect_size = abs(stats_tests.get('effect_size', {}).get('cohens_d', 0))
            
            if not np.isnan(p_val) and not np.isnan(effect_size):
                p_values.append(p_val)
                effect_sizes.append(effect_size)
                comparison_names.append(comp_name)
        
        if not p_values:
            ax1.text(0.5, 0.5, 'No statistical data available', ha='center', va='center')
            return
        
        # P-values
        colors = ['red' if p < 0.05 else 'blue' for p in p_values]
        ax1.bar(range(len(p_values)), p_values, color=colors, alpha=0.7)
        ax1.axhline(y=0.05, color='red', linestyle='--', label='Significance threshold')
        ax1.set_title('Statistical Significance (p-values)', fontsize=14, weight='bold')
        ax1.set_xlabel('Comparison')
        ax1.set_ylabel('p-value')
        ax1.set_xticks(range(len(comparison_names)))
        ax1.set_xticklabels(comparison_names, rotation=45, ha='right')
        ax1.legend()
        ax1.grid(axis='y', alpha=0.3)
        
        # Effect sizes
        effect_colors = ['red' if es > 0.8 else 'orange' if es > 0.5 else 'green' for es in effect_sizes]
        ax2.bar(range(len(effect_sizes)), effect_sizes, color=effect_colors, alpha=0.7)
        ax2.set_title('Effect Sizes (Cohen\'s d)', fontsize=14, weight='bold')
        ax2.set_xlabel('Comparison')
        ax2.set_ylabel('Effect Size')
        ax2.set_xticks(range(len(comparison_names)))
        ax2.set_xticklabels(comparison_names, rotation=45, ha='right')
        ax2.grid(axis='y', alpha=0.3)
        
        # Significance distribution
        significant_count = sum(1 for p in p_values if p < 0.05)
        non_significant_count = len(p_values) - significant_count
        
        ax3.pie([significant_count, non_significant_count], 
                labels=['Significant (p < 0.05)', 'Not Significant'],
                colors=['red', 'blue'], autopct='%1.1f%%')
        ax3.set_title('Significance Distribution', fontsize=14, weight='bold')
        
        # Effect size interpretation
        large_effect = sum(1 for es in effect_sizes if es > 0.8)
        medium_effect = sum(1 for es in effect_sizes if 0.5 < es <= 0.8)
        small_effect = sum(1 for es in effect_sizes if es <= 0.5)
        
        ax4.pie([large_effect, medium_effect, small_effect],
                labels=['Large (>0.8)', 'Medium (0.5-0.8)', 'Small (≤0.5)'],
                colors=['red', 'orange', 'green'], autopct='%1.1f%%')
        ax4.set_title('Effect Size Distribution', fontsize=14, weight='bold')
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_spectral_difference_plots(self, pdf, organized_data, comparison_results, reference_stage):
        """Create spectral difference visualization plots"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        # Reference spectrum
        ref_spectrum = self.get_average_spectrum(organized_data[reference_stage])
        
        # Plot reference and comparison spectra
        ax1.plot(ref_spectrum['wavelength'], ref_spectrum['intensity'], 
                'k-', linewidth=2, label=f'Stage {reference_stage} (Reference)')
        
        colors = plt.cm.tab10(np.linspace(0, 1, len(organized_data)))
        for i, stage in enumerate(organized_data.keys()):
            if stage != reference_stage:
                stage_spectrum = self.get_average_spectrum(organized_data[stage])
                ax1.plot(stage_spectrum['wavelength'], stage_spectrum['intensity'],
                        color=colors[i], linewidth=1.5, alpha=0.7, label=f'Stage {stage}')
        
        ax1.set_title('Spectral Evolution', fontsize=14, weight='bold')
        ax1.set_xlabel('Wavelength')
        ax1.set_ylabel('Intensity')
        ax1.legend()
        ax1.grid(alpha=0.3)
        
        # Difference heatmap (simplified)
        stages = sorted([s for s in organized_data.keys() if s != reference_stage])
        if stages:
            difference_matrix = self.create_difference_matrix(organized_data, reference_stage, stages)
            im = ax2.imshow(difference_matrix, cmap='Reds', aspect='auto')
            ax2.set_title('Difference Intensity Heatmap', fontsize=14, weight='bold')
            ax2.set_xlabel('Wavelength (sampled)')
            ax2.set_ylabel('Stage')
            ax2.set_yticks(range(len(stages)))
            ax2.set_yticklabels([f'Stage {s}' for s in stages])
            plt.colorbar(im, ax=ax2, label='Absolute Difference')
        
        # Contamination progression
        contamination_indices = []
        for stage in stages:
            stage_spectrum = self.get_average_spectrum(organized_data[stage])
            index = self.calculate_contamination_index(ref_spectrum, stage_spectrum)
            contamination_indices.append(index)
        
        ax3.plot(stages, contamination_indices, 'ro-', linewidth=2, markersize=8)
        ax3.set_title('Contamination Progression', fontsize=14, weight='bold')
        ax3.set_xlabel('Stage')
        ax3.set_ylabel('Contamination Index')
        ax3.grid(alpha=0.3)
        
        # Peak shift analysis
        peak_shifts = []
        for stage in stages:
            stage_spectrum = self.get_average_spectrum(organized_data[stage])
            shift = self.calculate_peak_shift(ref_spectrum, stage_spectrum)
            peak_shifts.append(shift)
        
        ax4.bar(range(len(stages)), peak_shifts, color='orange', alpha=0.7)
        ax4.set_title('Average Peak Shift', fontsize=14, weight='bold')
        ax4.set_xlabel('Stage')
        ax4.set_ylabel('Peak Shift')
        ax4.set_xticks(range(len(stages)))
        ax4.set_xticklabels([f'Stage {s}' for s in stages])
        ax4.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_wavelength_sensitivity_analysis(self, pdf, sensitivity_data):
        """Create wavelength sensitivity analysis page"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        wavelengths, sensitivities = zip(*sensitivity_data[:100])  # Top 100 for visibility
        
        # Full sensitivity plot
        ax1.plot(wavelengths, sensitivities, 'b-', linewidth=1)
        ax1.set_title('Wavelength Sensitivity Profile', fontsize=14, weight='bold')
        ax1.set_xlabel('Wavelength')
        ax1.set_ylabel('Sensitivity Score')
        ax1.grid(alpha=0.3)
        
        # Top 20 most sensitive wavelengths
        top_20_wav = list(wavelengths)[:20]
        top_20_sens = list(sensitivities)[:20]
        
        ax2.bar(range(len(top_20_wav)), top_20_sens, color='red', alpha=0.7)
        ax2.set_title('Top 20 Most Sensitive Wavelengths', fontsize=14, weight='bold')
        ax2.set_xlabel('Rank')
        ax2.set_ylabel('Sensitivity Score')
        ax2.grid(axis='y', alpha=0.3)
        
        # Sensitivity distribution
        ax3.hist(sensitivities, bins=30, color='skyblue', alpha=0.7, edgecolor='black')
        ax3.set_title('Sensitivity Score Distribution', fontsize=14, weight='bold')
        ax3.set_xlabel('Sensitivity Score')
        ax3.set_ylabel('Frequency')
        ax3.grid(axis='y', alpha=0.3)
        
        # Top wavelengths table
        ax4.axis('tight')
        ax4.axis('off')
        top_10_data = [(f'{w:.1f}', f'{s:.4f}') for w, s in sensitivity_data[:10]]
        table = ax4.table(cellText=top_10_data, 
                         colLabels=['Wavelength', 'Sensitivity'],
                         cellLoc='center', loc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1.2, 1.5)
        ax4.set_title('Top 10 Sensitive Wavelengths', fontsize=14, weight='bold', pad=20)
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_detailed_comparisons(self, pdf, comparison_results):
        """Create detailed comparison page for each stage pair"""
        for comp_name, comp_data in comparison_results.items():
            if 'file_comparisons' in comp_data and comp_data['file_comparisons']:
                self.create_single_comparison_page(pdf, comp_name, comp_data)
    
    def create_single_comparison_page(self, pdf, comp_name, comp_data):
        """Create detailed page for a single comparison"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(12, 10))
        
        # Title
        fig.suptitle(f'Detailed Analysis: {comp_name}', fontsize=16, weight='bold')
        
        file_comparisons = comp_data['file_comparisons']
        
        if not file_comparisons:
            return
        
        # Sample spectra comparison
        sample_comp = file_comparisons[0]
        wavelength = sample_comp['wavelength_grid']
        intensity1 = sample_comp['intensity1']
        intensity2 = sample_comp['intensity2']
        
        ax1.plot(wavelength, intensity1, 'b-', label=sample_comp['label1'], linewidth=2)
        ax1.plot(wavelength, intensity2, 'r-', label=sample_comp['label2'], linewidth=2)
        ax1.set_title('Sample Spectra Comparison', fontsize=12, weight='bold')
        ax1.set_xlabel('Wavelength')
        ax1.set_ylabel('Intensity')
        ax1.legend()
        ax1.grid(alpha=0.3)
        
        # Difference plot
        difference = sample_comp['absolute_difference']
        ax2.plot(wavelength, difference, 'g-', linewidth=2)
        ax2.fill_between(wavelength, difference, alpha=0.3, color='green')
        ax2.set_title('Absolute Difference', fontsize=12, weight='bold')
        ax2.set_xlabel('Wavelength')
        ax2.set_ylabel('Difference')
        ax2.grid(alpha=0.3)
        
        # Metrics comparison
        metrics = sample_comp['metrics']
        metric_names = list(metrics.keys())[:6]  # Top 6 metrics
        metric_values = [metrics[name] for name in metric_names]
        
        ax3.bar(range(len(metric_names)), metric_values, color='purple', alpha=0.7)
        ax3.set_title('Comparison Metrics', fontsize=12, weight='bold')
        ax3.set_xlabel('Metric')
        ax3.set_ylabel('Value')
        ax3.set_xticks(range(len(metric_names)))
        ax3.set_xticklabels(metric_names, rotation=45, ha='right')
        ax3.grid(axis='y', alpha=0.3)
        
        # Statistical summary
        agg_metrics = comp_data.get('aggregate_metrics', {})
        stats_tests = comp_data.get('statistical_tests', {})
        
        summary_text = f"""
        Aggregate Metrics:
        RMSE: {agg_metrics.get('rmse', {}).get('mean', 0):.4f}
        Correlation: {agg_metrics.get('correlation', {}).get('mean', 0):.4f}
        Max Difference: {agg_metrics.get('max_absolute_diff', {}).get('mean', 0):.4f}
        
        Statistical Tests:
        t-test p-value: {stats_tests.get('t_test', {}).get('p_value', 1):.4f}
        Effect Size: {abs(stats_tests.get('effect_size', {}).get('cohens_d', 0)):.4f}
        """
        
        ax4.text(0.1, 0.9, summary_text, fontsize=10, va='top', transform=ax4.transAxes,
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.3))
        ax4.set_title('Statistical Summary', fontsize=12, weight='bold')
        ax4.axis('off')
        
        plt.tight_layout()
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    def create_conclusions_page(self, pdf, comparison_results, reference_stage):
        """Create conclusions and recommendations page"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        ax.text(0.5, 0.95, 'Conclusions and Recommendations', 
                fontsize=20, weight='bold', ha='center', transform=ax.transAxes)
        
        # Generate conclusions based on analysis
        conclusions = self.generate_conclusions(comparison_results, reference_stage)
        
        ax.text(0.1, 0.8, conclusions, fontsize=11, va='top', transform=ax.transAxes,
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgreen", alpha=0.3))
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close(fig)
    
    # Helper methods
    def get_average_spectrum(self, stage_data):
        """Calculate average spectrum for a stage"""
        wavelengths = []
        intensities = []
        
        for file_data in stage_data.values():
            wavelengths.append(file_data['wavelength'])
            intensities.append(file_data['intensity'])
        
        # Find common range and interpolate
        min_wav = max(np.min(w) for w in wavelengths)
        max_wav = min(np.max(w) for w in wavelengths)
        common_wavelength = np.linspace(min_wav, max_wav, 1000)
        
        interpolated_intensities = []
        for wav, intens in zip(wavelengths, intensities):
            from scipy.interpolate import interp1d
            f = interp1d(wav, intens, kind='linear', bounds_error=False, fill_value=0)
            interpolated_intensities.append(f(common_wavelength))
        
        avg_intensity = np.mean(interpolated_intensities, axis=0)
        
        return {'wavelength': common_wavelength, 'intensity': avg_intensity}
    
    def find_most_significant_comparison(self, comparison_results):
        """Find the comparison with the most significant difference"""
        max_effect_size = 0
        most_significant = {'comparison': 'None', 'rmse': 0, 'correlation': 1, 'effect_size': 0}
        
        for comp_name, comp_data in comparison_results.items():
            stats_tests = comp_data.get('statistical_tests', {})
            effect_size = abs(stats_tests.get('effect_size', {}).get('cohens_d', 0))
            
            if not np.isnan(effect_size) and effect_size > max_effect_size:
                max_effect_size = effect_size
                agg = comp_data.get('aggregate_metrics', {})
                most_significant = {
                    'comparison': comp_name,
                    'rmse': agg.get('rmse', {}).get('mean', 0),
                    'correlation': agg.get('correlation', {}).get('mean', 1),
                    'effect_size': effect_size
                }
        
        return most_significant
    
    def count_significant_comparisons(self, comparison_results):
        """Count statistically significant comparisons"""
        count = 0
        for comp_data in comparison_results.values():
            stats_tests = comp_data.get('statistical_tests', {})
            p_value = stats_tests.get('t_test', {}).get('p_value', 1)
            if not np.isnan(p_value) and p_value < 0.05:
                count += 1
        return count
    
    def calculate_average_effect_size(self, comparison_results):
        """Calculate average effect size across all comparisons"""
        effect_sizes = []
        for comp_data in comparison_results.values():
            stats_tests = comp_data.get('statistical_tests', {})
            effect_size = abs(stats_tests.get('effect_size', {}).get('cohens_d', 0))
            if not np.isnan(effect_size):
                effect_sizes.append(effect_size)
        
        return np.mean(effect_sizes) if effect_sizes else 0
    
    def calculate_data_quality_metrics(self, organized_data):
        """Calculate basic data quality metrics"""
        total_files = sum(len(stage_data) for stage_data in organized_data.values())
        total_stages = len(organized_data)
        
        # Calculate average spectrum length
        spectrum_lengths = []
        for stage_data in organized_data.values():
            for file_data in stage_data.values():
                spectrum_lengths.append(len(file_data['intensity']))
        
        return {
            'Total Stages': total_stages,
            'Total Files': total_files,
            'Avg Spectrum Length': f"{np.mean(spectrum_lengths):.0f}",
            'Files per Stage': f"{total_files/total_stages:.1f}"
        }
    
    def create_difference_matrix(self, organized_data, reference_stage, stages):
        """Create a simplified difference matrix for heatmap"""
        ref_spectrum = self.get_average_spectrum(organized_data[reference_stage])
        
        difference_matrix = []
        for stage in stages:
            stage_spectrum = self.get_average_spectrum(organized_data[stage])
            
            # Sample points for visualization
            sample_indices = np.linspace(0, len(ref_spectrum['intensity'])-1, 50, dtype=int)
            ref_sample = ref_spectrum['intensity'][sample_indices]
            stage_sample = stage_spectrum['intensity'][sample_indices]
            
            difference = np.abs(stage_sample - ref_sample)
            difference_matrix.append(difference)
        
        return np.array(difference_matrix)
    
    def calculate_contamination_index(self, ref_spectrum, contaminated_spectrum):
        """Calculate contamination index between two spectra"""
        ref_norm = (ref_spectrum['intensity'] - np.min(ref_spectrum['intensity'])) / (np.max(ref_spectrum['intensity']) - np.min(ref_spectrum['intensity']))
        cont_norm = (contaminated_spectrum['intensity'] - np.min(contaminated_spectrum['intensity'])) / (np.max(contaminated_spectrum['intensity']) - np.min(contaminated_spectrum['intensity']))
        
        rms_diff = np.sqrt(np.mean((cont_norm - ref_norm)**2))
        correlation = np.corrcoef(ref_norm, cont_norm)[0,1]
        
        return rms_diff * (1 - correlation)
    
    def calculate_peak_shift(self, ref_spectrum, stage_spectrum):
        """Calculate average peak shift between spectra"""
        from scipy.signal import find_peaks
        
        ref_peaks, _ = find_peaks(ref_spectrum['intensity'], prominence=0.1)
        stage_peaks, _ = find_peaks(stage_spectrum['intensity'], prominence=0.1)
        
        if len(ref_peaks) == 0 or len(stage_peaks) == 0:
            return 0
        
        ref_wavelengths = ref_spectrum['wavelength'][ref_peaks]
        stage_wavelengths = stage_spectrum['wavelength'][stage_peaks]
        
        shifts = []
        for ref_wav in ref_wavelengths:
            closest_idx = np.argmin(np.abs(stage_wavelengths - ref_wav))
            shift = abs(stage_wavelengths[closest_idx] - ref_wav)
            shifts.append(shift)
        
        return np.mean(shifts) if shifts else 0
    
    def generate_conclusions(self, comparison_results, reference_stage):
        """Generate conclusions text based on analysis results"""
        significant_count = self.count_significant_comparisons(comparison_results)
        total_comparisons = len(comparison_results)
        avg_effect_size = self.calculate_average_effect_size(comparison_results)
        
        conclusions = f"""
        ANALYSIS CONCLUSIONS:
        
        1. STATISTICAL SIGNIFICANCE:
        • {significant_count} out of {total_comparisons} comparisons show statistically significant differences (p < 0.05)
        • Average effect size across all comparisons: {avg_effect_size:.3f}
        
        2. CONTAMINATION DETECTION:
        • Clear spectral changes detected between reference stage {reference_stage} and contaminated stages
        • Quantitative metrics successfully differentiate contamination levels
        
        3. RECOMMENDATIONS:
        • Use identified sensitive wavelengths for contamination monitoring
        • Implement statistical thresholds based on effect sizes for quality control
        • Consider stage-specific contamination signatures for early detection
        
        4. QUALITY ASSURANCE:
        • Statistical validation confirms reliability of detected differences
        • Multiple metrics provide robust contamination assessment
        • Wavelength-specific analysis enables targeted monitoring strategies
        
        This comprehensive analysis provides a solid foundation for contamination detection
        and quality control protocols in spectral analysis applications.
        """
        
        return conclusions