import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.decomposition import PCA
from scipy import interpolate
import warnings
warnings.filterwarnings('ignore')

class AIStagePredictor:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_importance = {}
        self.performance_metrics = {}
        self.is_trained = False
        self.wavelength_grid = None
        self.feature_names = None
        
    def prepare_training_data(self, organized_data, target_wavelength_range=None, n_features=100):
        """
        Prepare training data from organized spectral data
        """
        X_data = []
        y_data = []
        stage_labels = []
        
        # Determine common wavelength grid
        all_wavelengths = []
        for stage_data in organized_data.values():
            for file_data in stage_data.values():
                all_wavelengths.extend(file_data['wavelength'])
        
        if target_wavelength_range:
            min_wav, max_wav = target_wavelength_range
        else:
            min_wav = max(np.min(w) for stage_data in organized_data.values() 
                         for w in [file_data['wavelength'] for file_data in stage_data.values()])
            max_wav = min(np.max(w) for stage_data in organized_data.values() 
                         for w in [file_data['wavelength'] for file_data in stage_data.values()])
        
        self.wavelength_grid = np.linspace(min_wav, max_wav, n_features)
        self.feature_names = [f'Wavelength_{w:.1f}' for w in self.wavelength_grid]
        
        # Interpolate all spectra to common grid
        for stage, stage_data in organized_data.items():
            for file_num, file_data in stage_data.items():
                wavelength = file_data['wavelength']
                intensity = file_data['intensity']
                
                # Interpolate to common grid
                f = interpolate.interp1d(wavelength, intensity, kind='linear', 
                                       bounds_error=False, fill_value=0)
                interpolated_intensity = f(self.wavelength_grid)
                
                X_data.append(interpolated_intensity)
                y_data.append(stage)
                stage_labels.append(f'Stage_{stage}_File_{file_num}')
        
        X = np.array(X_data)
        y = np.array(y_data)
        
        return X, y, stage_labels
    
    def train_models(self, X, y, test_size=0.3, random_state=42):
        """
        Train multiple ML models for stage prediction
        """
        print("Training AI models for stage prediction...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        self.scalers['main'] = scaler
        
        # Define models with optimized parameters
        models_config = {
            'Random Forest': RandomForestClassifier(
                n_estimators=100, max_depth=15, min_samples_split=5,
                random_state=random_state, n_jobs=-1
            ),
            'Gradient Boosting': GradientBoostingClassifier(
                n_estimators=100, max_depth=6, learning_rate=0.1,
                random_state=random_state
            ),
            'Neural Network': MLPClassifier(
                hidden_layer_sizes=(100, 50), max_iter=500, alpha=0.01,
                random_state=random_state, early_stopping=True
            ),
            'SVM': SVC(
                kernel='rbf', C=1.0, gamma='scale', probability=True,
                random_state=random_state
            )
        }
        
        # Train and evaluate models
        for name, model in models_config.items():
            print(f"Training {name}...")
            
            # Train model
            if name in ['Neural Network', 'SVM']:
                model.fit(X_train_scaled, y_train)
                y_pred = model.predict(X_test_scaled)
                y_prob = model.predict_proba(X_test_scaled)
            else:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                y_prob = model.predict_proba(X_test)
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            cv_scores = cross_val_score(model, X_train_scaled if name in ['Neural Network', 'SVM'] else X_train, 
                                      y_train, cv=5, scoring='accuracy')
            
            # Store model and metrics
            self.models[name] = model
            self.performance_metrics[name] = {
                'accuracy': accuracy,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'classification_report': classification_report(y_test, y_pred, output_dict=True),
                'confusion_matrix': confusion_matrix(y_test, y_pred),
                'test_predictions': y_pred,
                'test_probabilities': y_prob,
                'test_labels': y_test
            }
            
            # Feature importance (for tree-based models)
            if hasattr(model, 'feature_importances_'):
                self.feature_importance[name] = model.feature_importances_
        
        self.is_trained = True
        print("Model training completed!")
        
        return self.performance_metrics
    
    def predict_stage(self, spectrum_data, model_name='Random Forest', return_probabilities=False):
        """
        Predict contamination stage for new spectrum data
        """
        if not self.is_trained:
            raise ValueError("Models must be trained before making predictions")
        
        if model_name not in self.models:
            raise ValueError(f"Model {model_name} not available")
        
        # Prepare input data
        if isinstance(spectrum_data, dict):
            wavelength = spectrum_data['wavelength']
            intensity = spectrum_data['intensity']
        else:
            # Assume it's already interpolated to the correct grid
            intensity = spectrum_data
        
        # Interpolate to model's wavelength grid if needed
        if isinstance(spectrum_data, dict):
            f = interpolate.interp1d(wavelength, intensity, kind='linear', 
                                   bounds_error=False, fill_value=0)
            intensity_interp = f(self.wavelength_grid)
        else:
            intensity_interp = intensity
        
        # Reshape for prediction
        X_pred = intensity_interp.reshape(1, -1)
        
        # Scale if needed
        model = self.models[model_name]
        if model_name in ['Neural Network', 'SVM']:
            X_pred = self.scalers['main'].transform(X_pred)
        
        # Make prediction
        prediction = model.predict(X_pred)[0]
        
        if return_probabilities:
            probabilities = model.predict_proba(X_pred)[0]
            stage_classes = model.classes_
            prob_dict = dict(zip(stage_classes, probabilities))
            return prediction, prob_dict
        
        return prediction
    
    def simulate_contamination_progression(self, clean_spectrum, target_stage, n_steps=10):
        """
        Simulate contamination progression from clean to target stage
        """
        if not self.is_trained:
            raise ValueError("Models must be trained before simulation")
        
        # Get a representative spectrum for the target stage
        # This would need to be provided or learned from training data
        simulated_spectra = []
        predicted_stages = []
        contamination_levels = np.linspace(0, 1, n_steps)
        
        for level in contamination_levels:
            # Simple linear interpolation simulation
            # In practice, this could be more sophisticated
            simulated_spectrum = clean_spectrum.copy()
            
            # Add some realistic contamination effects
            noise_factor = level * 0.1
            intensity_shift = level * 0.2
            
            simulated_spectrum['intensity'] = (
                simulated_spectrum['intensity'] * (1 - intensity_shift) + 
                np.random.normal(0, noise_factor, len(simulated_spectrum['intensity']))
            )
            
            predicted_stage, probabilities = self.predict_stage(
                simulated_spectrum, return_probabilities=True
            )
            
            simulated_spectra.append(simulated_spectrum)
            predicted_stages.append({
                'contamination_level': level,
                'predicted_stage': predicted_stage,
                'probabilities': probabilities
            })
        
        return simulated_spectra, predicted_stages
    
    def create_prediction_visualization(self, spectrum_data, model_name='Random Forest'):
        """
        Create interactive visualization for stage prediction
        """
        prediction, probabilities = self.predict_stage(
            spectrum_data, model_name, return_probabilities=True
        )
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=[
                'Input Spectrum',
                'Stage Prediction Probabilities',
                'Feature Importance (Top 20)',
                'Model Confidence Analysis'
            ],
            specs=[[{"type": "scatter"}, {"type": "bar"}],
                   [{"type": "bar"}, {"type": "scatter"}]]
        )
        
        # Input spectrum
        if isinstance(spectrum_data, dict):
            wavelength = spectrum_data['wavelength']
            intensity = spectrum_data['intensity']
        else:
            wavelength = self.wavelength_grid
            intensity = spectrum_data
        
        fig.add_trace(go.Scatter(
            x=wavelength,
            y=intensity,
            mode='lines',
            name='Input Spectrum',
            line=dict(color='blue', width=2)
        ), row=1, col=1)
        
        # Prediction probabilities
        stages = list(probabilities.keys())
        probs = list(probabilities.values())
        colors = ['red' if stage == prediction else 'lightblue' for stage in stages]
        
        fig.add_trace(go.Bar(
            x=[f'Stage {s}' for s in stages],
            y=probs,
            name='Probability',
            marker_color=colors
        ), row=1, col=2)
        
        # Feature importance (if available)
        if model_name in self.feature_importance:
            importance = self.feature_importance[model_name]
            top_indices = np.argsort(importance)[-20:]
            top_wavelengths = self.wavelength_grid[top_indices]
            top_importance = importance[top_indices]
            
            fig.add_trace(go.Bar(
                x=top_wavelengths,
                y=top_importance,
                name='Importance',
                marker_color='green'
            ), row=2, col=1)
        
        # Model confidence
        max_prob = max(probs)
        confidence_score = max_prob
        uncertainty = 1 - confidence_score
        
        fig.add_trace(go.Scatter(
            x=['Confidence', 'Uncertainty'],
            y=[confidence_score, uncertainty],
            mode='markers+text',
            text=[f'{confidence_score:.3f}', f'{uncertainty:.3f}'],
            textposition="middle center",
            marker=dict(size=[confidence_score*100, uncertainty*100],
                       color=['green', 'orange'])
        ), row=2, col=2)
        
        fig.update_layout(
            title=f'AI Stage Prediction: Stage {prediction} (Confidence: {max_prob:.3f})',
            height=800,
            showlegend=False
        )
        
        return fig, prediction, probabilities
    
    def create_model_comparison_plot(self):
        """
        Create visualization comparing all trained models
        """
        if not self.is_trained:
            return None
        
        models = list(self.performance_metrics.keys())
        accuracies = [self.performance_metrics[model]['accuracy'] for model in models]
        cv_means = [self.performance_metrics[model]['cv_mean'] for model in models]
        cv_stds = [self.performance_metrics[model]['cv_std'] for model in models]
        
        fig = go.Figure()
        
        # Test accuracy
        fig.add_trace(go.Bar(
            name='Test Accuracy',
            x=models,
            y=accuracies,
            marker_color='lightblue'
        ))
        
        # Cross-validation accuracy with error bars
        fig.add_trace(go.Bar(
            name='CV Accuracy',
            x=models,
            y=cv_means,
            error_y=dict(type='data', array=cv_stds),
            marker_color='orange'
        ))
        
        fig.update_layout(
            title='Model Performance Comparison',
            xaxis_title='Model',
            yaxis_title='Accuracy',
            barmode='group'
        )
        
        return fig
    
    def create_confusion_matrix_plot(self, model_name='Random Forest'):
        """
        Create confusion matrix visualization
        """
        if model_name not in self.performance_metrics:
            return None
        
        cm = self.performance_metrics[model_name]['confusion_matrix']
        
        # Get unique stages
        stages = sorted(list(set(self.performance_metrics[model_name]['test_labels'])))
        
        fig = go.Figure(data=go.Heatmap(
            z=cm,
            x=[f'Predicted Stage {s}' for s in stages],
            y=[f'Actual Stage {s}' for s in stages],
            colorscale='Blues',
            text=cm,
            texttemplate="%{text}",
            textfont={"size": 12}
        ))
        
        fig.update_layout(
            title=f'Confusion Matrix - {model_name}',
            xaxis_title='Predicted',
            yaxis_title='Actual'
        )
        
        return fig
    
    def get_feature_importance_analysis(self, model_name='Random Forest', top_n=20):
        """
        Get detailed feature importance analysis
        """
        if model_name not in self.feature_importance:
            return None
        
        importance = self.feature_importance[model_name]
        
        # Get top features
        top_indices = np.argsort(importance)[-top_n:][::-1]
        top_wavelengths = self.wavelength_grid[top_indices]
        top_importance = importance[top_indices]
        
        analysis = {
            'wavelengths': top_wavelengths,
            'importance_scores': top_importance,
            'feature_names': [self.feature_names[i] for i in top_indices],
            'cumulative_importance': np.cumsum(top_importance)
        }
        
        return analysis
    
    def simulate_interactive_prediction(self, base_spectrum, modifications):
        """
        Simulate predictions with interactive modifications to spectrum
        """
        results = []
        
        for modification in modifications:
            modified_spectrum = base_spectrum.copy()
            
            # Apply modifications
            if 'intensity_scale' in modification:
                modified_spectrum['intensity'] *= modification['intensity_scale']
            
            if 'wavelength_shift' in modification:
                modified_spectrum['wavelength'] += modification['wavelength_shift']
            
            if 'noise_level' in modification:
                noise = np.random.normal(0, modification['noise_level'], 
                                       len(modified_spectrum['intensity']))
                modified_spectrum['intensity'] += noise
            
            # Predict
            prediction, probabilities = self.predict_stage(
                modified_spectrum, return_probabilities=True
            )
            
            results.append({
                'modification': modification,
                'prediction': prediction,
                'probabilities': probabilities,
                'spectrum': modified_spectrum
            })
        
        return results
    
    def get_model_summary(self):
        """
        Get summary of all trained models
        """
        if not self.is_trained:
            return "No models have been trained yet."
        
        summary = {
            'models_trained': list(self.models.keys()),
            'best_model': max(self.performance_metrics.keys(), 
                            key=lambda k: self.performance_metrics[k]['accuracy']),
            'feature_count': len(self.wavelength_grid),
            'wavelength_range': (self.wavelength_grid[0], self.wavelength_grid[-1]),
            'performance_summary': {
                name: {
                    'accuracy': metrics['accuracy'],
                    'cv_score': f"{metrics['cv_mean']:.3f} ± {metrics['cv_std']:.3f}"
                }
                for name, metrics in self.performance_metrics.items()
            }
        }
        
        return summary