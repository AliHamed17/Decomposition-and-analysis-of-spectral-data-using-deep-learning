import numpy as np
import pandas as pd
import streamlit as st
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing
from functools import partial
import time
import gc
from typing import Dict, List, Tuple, Any, Optional
import warnings
warnings.filterwarnings('ignore')

class BatchProcessor:
    def __init__(self, max_workers=None):
        self.max_workers = max_workers or min(4, multiprocessing.cpu_count())
        self.batch_size = 10
        self.memory_threshold = 0.8  # 80% memory usage threshold
        
    def set_batch_size(self, size: int):
        """Set the batch size for processing"""
        self.batch_size = max(1, size)
    
    def set_max_workers(self, workers: int):
        """Set the maximum number of worker threads"""
        self.max_workers = max(1, min(workers, multiprocessing.cpu_count()))
    
    def process_single_spectrum(self, spectrum_data: Dict, spectrum_id: str, 
                              analysis_function, **kwargs) -> Dict:
        """Process a single spectrum with the given analysis function"""
        try:
            wavelength = spectrum_data['wavelength']
            intensity = spectrum_data['intensity']
            
            # Apply analysis function
            result = analysis_function(wavelength, intensity, spectrum_id, **kwargs)
            
            return {
                'spectrum_id': spectrum_id,
                'success': True,
                'result': result,
                'error': None
            }
        except Exception as e:
            return {
                'spectrum_id': spectrum_id,
                'success': False,
                'result': None,
                'error': str(e)
            }
    
    def batch_process_stage(self, organized_data: Dict, stage: int, 
                           analysis_function, progress_callback=None, **kwargs) -> Dict:
        """Process all files in a stage using batch processing"""
        if stage not in organized_data:
            return {}
        
        stage_data = organized_data[stage]
        file_items = list(stage_data.items())
        total_files = len(file_items)
        
        results = {}
        successful_count = 0
        failed_count = 0
        
        # Process in batches
        for batch_start in range(0, total_files, self.batch_size):
            batch_end = min(batch_start + self.batch_size, total_files)
            batch_items = file_items[batch_start:batch_end]
            
            # Process batch in parallel
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {}
                
                for file_num, file_data in batch_items:
                    spectrum_id = f"Stage_{stage}_File_{file_num}"
                    future = executor.submit(
                        self.process_single_spectrum,
                        file_data, spectrum_id, analysis_function, **kwargs
                    )
                    futures[future] = file_num
                
                # Collect results
                for future in as_completed(futures):
                    file_num = futures[future]
                    result = future.result()
                    
                    if result['success']:
                        results[file_num] = result['result']
                        successful_count += 1
                    else:
                        failed_count += 1
                        if progress_callback:
                            progress_callback(f"Error processing {result['spectrum_id']}: {result['error']}")
            
            # Update progress
            if progress_callback:
                progress = (batch_end / total_files) * 100
                progress_callback(f"Stage {stage}: Processed {batch_end}/{total_files} files ({progress:.1f}%)")
            
            # Memory cleanup
            gc.collect()
        
        return {
            'results': results,
            'stats': {
                'total_files': total_files,
                'successful': successful_count,
                'failed': failed_count,
                'success_rate': successful_count / total_files if total_files > 0 else 0
            }
        }
    
    def batch_process_all_stages(self, organized_data: Dict, analysis_function, 
                                progress_callback=None, **kwargs) -> Dict:
        """Process all stages using batch processing"""
        all_results = {}
        total_stages = len(organized_data)
        overall_stats = {
            'total_stages': total_stages,
            'total_files': 0,
            'successful': 0,
            'failed': 0,
            'processing_time': 0
        }
        
        start_time = time.time()
        
        for stage_idx, stage in enumerate(sorted(organized_data.keys())):
            if progress_callback:
                progress_callback(f"Processing Stage {stage} ({stage_idx + 1}/{total_stages})...")
            
            stage_results = self.batch_process_stage(
                organized_data, stage, analysis_function, progress_callback, **kwargs
            )
            
            all_results[stage] = stage_results
            
            # Update overall stats
            stage_stats = stage_results.get('stats', {})
            overall_stats['total_files'] += stage_stats.get('total_files', 0)
            overall_stats['successful'] += stage_stats.get('successful', 0)
            overall_stats['failed'] += stage_stats.get('failed', 0)
            
            # Memory cleanup between stages
            gc.collect()
        
        overall_stats['processing_time'] = time.time() - start_time
        overall_stats['success_rate'] = (
            overall_stats['successful'] / overall_stats['total_files'] 
            if overall_stats['total_files'] > 0 else 0
        )
        
        return {
            'stage_results': all_results,
            'overall_stats': overall_stats
        }
    
    def batch_peak_analysis(self, organized_data: Dict, peak_analyzer, 
                           prominence=0.1, width=2, progress_callback=None) -> Dict:
        """Batch process peak analysis across all stages"""
        def peak_analysis_function(wavelength, intensity, spectrum_id, **kwargs):
            return peak_analyzer.analyze_spectrum_peaks(
                wavelength, intensity, spectrum_id, 
                prominence=kwargs.get('prominence', 0.1),
                width=kwargs.get('width', 2)
            )
        
        return self.batch_process_all_stages(
            organized_data, peak_analysis_function, progress_callback,
            prominence=prominence, width=width
        )
    
    def batch_statistical_analysis(self, organized_data: Dict, stats_analyzer,
                                  progress_callback=None) -> Dict:
        """Batch process statistical analysis across all stages"""
        def stats_analysis_function(wavelength, intensity, spectrum_id, **kwargs):
            # Calculate basic statistics for the spectrum
            return {
                'min_intensity': np.min(intensity),
                'max_intensity': np.max(intensity),
                'mean_intensity': np.mean(intensity),
                'std_intensity': np.std(intensity),
                'median_intensity': np.median(intensity),
                'wavelength_range': (np.min(wavelength), np.max(wavelength)),
                'data_points': len(intensity)
            }
        
        return self.batch_process_all_stages(
            organized_data, stats_analysis_function, progress_callback
        )
    
    def batch_anomaly_detection(self, organized_data: Dict, anomaly_detector,
                               contamination=0.1, progress_callback=None) -> Dict:
        """Batch process anomaly detection across all stages"""
        def anomaly_analysis_function(wavelength, intensity, spectrum_id, **kwargs):
            # Prepare data for anomaly detection
            spectrum_features = np.column_stack([wavelength, intensity])
            
            # Simple outlier detection based on intensity distribution
            q75, q25 = np.percentile(intensity, [75, 25])
            iqr = q75 - q25
            lower_bound = q25 - 1.5 * iqr
            upper_bound = q75 + 1.5 * iqr
            
            outliers = np.where((intensity < lower_bound) | (intensity > upper_bound))[0]
            anomaly_score = len(outliers) / len(intensity)
            
            return {
                'anomaly_score': anomaly_score,
                'outlier_count': len(outliers),
                'outlier_percentage': (len(outliers) / len(intensity)) * 100,
                'intensity_range': (np.min(intensity), np.max(intensity)),
                'is_anomaly': anomaly_score > kwargs.get('contamination', 0.1)
            }
        
        return self.batch_process_all_stages(
            organized_data, anomaly_analysis_function, progress_callback,
            contamination=contamination
        )
    
    def batch_preprocessing(self, organized_data: Dict, preprocessing_params: Dict,
                           progress_callback=None) -> Dict:
        """Batch process data preprocessing (normalization, smoothing, etc.)"""
        def preprocessing_function(wavelength, intensity, spectrum_id, **kwargs):
            processed_intensity = intensity.copy()
            
            # Apply normalization if requested
            if kwargs.get('normalize', False):
                norm_method = kwargs.get('norm_method', 'min_max')
                if norm_method == 'min_max':
                    min_val, max_val = np.min(processed_intensity), np.max(processed_intensity)
                    if max_val > min_val:
                        processed_intensity = (processed_intensity - min_val) / (max_val - min_val)
                elif norm_method == 'z_score':
                    mean_val, std_val = np.mean(processed_intensity), np.std(processed_intensity)
                    if std_val > 0:
                        processed_intensity = (processed_intensity - mean_val) / std_val
            
            # Apply smoothing if requested
            if kwargs.get('smooth', False):
                from scipy.signal import savgol_filter
                window_length = kwargs.get('window_length', 11)
                polyorder = kwargs.get('polyorder', 3)
                if len(processed_intensity) >= window_length:
                    processed_intensity = savgol_filter(
                        processed_intensity, window_length, polyorder
                    )
            
            return {
                'wavelength': wavelength,
                'intensity': processed_intensity,
                'original_intensity': intensity
            }
        
        return self.batch_process_all_stages(
            organized_data, preprocessing_function, progress_callback,
            **preprocessing_params
        )
    
    def get_memory_usage(self) -> float:
        """Get current memory usage percentage"""
        try:
            import psutil
            return psutil.virtual_memory().percent / 100.0
        except ImportError:
            return 0.0
    
    def estimate_processing_time(self, organized_data: Dict, 
                               samples_per_second: float = 10.0) -> Dict:
        """Estimate processing time for the dataset"""
        total_files = sum(len(stage_data) for stage_data in organized_data.values())
        
        # Estimate based on samples per second
        estimated_seconds = total_files / samples_per_second
        
        # Adjust for parallel processing
        parallel_factor = min(self.max_workers, total_files)
        if parallel_factor > 1:
            estimated_seconds = estimated_seconds / parallel_factor * 0.8  # 80% efficiency
        
        return {
            'total_files': total_files,
            'estimated_seconds': estimated_seconds,
            'estimated_minutes': estimated_seconds / 60,
            'parallel_workers': parallel_factor,
            'batch_size': self.batch_size
        }
    
    def create_processing_summary(self, results: Dict) -> pd.DataFrame:
        """Create a summary DataFrame from processing results"""
        summary_data = []
        
        if 'stage_results' in results:
            stage_results = results['stage_results']
            for stage, stage_data in stage_results.items():
                stats = stage_data.get('stats', {})
                summary_data.append({
                    'Stage': stage,
                    'Total Files': stats.get('total_files', 0),
                    'Successful': stats.get('successful', 0),
                    'Failed': stats.get('failed', 0),
                    'Success Rate': f"{stats.get('success_rate', 0):.2%}"
                })
        
        return pd.DataFrame(summary_data)
    
    def save_batch_results(self, results: Dict, output_path: str, 
                          format_type: str = 'csv') -> bool:
        """Save batch processing results to file"""
        try:
            if format_type.lower() == 'csv':
                summary_df = self.create_processing_summary(results)
                summary_df.to_csv(output_path, index=False)
            elif format_type.lower() == 'excel':
                with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                    # Summary sheet
                    summary_df = self.create_processing_summary(results)
                    summary_df.to_excel(writer, sheet_name='Processing_Summary', index=False)
                    
                    # Detailed results per stage (if available)
                    if 'stage_results' in results:
                        for stage, stage_data in results['stage_results'].items():
                            if 'results' in stage_data:
                                stage_df = pd.DataFrame(stage_data['results']).T
                                sheet_name = f'Stage_{stage}_Results'[:31]  # Excel sheet name limit
                                stage_df.to_excel(writer, sheet_name=sheet_name)
            
            return True
        except Exception as e:
            print(f"Error saving results: {e}")
            return False