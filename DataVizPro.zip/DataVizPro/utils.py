import os
import base64
import io
import matplotlib.pyplot as plt
import numpy as np

def get_figure_download_link(fig, filename):
    """
    Generate a download link for a figure
    """
    # Save figure to a BytesIO buffer
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=300)
    buf.seek(0)
    
    # Encode buffer to base64
    b64 = base64.b64encode(buf.read()).decode()
    
    # Generate download link
    href = f'<a href="data:image/png;base64,{b64}" download="{filename}">Download {filename}</a>'
    
    return href

def save_figure(fig, path):
    """
    Save a figure to a path
    """
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(path), exist_ok=True)
    
    # Save figure
    fig.savefig(path, dpi=300)
    plt.close(fig)

def normalize_data(data):
    """
    Normalize data to [0, 1] range
    """
    min_val = np.min(data)
    max_val = np.max(data)
    
    if max_val == min_val:
        return np.zeros_like(data)
    
    return (data - min_val) / (max_val - min_val)

def normalize_spectrum_intensity(wavelength, intensity):
    """
    Normalize spectrum intensity to [0, 1] range
    Returns the normalized intensity array
    """
    return normalize_data(intensity)

def normalize_all_spectra(data):
    """
    Normalize all spectra in the data to [0, 1] range
    Returns a new copy of the data with normalized intensities
    """
    # Create a deep copy of the data
    normalized_data = {}
    
    # For each stage in the data
    for stage, stage_data in data.items():
        normalized_data[stage] = {}
        
        # For each file in this stage
        for file_num, file_data in stage_data.items():
            # Get wavelength and intensity
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            
            # Normalize intensity
            normalized_intensity = normalize_spectrum_intensity(wavelength, intensity)
            
            # Store normalized data
            normalized_data[stage][file_num] = {
                'wavelength': wavelength,
                'intensity': normalized_intensity
            }
    
    return normalized_data

def calculate_wavelength_range(organized_data):
    """
    Calculate the min and max wavelength across all data
    """
    min_wavelength = float('inf')
    max_wavelength = float('-inf')
    
    for stage, stage_data in organized_data.items():
        for file_num, file_data in stage_data.items():
            wavelength = file_data['wavelength']
            min_wavelength = min(min_wavelength, wavelength[0])
            max_wavelength = max(max_wavelength, wavelength[-1])
    
    return min_wavelength, max_wavelength

def downsample_array(array, target_size):
    """
    Downsample an array to a target size
    """
    if len(array) <= target_size:
        return array
    
    indices = np.linspace(0, len(array) - 1, target_size, dtype=int)
    return array[indices]
