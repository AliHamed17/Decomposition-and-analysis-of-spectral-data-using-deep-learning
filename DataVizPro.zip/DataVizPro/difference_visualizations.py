import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import signal, interpolate
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

def create_difference_detection_plots(data, reference_stage=0):
    """
    Create comprehensive difference detection visualizations
    """
    if reference_stage not in data:
        return None
    
    # Get all stages except reference
    comparison_stages = [stage for stage in data.keys() if stage != reference_stage]
    
    if not comparison_stages:
        return None
    
    # Create master figure with subplots
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=[
            f'Spectral Evolution from Stage {reference_stage}',
            'Difference Magnitude Heatmap',
            'Peak Shift Detection',
            'Contamination Progression Index',
            'Change Point Analysis',
            'Stage Discrimination Map'
        ],
        specs=[[{"type": "scatter"}, {"type": "heatmap"}],
               [{"type": "scatter"}, {"type": "scatter"}],
               [{"type": "scatter"}, {"type": "scatter"}]]
    )
    
    # Get reference data (average of all files in reference stage)
    ref_data = get_average_spectrum(data[reference_stage])
    ref_wavelength = ref_data['wavelength']
    ref_intensity = ref_data['intensity']
    
    colors = px.colors.qualitative.Set1
    
    # 1. Spectral Evolution Plot
    fig.add_trace(go.Scatter(
        x=ref_wavelength,
        y=ref_intensity,
        mode='lines',
        name=f'Stage {reference_stage} (Reference)',
        line=dict(color='black', width=3)
    ), row=1, col=1)
    
    difference_data = []
    peak_shifts = []
    contamination_indices = []
    
    for i, stage in enumerate(sorted(comparison_stages)):
        stage_data = get_average_spectrum(data[stage])
        stage_wavelength = stage_data['wavelength']
        stage_intensity = stage_data['intensity']
        
        # Interpolate to common grid
        common_wav, ref_interp, stage_interp = interpolate_to_common_grid(
            ref_wavelength, ref_intensity, stage_wavelength, stage_intensity
        )
        
        # Calculate difference
        difference = np.abs(stage_interp - ref_interp)
        difference_data.append(difference)
        
        color = colors[i % len(colors)]
        
        # Add to spectral evolution
        fig.add_trace(go.Scatter(
            x=common_wav,
            y=stage_interp,
            mode='lines',
            name=f'Stage {stage}',
            line=dict(color=color, width=2)
        ), row=1, col=1)
        
        # Calculate peak shifts
        ref_peaks = find_peaks_simple(ref_interp)
        stage_peaks = find_peaks_simple(stage_interp)
        peak_shift = calculate_peak_shift(common_wav, ref_peaks, stage_peaks)
        peak_shifts.append(peak_shift)
        
        # Calculate contamination index
        contamination_index = calculate_contamination_index(ref_interp, stage_interp)
        contamination_indices.append(contamination_index)
    
    # 2. Difference Magnitude Heatmap
    if difference_data:
        diff_matrix = np.array(difference_data)
        fig.add_trace(go.Heatmap(
            z=diff_matrix,
            x=common_wav[::10],  # Subsample for visibility
            y=[f'Stage {stage}' for stage in sorted(comparison_stages)],
            colorscale='Reds',
            name='Difference'
        ), row=1, col=2)
    
    # 3. Peak Shift Detection
    stages_list = sorted(comparison_stages)
    fig.add_trace(go.Scatter(
        x=stages_list,
        y=peak_shifts,
        mode='markers+lines',
        name='Peak Shift',
        marker=dict(size=10, color='red'),
        line=dict(color='red', width=2)
    ), row=2, col=1)
    
    # 4. Contamination Progression Index
    fig.add_trace(go.Scatter(
        x=stages_list,
        y=contamination_indices,
        mode='markers+lines',
        name='Contamination Index',
        marker=dict(size=10, color='blue'),
        line=dict(color='blue', width=2)
    ), row=2, col=2)
    
    # 5. Change Point Analysis
    change_points = detect_change_points(common_wav, difference_data)
    if change_points:
        fig.add_trace(go.Scatter(
            x=change_points,
            y=[1] * len(change_points),
            mode='markers',
            name='Change Points',
            marker=dict(size=15, color='orange', symbol='diamond')
        ), row=3, col=1)
    
    # 6. Stage Discrimination Map
    discrimination_scores = calculate_discrimination_scores(data, reference_stage)
    if discrimination_scores:
        wavelengths, scores = zip(*discrimination_scores)
        fig.add_trace(go.Scatter(
            x=list(wavelengths),
            y=list(scores),
            mode='lines+markers',
            name='Discrimination Power',
            line=dict(color='purple', width=2)
        ), row=3, col=2)
    
    fig.update_layout(
        title='Comprehensive Stage Difference Detection Analysis',
        height=1200,
        showlegend=True
    )
    
    return fig

def create_contamination_timeline(data, reference_stage=0):
    """
    Create a timeline showing contamination progression
    """
    stages = sorted([stage for stage in data.keys() if stage != reference_stage])
    
    if not stages:
        return None
    
    # Calculate various contamination indicators
    timeline_data = []
    
    ref_spectrum = get_average_spectrum(data[reference_stage])
    
    for stage in stages:
        stage_spectrum = get_average_spectrum(data[stage])
        
        # Interpolate to common grid
        common_wav, ref_interp, stage_interp = interpolate_to_common_grid(
            ref_spectrum['wavelength'], ref_spectrum['intensity'],
            stage_spectrum['wavelength'], stage_spectrum['intensity']
        )
        
        # Calculate multiple indicators
        indicators = {
            'Stage': stage,
            'Total_Difference': np.sum(np.abs(stage_interp - ref_interp)),
            'Max_Difference': np.max(np.abs(stage_interp - ref_interp)),
            'RMS_Difference': np.sqrt(np.mean((stage_interp - ref_interp)**2)),
            'Correlation_Loss': 1 - np.corrcoef(ref_interp, stage_interp)[0,1],
            'Signal_Degradation': calculate_signal_degradation(ref_interp, stage_interp),
            'Spectral_Distortion': calculate_spectral_distortion(ref_interp, stage_interp)
        }
        
        timeline_data.append(indicators)
    
    df = pd.DataFrame(timeline_data)
    
    # Create timeline visualization
    fig = make_subplots(
        rows=2, cols=3,
        subplot_titles=[
            'Total Contamination Load',
            'Maximum Local Change',
            'RMS Difference Trend',
            'Correlation Degradation',
            'Signal Quality Loss',
            'Spectral Distortion Index'
        ]
    )
    
    # Plot each indicator
    indicators_info = [
        ('Total_Difference', 'Total Contamination', 'blue', 1, 1),
        ('Max_Difference', 'Max Change', 'red', 1, 2),
        ('RMS_Difference', 'RMS Difference', 'green', 1, 3),
        ('Correlation_Loss', 'Correlation Loss', 'orange', 2, 1),
        ('Signal_Degradation', 'Signal Degradation', 'purple', 2, 2),
        ('Spectral_Distortion', 'Distortion Index', 'brown', 2, 3)
    ]
    
    for indicator, name, color, row, col in indicators_info:
        fig.add_trace(go.Scatter(
            x=df['Stage'],
            y=df[indicator],
            mode='lines+markers',
            name=name,
            line=dict(color=color, width=3),
            marker=dict(size=8)
        ), row=row, col=col)
    
    fig.update_layout(
        title='Contamination Timeline Analysis',
        height=800,
        showlegend=False
    )
    
    return fig

def create_wavelength_sensitivity_map(data, reference_stage=0):
    """
    Create a map showing which wavelengths are most sensitive to contamination
    """
    if reference_stage not in data:
        return None
    
    comparison_stages = [stage for stage in data.keys() if stage != reference_stage]
    
    if not comparison_stages:
        return None
    
    ref_spectrum = get_average_spectrum(data[reference_stage])
    
    # Calculate sensitivity for each wavelength
    wavelength_sensitivity = {}
    
    for stage in comparison_stages:
        stage_spectrum = get_average_spectrum(data[stage])
        
        # Interpolate to common grid
        common_wav, ref_interp, stage_interp = interpolate_to_common_grid(
            ref_spectrum['wavelength'], ref_spectrum['intensity'],
            stage_spectrum['wavelength'], stage_spectrum['intensity']
        )
        
        # Calculate difference for each wavelength
        difference = np.abs(stage_interp - ref_interp)
        
        for wav, diff in zip(common_wav, difference):
            wav_key = round(wav, 1)
            if wav_key not in wavelength_sensitivity:
                wavelength_sensitivity[wav_key] = []
            wavelength_sensitivity[wav_key].append(diff)
    
    # Calculate average sensitivity
    avg_sensitivity = {}
    for wav, diffs in wavelength_sensitivity.items():
        avg_sensitivity[wav] = np.mean(diffs)
    
    # Sort by sensitivity
    sorted_sensitivity = sorted(avg_sensitivity.items(), key=lambda x: x[1], reverse=True)
    
    # Create visualization
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            'Wavelength Sensitivity Map',
            'Top 20 Most Sensitive Wavelengths',
            'Sensitivity Distribution',
            'Contamination Hotspots'
        ]
    )
    
    wavelengths, sensitivities = zip(*sorted_sensitivity)
    
    # 1. Full sensitivity map
    fig.add_trace(go.Scatter(
        x=list(wavelengths),
        y=list(sensitivities),
        mode='lines',
        name='Sensitivity',
        line=dict(color='red', width=2)
    ), row=1, col=1)
    
    # 2. Top 20 most sensitive
    top_20_wav = list(wavelengths)[:20]
    top_20_sens = list(sensitivities)[:20]
    
    fig.add_trace(go.Bar(
        x=top_20_wav,
        y=top_20_sens,
        name='Top 20',
        marker_color='orange'
    ), row=1, col=2)
    
    # 3. Sensitivity distribution
    fig.add_trace(go.Histogram(
        x=list(sensitivities),
        nbinsx=50,
        name='Distribution',
        marker_color='lightblue'
    ), row=2, col=1)
    
    # 4. Contamination hotspots (regions with high sensitivity)
    hotspots = identify_contamination_hotspots(sorted_sensitivity)
    if hotspots:
        hotspot_wav, hotspot_sens = zip(*hotspots)
        fig.add_trace(go.Scatter(
            x=list(hotspot_wav),
            y=list(hotspot_sens),
            mode='markers',
            name='Hotspots',
            marker=dict(size=12, color='red', symbol='star')
        ), row=2, col=2)
    
    fig.update_layout(
        title='Wavelength Sensitivity Analysis for Contamination Detection',
        height=800,
        showlegend=True
    )
    
    return fig, sorted_sensitivity

def create_stage_transition_matrix(data):
    """
    Create a matrix showing transition patterns between stages
    """
    stages = sorted(data.keys())
    n_stages = len(stages)
    
    # Calculate transition matrix
    transition_matrix = np.zeros((n_stages, n_stages))
    
    for i, stage1 in enumerate(stages):
        spectrum1 = get_average_spectrum(data[stage1])
        
        for j, stage2 in enumerate(stages):
            spectrum2 = get_average_spectrum(data[stage2])
            
            # Calculate similarity (inverse of difference)
            similarity = calculate_spectral_similarity(spectrum1, spectrum2)
            transition_matrix[i, j] = similarity
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=transition_matrix,
        x=[f'Stage {s}' for s in stages],
        y=[f'Stage {s}' for s in stages],
        colorscale='RdYlBu',
        text=[[f'{val:.3f}' for val in row] for row in transition_matrix],
        texttemplate="%{text}",
        textfont={"size": 12}
    ))
    
    fig.update_layout(
        title='Stage Transition Similarity Matrix',
        xaxis_title='To Stage',
        yaxis_title='From Stage'
    )
    
    return fig

# Helper functions

def get_average_spectrum(stage_data):
    """Calculate average spectrum for a stage"""
    wavelengths = []
    intensities = []
    
    for file_data in stage_data.values():
        wavelengths.append(file_data['wavelength'])
        intensities.append(file_data['intensity'])
    
    # Find common wavelength range
    min_wav = max(np.min(w) for w in wavelengths)
    max_wav = min(np.max(w) for w in wavelengths)
    
    # Create common grid
    common_wavelength = np.linspace(min_wav, max_wav, 1000)
    
    # Interpolate all spectra and average
    interpolated_intensities = []
    for wav, intens in zip(wavelengths, intensities):
        f = interpolate.interp1d(wav, intens, kind='linear', bounds_error=False, fill_value=0)
        interpolated_intensities.append(f(common_wavelength))
    
    avg_intensity = np.mean(interpolated_intensities, axis=0)
    
    return {
        'wavelength': common_wavelength,
        'intensity': avg_intensity
    }

def interpolate_to_common_grid(wav1, int1, wav2, int2, num_points=1000):
    """Interpolate two spectra to common grid"""
    min_wav = max(np.min(wav1), np.min(wav2))
    max_wav = min(np.max(wav1), np.max(wav2))
    
    common_wav = np.linspace(min_wav, max_wav, num_points)
    
    f1 = interpolate.interp1d(wav1, int1, kind='linear', bounds_error=False, fill_value=0)
    f2 = interpolate.interp1d(wav2, int2, kind='linear', bounds_error=False, fill_value=0)
    
    return common_wav, f1(common_wav), f2(common_wav)

def find_peaks_simple(intensity, prominence=0.1):
    """Find peaks in spectrum"""
    peaks, _ = signal.find_peaks(intensity, prominence=prominence)
    return peaks

def calculate_peak_shift(wavelength, ref_peaks, stage_peaks):
    """Calculate average peak shift"""
    if len(ref_peaks) == 0 or len(stage_peaks) == 0:
        return 0
    
    ref_wavelengths = wavelength[ref_peaks]
    stage_wavelengths = wavelength[stage_peaks]
    
    # Find closest peaks and calculate shift
    shifts = []
    for ref_wav in ref_wavelengths:
        closest_idx = np.argmin(np.abs(stage_wavelengths - ref_wav))
        shift = abs(stage_wavelengths[closest_idx] - ref_wav)
        shifts.append(shift)
    
    return np.mean(shifts) if shifts else 0

def calculate_contamination_index(ref_spectrum, contaminated_spectrum):
    """Calculate overall contamination index"""
    # Normalize spectra
    ref_norm = (ref_spectrum - np.min(ref_spectrum)) / (np.max(ref_spectrum) - np.min(ref_spectrum))
    cont_norm = (contaminated_spectrum - np.min(contaminated_spectrum)) / (np.max(contaminated_spectrum) - np.min(contaminated_spectrum))
    
    # Calculate index based on multiple factors
    rms_diff = np.sqrt(np.mean((cont_norm - ref_norm)**2))
    correlation = np.corrcoef(ref_norm, cont_norm)[0,1]
    
    contamination_index = rms_diff * (1 - correlation)
    return contamination_index

def detect_change_points(wavelength, difference_data):
    """Detect significant change points in spectra"""
    if not difference_data:
        return []
    
    # Calculate variance across all differences
    avg_diff = np.mean(difference_data, axis=0)
    variance = np.var(difference_data, axis=0)
    
    # Find points with high variance (indicating significant changes)
    threshold = np.percentile(variance, 90)
    change_points = wavelength[variance > threshold]
    
    return change_points.tolist()

def calculate_discrimination_scores(data, reference_stage):
    """Calculate how well each wavelength discriminates between stages"""
    ref_spectrum = get_average_spectrum(data[reference_stage])
    comparison_stages = [stage for stage in data.keys() if stage != reference_stage]
    
    discrimination_scores = []
    
    for i, wav in enumerate(ref_spectrum['wavelength'][::10]):  # Subsample for performance
        ref_intensity = ref_spectrum['intensity'][i*10]
        
        stage_intensities = []
        for stage in comparison_stages:
            stage_spectrum = get_average_spectrum(data[stage])
            # Find closest wavelength
            closest_idx = np.argmin(np.abs(stage_spectrum['wavelength'] - wav))
            stage_intensities.append(stage_spectrum['intensity'][closest_idx])
        
        # Calculate discrimination power (variance across stages)
        if len(stage_intensities) > 1:
            discrimination = np.var(stage_intensities + [ref_intensity])
            discrimination_scores.append((wav, discrimination))
    
    return sorted(discrimination_scores, key=lambda x: x[1], reverse=True)

def calculate_signal_degradation(ref_spectrum, contaminated_spectrum):
    """Calculate signal degradation index"""
    ref_energy = np.sum(ref_spectrum**2)
    cont_energy = np.sum(contaminated_spectrum**2)
    
    if ref_energy == 0:
        return 0
    
    energy_loss = abs(cont_energy - ref_energy) / ref_energy
    return energy_loss

def calculate_spectral_distortion(ref_spectrum, contaminated_spectrum):
    """Calculate spectral distortion index"""
    # Calculate spectral centroid shift
    wavelength_proxy = np.arange(len(ref_spectrum))
    
    ref_centroid = np.sum(wavelength_proxy * ref_spectrum) / np.sum(ref_spectrum)
    cont_centroid = np.sum(wavelength_proxy * contaminated_spectrum) / np.sum(contaminated_spectrum)
    
    centroid_shift = abs(cont_centroid - ref_centroid)
    
    # Normalize by spectrum length
    distortion = centroid_shift / len(ref_spectrum)
    return distortion

def calculate_spectral_similarity(spectrum1, spectrum2):
    """Calculate spectral similarity"""
    # Interpolate to common grid
    common_wav, int1, int2 = interpolate_to_common_grid(
        spectrum1['wavelength'], spectrum1['intensity'],
        spectrum2['wavelength'], spectrum2['intensity']
    )
    
    # Calculate correlation
    correlation = np.corrcoef(int1, int2)[0,1]
    return correlation if not np.isnan(correlation) else 0

def identify_contamination_hotspots(sensitivity_data, threshold_percentile=95):
    """Identify contamination hotspots"""
    if not sensitivity_data:
        return []
    
    # Calculate threshold
    sensitivities = [item[1] for item in sensitivity_data]
    threshold = np.percentile(sensitivities, threshold_percentile)
    
    # Filter hotspots
    hotspots = [item for item in sensitivity_data if item[1] >= threshold]
    return hotspots