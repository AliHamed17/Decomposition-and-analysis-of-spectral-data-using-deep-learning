import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import signal
from scipy.stats import gaussian_kde
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

def plot_spectral_waterfall(data, stage, max_files=20):
    """
    Create a 3D waterfall plot showing multiple spectra in a stage
    """
    if stage not in data:
        return None
    
    stage_data = data[stage]
    file_numbers = list(stage_data.keys())[:max_files]
    
    fig = go.Figure()
    
    for i, file_num in enumerate(file_numbers):
        file_data = stage_data[file_num]
        wavelength = file_data['wavelength']
        intensity = file_data['intensity']
        
        # Add offset for 3D effect
        y_offset = i * 0.1
        
        fig.add_trace(go.Scatter3d(
            x=wavelength,
            y=[y_offset] * len(wavelength),
            z=intensity,
            mode='lines',
            name=f'File {file_num}',
            line=dict(width=2),
            showlegend=False
        ))
    
    fig.update_layout(
        title=f'Spectral Waterfall Plot - Stage {stage}',
        scene=dict(
            xaxis_title='Wavelength',
            yaxis_title='File Number',
            zaxis_title='Intensity',
            camera=dict(eye=dict(x=1.5, y=1.5, z=1.5))
        ),
        height=600
    )
    
    return fig

def plot_correlation_matrix(data, stages=None):
    """
    Create a correlation matrix between different files and stages
    """
    if stages is None:
        stages = list(data.keys())
    
    # Collect all intensity data
    intensity_data = {}
    labels = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                intensity = file_data['intensity']
                key = f'S{stage}_F{file_num}'
                intensity_data[key] = intensity
                labels.append(key)
    
    # Create DataFrame for correlation
    min_length = min(len(arr) for arr in intensity_data.values())
    correlation_data = {}
    
    for key, intensity in intensity_data.items():
        # Downsample to common length
        indices = np.linspace(0, len(intensity)-1, min_length, dtype=int)
        correlation_data[key] = intensity[indices]
    
    df = pd.DataFrame(correlation_data)
    correlation_matrix = df.corr()
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=correlation_matrix.values,
        x=correlation_matrix.columns,
        y=correlation_matrix.index,
        colorscale='RdBu',
        zmid=0,
        text=np.round(correlation_matrix.values, 2),
        texttemplate='%{text}',
        textfont={"size": 8},
        hovertemplate='%{x} vs %{y}<br>Correlation: %{z:.3f}<extra></extra>'
    ))
    
    fig.update_layout(
        title='Spectral Correlation Matrix',
        xaxis_title='Files',
        yaxis_title='Files',
        height=max(400, len(labels) * 20)
    )
    
    return fig

def plot_pca_analysis(data, stages=None, n_components=3):
    """
    Perform PCA analysis and visualize results
    """
    if stages is None:
        stages = list(data.keys())
    
    # Prepare data for PCA
    X = []
    labels = []
    stage_labels = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                intensity = file_data['intensity']
                X.append(intensity)
                labels.append(f'S{stage}_F{file_num}')
                stage_labels.append(stage)
    
    if len(X) == 0:
        return None
    
    # Standardize and apply PCA
    X = np.array(X)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    pca = PCA(n_components=min(n_components, X_scaled.shape[1]))
    X_pca = pca.fit_transform(X_scaled)
    
    # Create 3D scatter plot
    if X_pca.shape[1] >= 3:
        fig = go.Figure(data=go.Scatter3d(
            x=X_pca[:, 0],
            y=X_pca[:, 1],
            z=X_pca[:, 2],
            mode='markers',
            marker=dict(
                size=8,
                color=stage_labels,
                colorscale='Viridis',
                showscale=True,
                colorbar=dict(title="Stage")
            ),
            text=labels,
            hovertemplate='%{text}<br>PC1: %{x:.2f}<br>PC2: %{y:.2f}<br>PC3: %{z:.2f}<extra></extra>'
        ))
        
        explained_var = pca.explained_variance_ratio_
        fig.update_layout(
            title=f'PCA Analysis - Explained Variance: PC1={explained_var[0]:.1%}, PC2={explained_var[1]:.1%}, PC3={explained_var[2]:.1%}',
            scene=dict(
                xaxis_title=f'PC1 ({explained_var[0]:.1%})',
                yaxis_title=f'PC2 ({explained_var[1]:.1%})',
                zaxis_title=f'PC3 ({explained_var[2]:.1%})'
            ),
            height=600
        )
    else:
        # 2D plot if less than 3 components
        fig = go.Figure(data=go.Scatter(
            x=X_pca[:, 0],
            y=X_pca[:, 1],
            mode='markers',
            marker=dict(
                size=10,
                color=stage_labels,
                colorscale='Viridis',
                showscale=True,
                colorbar=dict(title="Stage")
            ),
            text=labels,
            hovertemplate='%{text}<br>PC1: %{x:.2f}<br>PC2: %{y:.2f}<extra></extra>'
        ))
        
        explained_var = pca.explained_variance_ratio_
        fig.update_layout(
            title=f'PCA Analysis - Explained Variance: PC1={explained_var[0]:.1%}, PC2={explained_var[1]:.1%}',
            xaxis_title=f'PC1 ({explained_var[0]:.1%})',
            yaxis_title=f'PC2 ({explained_var[1]:.1%})',
            height=600
        )
    
    return fig, pca.explained_variance_ratio_

def plot_tsne_analysis(data, stages=None, perplexity=30):
    """
    Perform t-SNE analysis for non-linear dimensionality reduction
    """
    if stages is None:
        stages = list(data.keys())
    
    # Prepare data for t-SNE
    X = []
    labels = []
    stage_labels = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                intensity = file_data['intensity']
                X.append(intensity)
                labels.append(f'S{stage}_F{file_num}')
                stage_labels.append(stage)
    
    if len(X) < 4:  # t-SNE needs at least 4 samples
        return None
    
    # Standardize and apply t-SNE
    X = np.array(X)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Adjust perplexity if needed
    max_perplexity = (len(X) - 1) // 3
    perplexity = min(perplexity, max_perplexity)
    
    tsne = TSNE(n_components=2, perplexity=perplexity, random_state=42)
    X_tsne = tsne.fit_transform(X_scaled)
    
    # Create scatter plot
    fig = go.Figure(data=go.Scatter(
        x=X_tsne[:, 0],
        y=X_tsne[:, 1],
        mode='markers',
        marker=dict(
            size=10,
            color=stage_labels,
            colorscale='Viridis',
            showscale=True,
            colorbar=dict(title="Stage")
        ),
        text=labels,
        hovertemplate='%{text}<br>t-SNE1: %{x:.2f}<br>t-SNE2: %{y:.2f}<extra></extra>'
    ))
    
    fig.update_layout(
        title=f't-SNE Analysis (Perplexity={perplexity})',
        xaxis_title='t-SNE Component 1',
        yaxis_title='t-SNE Component 2',
        height=600
    )
    
    return fig

def plot_spectral_derivatives(data, stage, file_num, orders=[1, 2]):
    """
    Plot spectral derivatives to highlight features
    """
    if stage not in data or file_num not in data[stage]:
        return None
    
    file_data = data[stage][file_num]
    wavelength = file_data['wavelength']
    intensity = file_data['intensity']
    
    fig = make_subplots(
        rows=len(orders) + 1, cols=1,
        subplot_titles=['Original Spectrum'] + [f'{order}st Derivative' if order == 1 else f'{order}nd Derivative' for order in orders],
        vertical_spacing=0.1
    )
    
    # Original spectrum
    fig.add_trace(
        go.Scatter(x=wavelength, y=intensity, mode='lines', name='Original', line=dict(color='blue')),
        row=1, col=1
    )
    
    # Calculate and plot derivatives
    current_signal = intensity
    for i, order in enumerate(orders):
        derivative = np.gradient(current_signal, wavelength)
        current_signal = derivative
        
        fig.add_trace(
            go.Scatter(
                x=wavelength, y=derivative, mode='lines', 
                name=f'{order}st Derivative' if order == 1 else f'{order}nd Derivative',
                line=dict(color=['red', 'green', 'orange'][i % 3])
            ),
            row=i + 2, col=1
        )
    
    fig.update_layout(
        title=f'Spectral Derivatives - Stage {stage}, File {file_num}',
        height=200 * (len(orders) + 1),
        showlegend=False
    )
    
    return fig

def plot_spectral_density(data, stages=None, wavelength_range=None):
    """
    Create a density plot showing intensity distributions across wavelengths
    """
    if stages is None:
        stages = list(data.keys())
    
    fig = go.Figure()
    
    for stage in stages:
        if stage not in data:
            continue
            
        # Collect all intensities for this stage
        all_wavelengths = []
        all_intensities = []
        
        for file_num, file_data in data[stage].items():
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            
            if wavelength_range:
                mask = (wavelength >= wavelength_range[0]) & (wavelength <= wavelength_range[1])
                wavelength = wavelength[mask]
                intensity = intensity[mask]
            
            all_wavelengths.extend(wavelength)
            all_intensities.extend(intensity)
        
        if all_wavelengths:
            # Create 2D histogram
            fig.add_trace(go.Histogram2d(
                x=all_wavelengths,
                y=all_intensities,
                name=f'Stage {stage}',
                nbinsx=50,
                nbinsy=50,
                colorscale='Viridis',
                showscale=True
            ))
    
    fig.update_layout(
        title='Spectral Density Distribution',
        xaxis_title='Wavelength',
        yaxis_title='Intensity',
        height=600
    )
    
    return fig

def plot_peak_analysis(data, stage, prominence=0.1, distance=10):
    """
    Analyze and visualize spectral peaks across files in a stage
    """
    if stage not in data:
        return None
    
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=['Individual Spectra with Peaks', 'Peak Distribution'],
        vertical_spacing=0.15
    )
    
    all_peak_positions = []
    colors = px.colors.qualitative.Set1
    
    for i, (file_num, file_data) in enumerate(data[stage].items()):
        wavelength = file_data['wavelength']
        intensity = file_data['intensity']
        
        # Find peaks
        peaks, properties = signal.find_peaks(intensity, prominence=prominence, distance=distance)
        peak_wavelengths = wavelength[peaks]
        peak_intensities = intensity[peaks]
        
        all_peak_positions.extend(peak_wavelengths)
        
        color = colors[i % len(colors)]
        
        # Plot spectrum
        fig.add_trace(
            go.Scatter(
                x=wavelength, y=intensity, mode='lines',
                name=f'File {file_num}', line=dict(color=color),
                showlegend=False
            ),
            row=1, col=1
        )
        
        # Plot peaks
        fig.add_trace(
            go.Scatter(
                x=peak_wavelengths, y=peak_intensities, mode='markers',
                name=f'Peaks F{file_num}', marker=dict(color=color, size=8, symbol='diamond'),
                showlegend=False
            ),
            row=1, col=1
        )
    
    # Peak distribution histogram
    if all_peak_positions:
        fig.add_trace(
            go.Histogram(
                x=all_peak_positions, nbinsx=30,
                name='Peak Distribution', marker_color='lightblue',
                showlegend=False
            ),
            row=2, col=1
        )
    
    fig.update_layout(
        title=f'Peak Analysis - Stage {stage}',
        height=800
    )
    
    fig.update_xaxes(title_text="Wavelength", row=1, col=1)
    fig.update_yaxes(title_text="Intensity", row=1, col=1)
    fig.update_xaxes(title_text="Wavelength", row=2, col=1)
    fig.update_yaxes(title_text="Peak Count", row=2, col=1)
    
    return fig

def plot_spectral_evolution(data, file_nums=None, stages=None):
    """
    Show how a specific file number evolves across different stages
    """
    if stages is None:
        stages = sorted(data.keys())
    if file_nums is None:
        # Find common file numbers across stages
        common_files = set()
        for stage in stages:
            if stage in data:
                if not common_files:
                    common_files = set(data[stage].keys())
                else:
                    common_files &= set(data[stage].keys())
        file_nums = sorted(list(common_files))[:5]  # Limit to 5 files
    
    fig = go.Figure()
    
    for file_num in file_nums:
        stage_data_for_file = []
        stage_labels = []
        
        for stage in stages:
            if stage in data and file_num in data[stage]:
                intensity = data[stage][file_num]['intensity']
                stage_data_for_file.append(np.mean(intensity))  # Use mean intensity as metric
                stage_labels.append(stage)
        
        if stage_data_for_file:
            fig.add_trace(go.Scatter(
                x=stage_labels,
                y=stage_data_for_file,
                mode='lines+markers',
                name=f'File {file_num}',
                line=dict(width=3),
                marker=dict(size=8)
            ))
    
    fig.update_layout(
        title='Spectral Evolution Across Stages',
        xaxis_title='Stage',
        yaxis_title='Mean Intensity',
        height=500,
        hovermode='x unified'
    )
    
    return fig

def plot_wavelength_intensity_heatmap(data, stages=None, bin_size=50):
    """
    Create a comprehensive heatmap of intensity vs wavelength across all data
    """
    if stages is None:
        stages = list(data.keys())
    
    # Collect all data points
    wavelengths = []
    intensities = []
    stage_info = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                wavelength = file_data['wavelength']
                intensity = file_data['intensity']
                wavelengths.extend(wavelength)
                intensities.extend(intensity)
                stage_info.extend([stage] * len(wavelength))
    
    # Create bins
    wavelength_bins = np.linspace(min(wavelengths), max(wavelengths), bin_size)
    intensity_bins = np.linspace(min(intensities), max(intensities), bin_size)
    
    # Create 2D histogram
    hist, x_edges, y_edges = np.histogram2d(wavelengths, intensities, bins=[wavelength_bins, intensity_bins])
    
    fig = go.Figure(data=go.Heatmap(
        z=hist.T,
        x=x_edges[:-1],
        y=y_edges[:-1],
        colorscale='Viridis',
        colorbar=dict(title="Count")
    ))
    
    fig.update_layout(
        title='Wavelength vs Intensity Distribution Heatmap',
        xaxis_title='Wavelength',
        yaxis_title='Intensity',
        height=600
    )
    
    return fig