import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import batch_job_manager as job_mgr
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

class JobComplexityAnalyzer:
    def __init__(self):
        self.complexity_weights = {
            'runtime_factor': 0.25,
            'resource_factor': 0.25,
            'failure_factor': 0.20,
            'dependency_factor': 0.15,
            'priority_factor': 0.15
        }
        
        self.complexity_levels = {
            'Simple': (0, 0.3),
            'Moderate': (0.3, 0.6),
            'Complex': (0.6, 0.8),
            'Critical': (0.8, 1.0)
        }
    
    def generate_comprehensive_job_data(self, num_jobs=50):
        """Generate comprehensive job data with complexity factors"""
        np.random.seed(42)
        
        job_types = ['peak_analysis', 'statistical_analysis', 'anomaly_detection', 
                    'data_preprocessing', 'model_training', 'batch_export', 'data_validation']
        priorities = ['Low', 'Normal', 'High', 'Urgent']
        statuses = ['completed', 'failed', 'running', 'cancelled']
        
        data = []
        for i in range(num_jobs):
            job_type = np.random.choice(job_types)
            priority = np.random.choice(priorities, p=[0.3, 0.4, 0.2, 0.1])
            status = np.random.choice(statuses, p=[0.7, 0.15, 0.1, 0.05])
            
            # Base complexity factors by job type
            base_complexity = {
                'peak_analysis': 0.4,
                'statistical_analysis': 0.5,
                'anomaly_detection': 0.7,
                'data_preprocessing': 0.3,
                'model_training': 0.8,
                'batch_export': 0.2,
                'data_validation': 0.4
            }[job_type]
            
            # Runtime varies with complexity
            base_runtime = np.random.uniform(30, 300) * (1 + base_complexity)
            actual_runtime = base_runtime * np.random.uniform(0.7, 1.5)
            
            # Resource usage correlates with complexity
            cpu_usage = np.clip(np.random.normal(50, 20) * (1 + base_complexity * 0.5), 10, 95)
            memory_usage = np.clip(np.random.normal(45, 15) * (1 + base_complexity * 0.6), 15, 90)
            
            # File processing complexity
            files_processed = int(np.random.exponential(20) * (1 + base_complexity))
            data_size_mb = np.random.uniform(10, 1000) * (1 + base_complexity)
            
            # Dependencies and interactions
            num_dependencies = int(np.random.poisson(2) * (1 + base_complexity * 0.5))
            parallel_tasks = max(1, int(np.random.poisson(3) * (1 - base_complexity * 0.3)))
            
            # Error patterns
            error_probability = base_complexity * 0.3 + np.random.uniform(0, 0.1)
            retry_count = int(np.random.poisson(1) * base_complexity) if status == 'failed' else 0
            
            # Performance metrics
            throughput = files_processed / max(1, actual_runtime / 60)  # files per minute
            efficiency_score = (100 if status == 'completed' else 0) / max(1, actual_runtime / 60)
            
            # Success patterns
            success_rate = 1.0 if status == 'completed' else 0.0
            if status == 'failed':
                success_rate = max(0, 1 - error_probability - np.random.uniform(0, 0.3))
            
            data.append({
                'job_id': f"job_{i+1:03d}",
                'job_type': job_type,
                'priority': priority,
                'status': status,
                'runtime_seconds': actual_runtime,
                'cpu_usage': cpu_usage,
                'memory_usage': memory_usage,
                'files_processed': files_processed,
                'data_size_mb': data_size_mb,
                'num_dependencies': num_dependencies,
                'parallel_tasks': parallel_tasks,
                'error_probability': error_probability,
                'retry_count': retry_count,
                'throughput': throughput,
                'efficiency_score': efficiency_score,
                'success_rate': success_rate,
                'created_at': datetime.now() - timedelta(days=np.random.randint(1, 30)),
                'base_complexity': base_complexity
            })
        
        return pd.DataFrame(data)
    
    def calculate_complexity_score(self, job_data):
        """Calculate comprehensive complexity score for each job"""
        scores = []
        
        for _, job in job_data.iterrows():
            # Runtime complexity (normalized by job type median)
            type_median_runtime = job_data[job_data['job_type'] == job['job_type']]['runtime_seconds'].median()
            runtime_factor = min(1.0, job['runtime_seconds'] / max(1, type_median_runtime))
            
            # Resource complexity
            resource_factor = (job['cpu_usage'] + job['memory_usage']) / 200.0
            
            # Failure/retry complexity
            failure_factor = (job['error_probability'] + job['retry_count'] * 0.1)
            
            # Dependency complexity
            dependency_factor = min(1.0, (job['num_dependencies'] + 1/max(1, job['parallel_tasks'])) / 10.0)
            
            # Priority urgency factor
            priority_weights = {'Low': 0.1, 'Normal': 0.3, 'High': 0.7, 'Urgent': 1.0}
            priority_factor = priority_weights.get(job['priority'], 0.3)
            
            # Weighted complexity score
            complexity_score = (
                runtime_factor * self.complexity_weights['runtime_factor'] +
                resource_factor * self.complexity_weights['resource_factor'] +
                failure_factor * self.complexity_weights['failure_factor'] +
                dependency_factor * self.complexity_weights['dependency_factor'] +
                priority_factor * self.complexity_weights['priority_factor']
            )
            
            scores.append(min(1.0, complexity_score))
        
        return scores
    
    def classify_complexity_level(self, score):
        """Classify job into complexity levels"""
        for level, (min_score, max_score) in self.complexity_levels.items():
            if min_score <= score < max_score:
                return level
        return 'Critical'
    
    def perform_complexity_clustering(self, job_data):
        """Perform clustering analysis to identify complexity patterns"""
        # Prepare features for clustering
        features = ['runtime_seconds', 'cpu_usage', 'memory_usage', 'files_processed', 
                   'num_dependencies', 'error_probability', 'throughput']
        
        clustering_data = job_data[features].fillna(0)
        
        # Standardize features
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(clustering_data)
        
        # Find optimal number of clusters
        silhouette_scores = []
        K_range = range(2, min(8, len(job_data)//3))
        
        best_k = 3
        best_score = 0
        
        for k in K_range:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(scaled_data)
            score = silhouette_score(scaled_data, cluster_labels)
            silhouette_scores.append(score)
            
            if score > best_score:
                best_score = score
                best_k = k
        
        # Final clustering with best k
        final_kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
        job_data['cluster'] = final_kmeans.fit_predict(scaled_data)
        job_data['cluster_name'] = job_data['cluster'].map({
            0: 'Low Complexity',
            1: 'Medium Complexity', 
            2: 'High Complexity',
            3: 'Critical Complexity'
        })
        
        return job_data, final_kmeans, scaler, silhouette_scores
    
    def analyze_complexity_drivers(self, job_data):
        """Identify key drivers of job complexity"""
        correlations = job_data[['complexity_score', 'runtime_seconds', 'cpu_usage', 
                               'memory_usage', 'files_processed', 'num_dependencies', 
                               'error_probability', 'retry_count']].corr()['complexity_score'].abs().sort_values(ascending=False)
        
        return correlations.drop('complexity_score')
    
    def generate_optimization_recommendations(self, job_data):
        """Generate actionable optimization recommendations"""
        recommendations = []
        
        # Analyze high complexity jobs
        high_complexity = job_data[job_data['complexity_level'].isin(['Complex', 'Critical'])]
        
        if not high_complexity.empty:
            # Runtime optimization
            slow_jobs = high_complexity[high_complexity['runtime_seconds'] > high_complexity['runtime_seconds'].quantile(0.75)]
            if not slow_jobs.empty:
                avg_runtime = slow_jobs['runtime_seconds'].mean()
                recommendations.append({
                    'category': 'Runtime Optimization',
                    'priority': 'High',
                    'issue': f'{len(slow_jobs)} jobs with excessive runtime (avg: {avg_runtime:.1f}s)',
                    'recommendation': 'Consider parallel processing, algorithm optimization, or resource scaling',
                    'impact': 'Could reduce processing time by 30-50%'
                })
            
            # Resource optimization
            resource_intensive = high_complexity[(high_complexity['cpu_usage'] > 80) | (high_complexity['memory_usage'] > 80)]
            if not resource_intensive.empty:
                recommendations.append({
                    'category': 'Resource Management',
                    'priority': 'Medium',
                    'issue': f'{len(resource_intensive)} jobs with high resource usage',
                    'recommendation': 'Implement resource monitoring and dynamic allocation',
                    'impact': 'Better resource utilization and reduced bottlenecks'
                })
            
            # Error handling
            error_prone = high_complexity[high_complexity['error_probability'] > 0.3]
            if not error_prone.empty:
                recommendations.append({
                    'category': 'Error Handling',
                    'priority': 'High',
                    'issue': f'{len(error_prone)} jobs with high failure rates',
                    'recommendation': 'Implement better error handling, validation, and retry logic',
                    'impact': 'Improved reliability and reduced manual intervention'
                })
            
            # Dependency optimization
            dependency_heavy = high_complexity[high_complexity['num_dependencies'] > 5]
            if not dependency_heavy.empty:
                recommendations.append({
                    'category': 'Dependency Management',
                    'priority': 'Medium',
                    'issue': f'{len(dependency_heavy)} jobs with complex dependencies',
                    'recommendation': 'Simplify workflows and reduce inter-job dependencies',
                    'impact': 'Faster execution and easier troubleshooting'
                })
        
        # Performance insights
        if len(job_data) > 10:
            throughput_stats = job_data['throughput'].describe()
            if throughput_stats['std'] > throughput_stats['mean'] * 0.5:
                recommendations.append({
                    'category': 'Performance Consistency',
                    'priority': 'Medium',
                    'issue': 'High variability in job throughput detected',
                    'recommendation': 'Standardize processing approaches and implement performance monitoring',
                    'impact': 'More predictable execution times'
                })
        
        return recommendations
    
    def create_complexity_overview_chart(self, job_data):
        """Create comprehensive complexity overview visualization"""
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Complexity Distribution', 'Complexity vs Runtime', 
                          'Resource Usage Patterns', 'Success Rate by Complexity'),
            specs=[[{"type": "xy"}, {"type": "xy"}],
                   [{"type": "xy"}, {"type": "xy"}]]
        )
        
        # Complexity distribution
        complexity_counts = job_data['complexity_level'].value_counts()
        fig.add_trace(
            go.Bar(x=complexity_counts.index, y=complexity_counts.values,
                  marker_color=['green', 'yellow', 'orange', 'red'],
                  name='Job Count'),
            row=1, col=1
        )
        
        # Complexity vs Runtime scatter
        colors = {'Simple': 'green', 'Moderate': 'yellow', 'Complex': 'orange', 'Critical': 'red'}
        for level in job_data['complexity_level'].unique():
            level_data = job_data[job_data['complexity_level'] == level]
            fig.add_trace(
                go.Scatter(x=level_data['complexity_score'], y=level_data['runtime_seconds'],
                          mode='markers', name=level, marker_color=colors.get(level, 'blue'),
                          showlegend=False),
                row=1, col=2
            )
        
        # Resource usage by complexity
        fig.add_trace(
            go.Scatter(x=job_data['cpu_usage'], y=job_data['memory_usage'],
                      mode='markers', marker=dict(
                          size=job_data['complexity_score']*20,
                          color=job_data['complexity_score'],
                          colorscale='Viridis',
                          showscale=True,
                          colorbar=dict(title="Complexity Score")
                      ),
                      showlegend=False),
            row=2, col=1
        )
        
        # Success rate by complexity
        success_by_complexity = job_data.groupby('complexity_level')['success_rate'].mean()
        fig.add_trace(
            go.Bar(x=success_by_complexity.index, y=success_by_complexity.values,
                  marker_color=['green', 'yellow', 'orange', 'red'],
                  showlegend=False),
            row=2, col=2
        )
        
        fig.update_layout(height=600, title_text="Job Complexity Analysis Overview")
        fig.update_xaxes(title_text="Complexity Level", row=1, col=1)
        fig.update_xaxes(title_text="Complexity Score", row=1, col=2)
        fig.update_xaxes(title_text="CPU Usage (%)", row=2, col=1)
        fig.update_xaxes(title_text="Complexity Level", row=2, col=2)
        fig.update_yaxes(title_text="Job Count", row=1, col=1)
        fig.update_yaxes(title_text="Runtime (seconds)", row=1, col=2)
        fig.update_yaxes(title_text="Memory Usage (%)", row=2, col=1)
        fig.update_yaxes(title_text="Success Rate", row=2, col=2)
        
        return fig
    
    def create_complexity_drivers_chart(self, drivers):
        """Create chart showing complexity drivers"""
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            x=drivers.values,
            y=drivers.index,
            orientation='h',
            marker_color='lightblue',
            text=[f'{v:.3f}' for v in drivers.values],
            textposition='auto'
        ))
        
        fig.update_layout(
            title='Key Complexity Drivers (Correlation with Complexity Score)',
            xaxis_title='Correlation Coefficient',
            yaxis_title='Factors',
            height=400
        )
        
        return fig
    
    def create_cluster_analysis_chart(self, job_data):
        """Create cluster analysis visualization"""
        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('Job Clusters by Runtime and Resources', 'Cluster Characteristics'),
            specs=[[{"type": "xy"}, {"type": "xy"}]]
        )
        
        # Cluster scatter plot
        colors = px.colors.qualitative.Set1
        for i, cluster in enumerate(job_data['cluster_name'].unique()):
            cluster_data = job_data[job_data['cluster_name'] == cluster]
            fig.add_trace(
                go.Scatter(
                    x=cluster_data['runtime_seconds'],
                    y=cluster_data['cpu_usage'],
                    mode='markers',
                    name=cluster,
                    marker_color=colors[i % len(colors)],
                    marker_size=8
                ),
                row=1, col=1
            )
        
        # Cluster characteristics
        cluster_stats = job_data.groupby('cluster_name').agg({
            'complexity_score': 'mean',
            'runtime_seconds': 'mean',
            'success_rate': 'mean'
        }).reset_index()
        
        fig.add_trace(
            go.Bar(
                x=cluster_stats['cluster_name'],
                y=cluster_stats['complexity_score'],
                name='Avg Complexity',
                marker_color='lightcoral'
            ),
            row=1, col=2
        )
        
        fig.update_layout(height=400, title_text="Complexity Clustering Analysis")
        fig.update_xaxes(title_text="Runtime (seconds)", row=1, col=1)
        fig.update_xaxes(title_text="Cluster", row=1, col=2)
        fig.update_yaxes(title_text="CPU Usage (%)", row=1, col=1)
        fig.update_yaxes(title_text="Average Complexity Score", row=1, col=2)
        
        return fig
    
    def create_one_click_analysis_dashboard(self, job_manager=None):
        """Create the main one-click complexity analysis dashboard"""
        
        st.markdown("""
        <div class="analysis-section">
            <h2>🔍 One-Click Job Complexity Analyzer</h2>
            <p>Intelligent analysis of batch job complexity patterns with automated insights and optimization recommendations</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Analysis controls
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            data_source = st.radio(
                "Analysis Data Source:",
                ["Demo Data (Comprehensive Analysis)", "Live Job Data (Current Session)"],
                help="Choose between comprehensive demo data or live job manager data"
            )
        
        with col2:
            if data_source == "Demo Data (Comprehensive Analysis)":
                num_jobs = st.slider("Number of jobs to analyze", 20, 100, 50)
        
        with col3:
            analyze_button = st.button("🚀 Run One-Click Analysis", type="primary", use_container_width=True)
        
        if analyze_button or st.session_state.get('complexity_analysis_complete', False):
            with st.spinner("Running comprehensive complexity analysis..."):
                # Generate or load data
                if data_source == "Demo Data (Comprehensive Analysis)":
                    job_data = self.generate_comprehensive_job_data(num_jobs)
                else:
                    if job_manager and len(job_manager.get_all_jobs()) > 0:
                        # Convert job manager data
                        jobs = job_manager.get_all_jobs()
                        job_records = []
                        for job in jobs:
                            job_records.append({
                                'job_id': job.job_id,
                                'job_type': job.job_type,
                                'priority': job.priority.name,
                                'status': job.status.value,
                                'runtime_seconds': job.get_runtime(),
                                'cpu_usage': job.resource_usage.get('cpu_usage', 50),
                                'memory_usage': job.resource_usage.get('memory_usage', 40),
                                'files_processed': job.resource_usage.get('files_processed', 10),
                                'data_size_mb': np.random.uniform(50, 500),
                                'num_dependencies': np.random.randint(1, 5),
                                'parallel_tasks': np.random.randint(1, 4),
                                'error_probability': 0.0 if job.status.value == 'completed' else 0.5,
                                'retry_count': 0,
                                'throughput': 10 / max(1, job.get_runtime() / 60),
                                'efficiency_score': job.progress / max(1, job.get_runtime() / 60),
                                'success_rate': 1.0 if job.status.value == 'completed' else 0.0,
                                'created_at': job.created_at
                            })
                        job_data = pd.DataFrame(job_records)
                        if len(job_data) < 10:
                            st.warning("Limited live data available. Using demo data for comprehensive analysis.")
                            job_data = self.generate_comprehensive_job_data(30)
                    else:
                        st.warning("No job manager data available. Using demo data.")
                        job_data = self.generate_comprehensive_job_data(30)
                
                # Calculate complexity scores
                job_data['complexity_score'] = self.calculate_complexity_score(job_data)
                job_data['complexity_level'] = job_data['complexity_score'].apply(self.classify_complexity_level)
                
                # Perform clustering analysis
                job_data, kmeans_model, scaler, silhouette_scores = self.perform_complexity_clustering(job_data)
                
                # Analyze complexity drivers
                complexity_drivers = self.analyze_complexity_drivers(job_data)
                
                # Generate recommendations
                recommendations = self.generate_optimization_recommendations(job_data)
                
                st.session_state.complexity_analysis_complete = True
            
            # Display results
            st.success("✅ Complexity analysis completed successfully!")
            
            # Key metrics overview
            st.write("### 📊 Complexity Analysis Summary")
            
            col1, col2, col3, col4, col5 = st.columns(5)
            
            with col1:
                avg_complexity = job_data['complexity_score'].mean()
                st.metric("Average Complexity", f"{avg_complexity:.2f}")
            
            with col2:
                critical_jobs = len(job_data[job_data['complexity_level'] == 'Critical'])
                st.metric("Critical Jobs", critical_jobs)
            
            with col3:
                high_resource_jobs = len(job_data[(job_data['cpu_usage'] > 80) | (job_data['memory_usage'] > 80)])
                st.metric("High Resource Jobs", high_resource_jobs)
            
            with col4:
                avg_runtime = job_data['runtime_seconds'].mean()
                st.metric("Avg Runtime", f"{avg_runtime:.1f}s")
            
            with col5:
                success_rate = job_data['success_rate'].mean()
                st.metric("Success Rate", f"{success_rate:.1%}")
            
            # Complexity overview visualization
            st.write("### 🔥 Complexity Analysis Overview")
            complexity_overview_fig = self.create_complexity_overview_chart(job_data)
            st.plotly_chart(complexity_overview_fig, use_container_width=True)
            
            # Two-column layout for detailed analysis
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("#### 🎯 Complexity Drivers")
                drivers_fig = self.create_complexity_drivers_chart(complexity_drivers)
                st.plotly_chart(drivers_fig, use_container_width=True)
                
                # Top complexity drivers insights
                st.write("**Key Insights:**")
                top_drivers = complexity_drivers.head(3)
                for driver, correlation in top_drivers.items():
                    impact = "High" if correlation > 0.5 else "Medium" if correlation > 0.3 else "Low"
                    st.write(f"- **{driver.replace('_', ' ').title()}**: {impact} impact ({correlation:.3f})")
            
            with col2:
                st.write("#### 🏷️ Complexity Clustering")
                cluster_fig = self.create_cluster_analysis_chart(job_data)
                st.plotly_chart(cluster_fig, use_container_width=True)
                
                # Cluster insights
                st.write("**Cluster Summary:**")
                cluster_summary = job_data.groupby('cluster_name').agg({
                    'complexity_score': 'mean',
                    'job_id': 'count'
                }).round(3)
                cluster_summary.columns = ['Avg Complexity', 'Job Count']
                st.dataframe(cluster_summary, use_container_width=True)
            
            # Optimization recommendations
            st.write("### 💡 Optimization Recommendations")
            
            if recommendations:
                for i, rec in enumerate(recommendations):
                    with st.expander(f"🔧 {rec['category']} - {rec['priority']} Priority"):
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            st.write(f"**Issue:** {rec['issue']}")
                            st.write(f"**Recommendation:** {rec['recommendation']}")
                            st.write(f"**Expected Impact:** {rec['impact']}")
                        
                        with col2:
                            priority_color = {"High": "🔴", "Medium": "🟡", "Low": "🟢"}
                            st.write(f"**Priority:** {priority_color.get(rec['priority'], '🔵')} {rec['priority']}")
            else:
                st.info("🎉 No critical optimization opportunities detected. Jobs are running efficiently!")
            
            # Detailed analysis tables
            st.write("### 📋 Detailed Analysis")
            
            tab1, tab2, tab3 = st.tabs(["Job Details", "Complexity Distribution", "Performance Metrics"])
            
            with tab1:
                # Job details with complexity scores
                display_columns = ['job_id', 'job_type', 'complexity_level', 'complexity_score', 
                                 'runtime_seconds', 'cpu_usage', 'memory_usage', 'success_rate']
                job_display = job_data[display_columns].round(3)
                job_display = job_display.sort_values('complexity_score', ascending=False)
                st.dataframe(job_display, use_container_width=True, hide_index=True)
            
            with tab2:
                # Complexity distribution analysis
                complexity_dist = job_data['complexity_level'].value_counts()
                st.write("**Complexity Level Distribution:**")
                for level, count in complexity_dist.items():
                    percentage = (count / len(job_data)) * 100
                    st.write(f"- {level}: {count} jobs ({percentage:.1f}%)")
                
                st.write("**Complexity Score Statistics:**")
                complexity_stats = job_data['complexity_score'].describe()
                st.dataframe(complexity_stats.to_frame('Complexity Score'), use_container_width=True)
            
            with tab3:
                # Performance metrics by complexity
                performance_by_complexity = job_data.groupby('complexity_level').agg({
                    'runtime_seconds': ['mean', 'std'],
                    'cpu_usage': 'mean',
                    'memory_usage': 'mean',
                    'success_rate': 'mean',
                    'throughput': 'mean'
                }).round(2)
                
                st.write("**Performance Metrics by Complexity Level:**")
                st.dataframe(performance_by_complexity, use_container_width=True)
            
            # Export options
            st.write("### 📁 Export Analysis Results")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("📊 Export Detailed Data"):
                    csv_data = job_data.to_csv(index=False)
                    st.download_button(
                        label="Download Analysis Data (CSV)",
                        data=csv_data,
                        file_name=f"job_complexity_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
            
            with col2:
                if st.button("📋 Export Recommendations"):
                    if recommendations:
                        rec_text = "JOB COMPLEXITY ANALYSIS RECOMMENDATIONS\n" + "="*50 + "\n\n"
                        for i, rec in enumerate(recommendations, 1):
                            rec_text += f"{i}. {rec['category']} ({rec['priority']} Priority)\n"
                            rec_text += f"   Issue: {rec['issue']}\n"
                            rec_text += f"   Recommendation: {rec['recommendation']}\n"
                            rec_text += f"   Impact: {rec['impact']}\n\n"
                    else:
                        rec_text = "No optimization recommendations generated."
                    
                    st.download_button(
                        label="Download Recommendations (TXT)",
                        data=rec_text,
                        file_name=f"optimization_recommendations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                        mime="text/plain"
                    )
            
            with col3:
                if st.button("📈 Export Summary Report"):
                    summary = self.generate_analysis_summary(job_data, complexity_drivers, recommendations)
                    st.download_button(
                        label="Download Summary Report (TXT)",
                        data=summary,
                        file_name=f"complexity_analysis_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                        mime="text/plain"
                    )
        
        else:
            st.info("👆 Click 'Run One-Click Analysis' to start the comprehensive job complexity analysis")
    
    def generate_analysis_summary(self, job_data, drivers, recommendations):
        """Generate comprehensive analysis summary"""
        summary = []
        summary.append("JOB COMPLEXITY ANALYSIS SUMMARY")
        summary.append("=" * 40)
        summary.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        summary.append(f"Total Jobs Analyzed: {len(job_data)}")
        summary.append("")
        
        summary.append("COMPLEXITY OVERVIEW")
        summary.append("-" * 20)
        complexity_dist = job_data['complexity_level'].value_counts()
        for level, count in complexity_dist.items():
            percentage = (count / len(job_data)) * 100
            summary.append(f"{level}: {count} jobs ({percentage:.1f}%)")
        summary.append("")
        
        summary.append("KEY METRICS")
        summary.append("-" * 12)
        summary.append(f"Average Complexity Score: {job_data['complexity_score'].mean():.3f}")
        summary.append(f"Average Runtime: {job_data['runtime_seconds'].mean():.1f} seconds")
        summary.append(f"Average Success Rate: {job_data['success_rate'].mean():.1%}")
        summary.append(f"High Resource Jobs: {len(job_data[(job_data['cpu_usage'] > 80) | (job_data['memory_usage'] > 80)])}")
        summary.append("")
        
        summary.append("TOP COMPLEXITY DRIVERS")
        summary.append("-" * 23)
        for driver, correlation in drivers.head(5).items():
            summary.append(f"{driver.replace('_', ' ').title()}: {correlation:.3f}")
        summary.append("")
        
        summary.append("OPTIMIZATION RECOMMENDATIONS")
        summary.append("-" * 29)
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                summary.append(f"{i}. {rec['category']} ({rec['priority']} Priority)")
                summary.append(f"   {rec['issue']}")
                summary.append("")
        else:
            summary.append("No critical optimization opportunities detected.")
        
        return "\n".join(summary)

def create_job_complexity_analyzer_dashboard():
    """Main function to create the complexity analyzer dashboard"""
    
    # Initialize the analyzer
    analyzer = JobComplexityAnalyzer()
    
    # Get job manager if available
    job_manager = st.session_state.get('batch_job_manager', None)
    
    # Create the dashboard
    analyzer.create_one_click_analysis_dashboard(job_manager)
    
    return analyzer