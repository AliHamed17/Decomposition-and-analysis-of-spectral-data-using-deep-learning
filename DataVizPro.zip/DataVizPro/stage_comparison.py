import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import stats, interpolate
from scipy.spatial.distance import euclidean, cosine
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

def calculate_stage_differences(data, reference_stage=0, comparison_stages=None):
    """
    Calculate comprehensive differences between stages
    Returns detailed comparison metrics
    """
    if comparison_stages is None:
        comparison_stages = [stage for stage in data.keys() if stage != reference_stage]
    
    if reference_stage not in data:
        return None
    
    results = {}
    reference_data = data[reference_stage]
    
    for comp_stage in comparison_stages:
        if comp_stage not in data:
            continue
            
        comp_data = data[comp_stage]
        stage_comparison = compare_two_stages(reference_data, comp_data, reference_stage, comp_stage)
        results[f"Stage_{reference_stage}_vs_{comp_stage}"] = stage_comparison
    
    return results

def compare_two_stages(stage1_data, stage2_data, stage1_num, stage2_num):
    """
    Detailed comparison between two specific stages
    """
    comparison_results = {
        'stage1': stage1_num,
        'stage2': stage2_num,
        'file_comparisons': [],
        'aggregate_metrics': {},
        'statistical_tests': {}
    }
    
    # File-by-file comparison
    for file_num in stage1_data.keys():
        if file_num in stage2_data:
            file_comparison = compare_spectrum_files(
                stage1_data[file_num], 
                stage2_data[file_num],
                f"S{stage1_num}_F{file_num}",
                f"S{stage2_num}_F{file_num}"
            )
            comparison_results['file_comparisons'].append(file_comparison)
    
    # Aggregate metrics across all files
    if comparison_results['file_comparisons']:
        comparison_results['aggregate_metrics'] = calculate_aggregate_metrics(
            comparison_results['file_comparisons']
        )
        
        # Statistical significance tests
        comparison_results['statistical_tests'] = perform_statistical_tests(
            stage1_data, stage2_data
        )
    
    return comparison_results

def compare_spectrum_files(file1_data, file2_data, label1, label2):
    """
    Compare two individual spectrum files
    """
    wavelength1 = file1_data['wavelength']
    intensity1 = file1_data['intensity']
    wavelength2 = file2_data['wavelength']
    intensity2 = file2_data['intensity']
    
    # Interpolate to common wavelength grid
    common_wavelength, interp_intensity1, interp_intensity2 = interpolate_to_common_grid(
        wavelength1, intensity1, wavelength2, intensity2
    )
    
    # Calculate various difference metrics
    comparison = {
        'label1': label1,
        'label2': label2,
        'wavelength_grid': common_wavelength,
        'intensity1': interp_intensity1,
        'intensity2': interp_intensity2,
        'absolute_difference': np.abs(interp_intensity2 - interp_intensity1),
        'relative_difference': np.abs(interp_intensity2 - interp_intensity1) / (interp_intensity1 + 1e-10),
        'percent_change': ((interp_intensity2 - interp_intensity1) / (interp_intensity1 + 1e-10)) * 100,
        'metrics': {}
    }
    
    # Calculate comprehensive metrics
    comparison['metrics'] = {
        'rmse': np.sqrt(mean_squared_error(interp_intensity1, interp_intensity2)),
        'mae': mean_absolute_error(interp_intensity1, interp_intensity2),
        'correlation': np.corrcoef(interp_intensity1, interp_intensity2)[0, 1],
        'cosine_similarity': 1 - cosine(interp_intensity1, interp_intensity2),
        'euclidean_distance': euclidean(interp_intensity1, interp_intensity2),
        'max_absolute_diff': np.max(comparison['absolute_difference']),
        'mean_absolute_diff': np.mean(comparison['absolute_difference']),
        'max_percent_change': np.max(np.abs(comparison['percent_change'])),
        'mean_percent_change': np.mean(np.abs(comparison['percent_change'])),
        'total_area_difference': np.trapz(comparison['absolute_difference'], common_wavelength),
        'spectral_angle': calculate_spectral_angle(interp_intensity1, interp_intensity2)
    }
    
    return comparison

def interpolate_to_common_grid(wavelength1, intensity1, wavelength2, intensity2, num_points=1000):
    """
    Interpolate both spectra to a common wavelength grid
    """
    # Find common wavelength range
    min_wavelength = max(np.min(wavelength1), np.min(wavelength2))
    max_wavelength = min(np.max(wavelength1), np.max(wavelength2))
    
    # Create common grid
    common_wavelength = np.linspace(min_wavelength, max_wavelength, num_points)
    
    # Interpolate both spectra
    f1 = interpolate.interp1d(wavelength1, intensity1, kind='linear', bounds_error=False, fill_value=0)
    f2 = interpolate.interp1d(wavelength2, intensity2, kind='linear', bounds_error=False, fill_value=0)
    
    interp_intensity1 = f1(common_wavelength)
    interp_intensity2 = f2(common_wavelength)
    
    return common_wavelength, interp_intensity1, interp_intensity2

def calculate_spectral_angle(spectrum1, spectrum2):
    """
    Calculate spectral angle mapper (SAM) between two spectra
    """
    dot_product = np.dot(spectrum1, spectrum2)
    norm1 = np.linalg.norm(spectrum1)
    norm2 = np.linalg.norm(spectrum2)
    
    cos_angle = dot_product / (norm1 * norm2)
    cos_angle = np.clip(cos_angle, -1, 1)  # Handle numerical errors
    angle_radians = np.arccos(cos_angle)
    
    return np.degrees(angle_radians)

def calculate_aggregate_metrics(file_comparisons):
    """
    Calculate aggregate metrics across all file comparisons
    """
    metrics_list = [comp['metrics'] for comp in file_comparisons]
    
    aggregate = {}
    for metric_name in metrics_list[0].keys():
        values = [metrics[metric_name] for metrics in metrics_list if not np.isnan(metrics[metric_name])]
        if values:
            aggregate[metric_name] = {
                'mean': np.mean(values),
                'std': np.std(values),
                'min': np.min(values),
                'max': np.max(values),
                'median': np.median(values)
            }
    
    return aggregate

def perform_statistical_tests(stage1_data, stage2_data):
    """
    Perform statistical significance tests between stages
    """
    # Collect all intensity values for each stage
    stage1_intensities = []
    stage2_intensities = []
    
    for file_data in stage1_data.values():
        stage1_intensities.extend(file_data['intensity'])
    
    for file_data in stage2_data.values():
        stage2_intensities.extend(file_data['intensity'])
    
    # Convert to numpy arrays
    stage1_intensities = np.array(stage1_intensities)
    stage2_intensities = np.array(stage2_intensities)
    
    # Perform various statistical tests
    tests = {}
    
    # t-test
    try:
        t_stat, t_pvalue = stats.ttest_ind(stage1_intensities, stage2_intensities)
        tests['t_test'] = {'statistic': t_stat, 'p_value': t_pvalue}
    except:
        tests['t_test'] = {'statistic': np.nan, 'p_value': np.nan}
    
    # Mann-Whitney U test (non-parametric)
    try:
        u_stat, u_pvalue = stats.mannwhitneyu(stage1_intensities, stage2_intensities, alternative='two-sided')
        tests['mann_whitney'] = {'statistic': u_stat, 'p_value': u_pvalue}
    except:
        tests['mann_whitney'] = {'statistic': np.nan, 'p_value': np.nan}
    
    # Kolmogorov-Smirnov test
    try:
        ks_stat, ks_pvalue = stats.ks_2samp(stage1_intensities, stage2_intensities)
        tests['kolmogorov_smirnov'] = {'statistic': ks_stat, 'p_value': ks_pvalue}
    except:
        tests['kolmogorov_smirnov'] = {'statistic': np.nan, 'p_value': np.nan}
    
    # Effect size (Cohen's d)
    try:
        pooled_std = np.sqrt(((len(stage1_intensities) - 1) * np.var(stage1_intensities) + 
                             (len(stage2_intensities) - 1) * np.var(stage2_intensities)) / 
                            (len(stage1_intensities) + len(stage2_intensities) - 2))
        cohens_d = (np.mean(stage1_intensities) - np.mean(stage2_intensities)) / pooled_std
        tests['effect_size'] = {'cohens_d': cohens_d}
    except:
        tests['effect_size'] = {'cohens_d': np.nan}
    
    return tests

def plot_stage_comparison_overview(comparison_results):
    """
    Create comprehensive comparison visualization
    """
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=[
            'RMSE Comparison',
            'Correlation Comparison', 
            'Maximum Difference',
            'Spectral Angle',
            'Total Area Difference',
            'Effect Sizes'
        ],
        specs=[[{"type": "bar"}, {"type": "bar"}],
               [{"type": "bar"}, {"type": "bar"}],
               [{"type": "bar"}, {"type": "bar"}]]
    )
    
    comparison_names = list(comparison_results.keys())
    
    # Extract metrics for plotting
    rmse_values = []
    correlation_values = []
    max_diff_values = []
    spectral_angle_values = []
    area_diff_values = []
    effect_sizes = []
    
    for comp_name, comp_data in comparison_results.items():
        if 'aggregate_metrics' in comp_data and comp_data['aggregate_metrics']:
            agg = comp_data['aggregate_metrics']
            rmse_values.append(agg.get('rmse', {}).get('mean', 0))
            correlation_values.append(agg.get('correlation', {}).get('mean', 0))
            max_diff_values.append(agg.get('max_absolute_diff', {}).get('mean', 0))
            spectral_angle_values.append(agg.get('spectral_angle', {}).get('mean', 0))
            area_diff_values.append(agg.get('total_area_difference', {}).get('mean', 0))
            
            # Effect size from statistical tests
            effect_size = comp_data.get('statistical_tests', {}).get('effect_size', {}).get('cohens_d', 0)
            effect_sizes.append(abs(effect_size) if not np.isnan(effect_size) else 0)
    
    # Create bar plots
    fig.add_trace(go.Bar(x=comparison_names, y=rmse_values, name='RMSE', showlegend=False), row=1, col=1)
    fig.add_trace(go.Bar(x=comparison_names, y=correlation_values, name='Correlation', showlegend=False), row=1, col=2)
    fig.add_trace(go.Bar(x=comparison_names, y=max_diff_values, name='Max Diff', showlegend=False), row=2, col=1)
    fig.add_trace(go.Bar(x=comparison_names, y=spectral_angle_values, name='Spectral Angle', showlegend=False), row=2, col=2)
    fig.add_trace(go.Bar(x=comparison_names, y=area_diff_values, name='Area Diff', showlegend=False), row=3, col=1)
    fig.add_trace(go.Bar(x=comparison_names, y=effect_sizes, name='Effect Size', showlegend=False), row=3, col=2)
    
    fig.update_layout(
        title='Stage Comparison Overview - Key Metrics',
        height=800,
        showlegend=False
    )
    
    return fig

def plot_difference_spectra(comparison_results, comparison_name):
    """
    Plot difference spectra for a specific comparison
    """
    if comparison_name not in comparison_results:
        return None
    
    comp_data = comparison_results[comparison_name]
    file_comparisons = comp_data['file_comparisons']
    
    if not file_comparisons:
        return None
    
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            'Original Spectra Overlay',
            'Absolute Difference',
            'Relative Difference (%)',
            'Difference Distribution'
        ]
    )
    
    colors = px.colors.qualitative.Set1
    
    # Plot first few file comparisons
    for i, file_comp in enumerate(file_comparisons[:5]):  # Limit to 5 files for clarity
        wavelength = file_comp['wavelength_grid']
        intensity1 = file_comp['intensity1']
        intensity2 = file_comp['intensity2']
        abs_diff = file_comp['absolute_difference']
        percent_change = file_comp['percent_change']
        
        color = colors[i % len(colors)]
        
        # Original spectra overlay
        fig.add_trace(go.Scatter(
            x=wavelength, y=intensity1,
            mode='lines', name=f'{file_comp["label1"]}',
            line=dict(color=color, dash='solid'),
            showlegend=i < 3
        ), row=1, col=1)
        
        fig.add_trace(go.Scatter(
            x=wavelength, y=intensity2,
            mode='lines', name=f'{file_comp["label2"]}',
            line=dict(color=color, dash='dash'),
            showlegend=i < 3
        ), row=1, col=1)
        
        # Absolute difference
        fig.add_trace(go.Scatter(
            x=wavelength, y=abs_diff,
            mode='lines', name=f'File {i+1}',
            line=dict(color=color),
            showlegend=False
        ), row=1, col=2)
        
        # Relative difference
        fig.add_trace(go.Scatter(
            x=wavelength, y=percent_change,
            mode='lines', name=f'File {i+1}',
            line=dict(color=color),
            showlegend=False
        ), row=2, col=1)
        
        # Difference distribution
        fig.add_trace(go.Histogram(
            x=abs_diff, name=f'File {i+1}',
            opacity=0.7, showlegend=False
        ), row=2, col=2)
    
    fig.update_layout(
        title=f'Detailed Difference Analysis: {comparison_name}',
        height=800
    )
    
    return fig

def plot_statistical_significance_matrix(comparison_results):
    """
    Create a matrix showing statistical significance between stages
    """
    # Extract p-values from all comparisons
    stage_names = set()
    p_values = {}
    
    for comp_name, comp_data in comparison_results.items():
        parts = comp_name.split('_vs_')
        if len(parts) == 2:
            stage1 = parts[0]
            stage2 = parts[1]
            stage_names.add(stage1)
            stage_names.add(stage2)
            
            # Get p-value from t-test
            p_val = comp_data.get('statistical_tests', {}).get('t_test', {}).get('p_value', 1.0)
            p_values[(stage1, stage2)] = p_val
            p_values[(stage2, stage1)] = p_val  # Symmetric
    
    stage_names = sorted(list(stage_names))
    n_stages = len(stage_names)
    
    # Create matrix
    significance_matrix = np.ones((n_stages, n_stages))
    
    for i, stage1 in enumerate(stage_names):
        for j, stage2 in enumerate(stage_names):
            if i != j and (stage1, stage2) in p_values:
                significance_matrix[i, j] = p_values[(stage1, stage2)]
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=significance_matrix,
        x=stage_names,
        y=stage_names,
        colorscale='RdYlBu_r',
        colorbar=dict(title="p-value"),
        text=[[f'{val:.3f}' for val in row] for row in significance_matrix],
        texttemplate="%{text}",
        textfont={"size": 10}
    ))
    
    fig.update_layout(
        title='Statistical Significance Matrix (p-values from t-test)',
        xaxis_title='Stage',
        yaxis_title='Stage'
    )
    
    return fig

def create_comparison_summary_table(comparison_results):
    """
    Create a comprehensive summary table of all comparisons
    """
    summary_data = []
    
    for comp_name, comp_data in comparison_results.items():
        if 'aggregate_metrics' not in comp_data or not comp_data['aggregate_metrics']:
            continue
            
        agg = comp_data['aggregate_metrics']
        stats_tests = comp_data.get('statistical_tests', {})
        
        summary_row = {
            'Comparison': comp_name,
            'RMSE (mean)': agg.get('rmse', {}).get('mean', np.nan),
            'Correlation (mean)': agg.get('correlation', {}).get('mean', np.nan),
            'Max Diff (mean)': agg.get('max_absolute_diff', {}).get('mean', np.nan),
            'Mean % Change': agg.get('mean_percent_change', {}).get('mean', np.nan),
            'Spectral Angle (deg)': agg.get('spectral_angle', {}).get('mean', np.nan),
            'Effect Size (Cohen\'s d)': abs(stats_tests.get('effect_size', {}).get('cohens_d', np.nan)),
            't-test p-value': stats_tests.get('t_test', {}).get('p_value', np.nan),
            'Significant (p<0.05)': 'Yes' if stats_tests.get('t_test', {}).get('p_value', 1) < 0.05 else 'No'
        }
        
        summary_data.append(summary_row)
    
    return pd.DataFrame(summary_data)

def identify_most_changed_wavelengths(comparison_results, top_n=10):
    """
    Identify wavelengths with the most significant changes across comparisons
    """
    wavelength_changes = {}
    
    for comp_name, comp_data in comparison_results.items():
        file_comparisons = comp_data.get('file_comparisons', [])
        
        for file_comp in file_comparisons:
            wavelength = file_comp['wavelength_grid']
            abs_diff = file_comp['absolute_difference']
            
            for wav, diff in zip(wavelength, abs_diff):
                wav_rounded = round(wav, 1)  # Round to 1 decimal place
                if wav_rounded not in wavelength_changes:
                    wavelength_changes[wav_rounded] = []
                wavelength_changes[wav_rounded].append(diff)
    
    # Calculate average change for each wavelength
    avg_changes = {}
    for wav, changes in wavelength_changes.items():
        avg_changes[wav] = np.mean(changes)
    
    # Sort by average change
    sorted_wavelengths = sorted(avg_changes.items(), key=lambda x: x[1], reverse=True)
    
    return sorted_wavelengths[:top_n]