import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import threading
import queue
import json
import uuid
from enum import Enum
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

class JobStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class JobPriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4

class BatchJob:
    def __init__(self, job_id: str, name: str, job_type: str, parameters: Dict, priority: JobPriority = JobPriority.NORMAL):
        self.job_id = job_id
        self.name = name
        self.job_type = job_type
        self.parameters = parameters
        self.priority = priority
        self.status = JobStatus.PENDING
        self.created_at = datetime.now()
        self.started_at = None
        self.completed_at = None
        self.progress = 0.0
        self.current_step = ""
        self.total_steps = 0
        self.completed_steps = 0
        self.error_message = ""
        self.results = {}
        self.estimated_duration = None
        self.actual_duration = None
        self.resource_usage = {
            'cpu_usage': 0.0,
            'memory_usage': 0.0,
            'files_processed': 0,
            'total_files': 0
        }
        self.log_messages = []
    
    def update_progress(self, progress: float, current_step: str = ""):
        self.progress = min(100.0, max(0.0, progress))
        if current_step:
            self.current_step = current_step
        self.log_messages.append({
            'timestamp': datetime.now(),
            'message': f"Progress: {self.progress:.1f}% - {current_step}",
            'level': 'info'
        })
    
    def update_status(self, status: JobStatus, message: str = ""):
        self.status = status
        if status == JobStatus.RUNNING and not self.started_at:
            self.started_at = datetime.now()
        elif status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            self.completed_at = datetime.now()
            if self.started_at:
                self.actual_duration = (self.completed_at - self.started_at).total_seconds()
        
        self.log_messages.append({
            'timestamp': datetime.now(),
            'message': f"Status changed to {status.value}: {message}",
            'level': 'info' if status != JobStatus.FAILED else 'error'
        })
    
    def add_log(self, message: str, level: str = 'info'):
        self.log_messages.append({
            'timestamp': datetime.now(),
            'message': message,
            'level': level
        })
    
    def get_runtime(self):
        if self.started_at:
            end_time = self.completed_at or datetime.now()
            return (end_time - self.started_at).total_seconds()
        return 0
    
    def to_dict(self):
        return {
            'job_id': self.job_id,
            'name': self.name,
            'job_type': self.job_type,
            'status': self.status.value,
            'priority': self.priority.value,
            'progress': self.progress,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'runtime': self.get_runtime(),
            'current_step': self.current_step,
            'error_message': self.error_message
        }

class BatchJobManager:
    def __init__(self):
        self.jobs = {}
        self.job_queue = queue.PriorityQueue()
        self.active_jobs = {}
        self.max_concurrent_jobs = 2
        self.job_history = []
        self.worker_threads = []
        self.is_running = False
    
    def create_job(self, name: str, job_type: str, parameters: Dict, priority: JobPriority = JobPriority.NORMAL) -> str:
        """Create a new batch job"""
        job_id = str(uuid.uuid4())
        job = BatchJob(job_id, name, job_type, parameters, priority)
        self.jobs[job_id] = job
        
        # Add to priority queue (negative priority for correct ordering)
        self.job_queue.put((-priority.value, time.time(), job_id))
        
        job.add_log(f"Job created: {name} ({job_type})")
        return job_id
    
    def get_job(self, job_id: str) -> Optional[BatchJob]:
        """Get job by ID"""
        return self.jobs.get(job_id)
    
    def get_all_jobs(self) -> List[BatchJob]:
        """Get all jobs sorted by creation time"""
        return sorted(self.jobs.values(), key=lambda x: x.created_at, reverse=True)
    
    def get_jobs_by_status(self, status: JobStatus) -> List[BatchJob]:
        """Get jobs filtered by status"""
        return [job for job in self.jobs.values() if job.status == status]
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a job"""
        job = self.get_job(job_id)
        if job and job.status in [JobStatus.PENDING, JobStatus.RUNNING, JobStatus.PAUSED]:
            job.update_status(JobStatus.CANCELLED, "Job cancelled by user")
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            return True
        return False
    
    def pause_job(self, job_id: str) -> bool:
        """Pause a running job"""
        job = self.get_job(job_id)
        if job and job.status == JobStatus.RUNNING:
            job.update_status(JobStatus.PAUSED, "Job paused by user")
            return True
        return False
    
    def resume_job(self, job_id: str) -> bool:
        """Resume a paused job"""
        job = self.get_job(job_id)
        if job and job.status == JobStatus.PAUSED:
            job.update_status(JobStatus.PENDING, "Job resumed by user")
            self.job_queue.put((-job.priority.value, time.time(), job_id))
            return True
        return False
    
    def delete_job(self, job_id: str) -> bool:
        """Delete a completed or failed job"""
        job = self.get_job(job_id)
        if job and job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            self.job_history.append(job.to_dict())
            del self.jobs[job_id]
            return True
        return False
    
    def get_job_statistics(self) -> Dict:
        """Get overall job statistics"""
        total_jobs = len(self.jobs)
        pending_jobs = len(self.get_jobs_by_status(JobStatus.PENDING))
        running_jobs = len(self.get_jobs_by_status(JobStatus.RUNNING))
        completed_jobs = len(self.get_jobs_by_status(JobStatus.COMPLETED))
        failed_jobs = len(self.get_jobs_by_status(JobStatus.FAILED))
        
        avg_runtime = 0
        if completed_jobs > 0:
            completed_job_list = self.get_jobs_by_status(JobStatus.COMPLETED)
            avg_runtime = sum(job.get_runtime() for job in completed_job_list) / len(completed_job_list)
        
        return {
            'total_jobs': total_jobs,
            'pending_jobs': pending_jobs,
            'running_jobs': running_jobs,
            'completed_jobs': completed_jobs,
            'failed_jobs': failed_jobs,
            'success_rate': (completed_jobs / max(1, total_jobs)) * 100,
            'average_runtime': avg_runtime,
            'active_workers': len(self.active_jobs)
        }
    
    def simulate_job_execution(self, job_id: str):
        """Simulate job execution (for demo purposes)"""
        job = self.get_job(job_id)
        if not job:
            return
        
        job.update_status(JobStatus.RUNNING, "Job execution started")
        
        # Simulate job steps based on job type
        if job.job_type == "peak_analysis":
            steps = ["Initializing", "Loading Data", "Detecting Peaks", "Analyzing Properties", "Generating Report"]
        elif job.job_type == "statistical_analysis":
            steps = ["Initializing", "Loading Data", "Calculating Statistics", "Processing Results", "Exporting Data"]
        elif job.job_type == "anomaly_detection":
            steps = ["Initializing", "Loading Data", "Training Models", "Detecting Anomalies", "Generating Report"]
        else:
            steps = ["Initializing", "Processing", "Finalizing"]
        
        job.total_steps = len(steps)
        
        try:
            for i, step in enumerate(steps):
                if job.status == JobStatus.CANCELLED:
                    return
                
                job.update_progress((i / len(steps)) * 100, step)
                job.completed_steps = i + 1
                
                # Simulate processing time
                time.sleep(np.random.uniform(0.5, 2.0))
                
                # Simulate resource usage
                job.resource_usage['cpu_usage'] = np.random.uniform(20, 80)
                job.resource_usage['memory_usage'] = np.random.uniform(30, 70)
                
                if job.job_type in ["peak_analysis", "statistical_analysis"]:
                    job.resource_usage['files_processed'] = min(job.parameters.get('total_files', 100), 
                                                              int((i + 1) / len(steps) * job.parameters.get('total_files', 100)))
                    job.resource_usage['total_files'] = job.parameters.get('total_files', 100)
            
            # Simulate potential failure
            if np.random.random() < 0.1:  # 10% chance of failure
                job.update_status(JobStatus.FAILED, "Simulated processing error")
                job.error_message = "Random simulation error occurred"
            else:
                job.update_progress(100.0, "Completed successfully")
                job.update_status(JobStatus.COMPLETED, "Job completed successfully")
                job.results = {
                    'processed_files': job.resource_usage.get('total_files', 0),
                    'success_rate': np.random.uniform(85, 98),
                    'processing_time': job.get_runtime()
                }
        
        except Exception as e:
            job.update_status(JobStatus.FAILED, f"Error: {str(e)}")
            job.error_message = str(e)

def create_batch_job_dashboard():
    """Create the main batch job management dashboard"""
    
    # Initialize job manager in session state
    if 'batch_job_manager' not in st.session_state:
        st.session_state.batch_job_manager = BatchJobManager()
    
    job_manager = st.session_state.batch_job_manager
    
    st.markdown("""
    <div class="analysis-section">
        <h2>🎛️ Batch Job Management Dashboard</h2>
        <p>Comprehensive control center for managing batch processing operations</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Job Statistics Overview
    st.write("### 📊 Job Statistics Overview")
    
    stats = job_manager.get_job_statistics()
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("Total Jobs", stats['total_jobs'])
    
    with col2:
        st.metric("Running", stats['running_jobs'], 
                 delta=f"/{job_manager.max_concurrent_jobs} slots")
    
    with col3:
        st.metric("Pending", stats['pending_jobs'])
    
    with col4:
        st.metric("Completed", stats['completed_jobs'])
    
    with col5:
        st.metric("Success Rate", f"{stats['success_rate']:.1f}%")
    
    # Job Creation Section
    st.markdown("---")
    st.write("### ➕ Create New Batch Job")
    
    with st.expander("Create New Job", expanded=False):
        col1, col2 = st.columns(2)
        
        with col1:
            job_name = st.text_input("Job Name", placeholder="Enter descriptive job name")
            job_type = st.selectbox("Job Type", [
                "peak_analysis",
                "statistical_analysis", 
                "anomaly_detection",
                "data_preprocessing",
                "model_training"
            ])
            priority = st.selectbox("Priority", [
                ("Low", JobPriority.LOW),
                ("Normal", JobPriority.NORMAL), 
                ("High", JobPriority.HIGH),
                ("Urgent", JobPriority.URGENT)
            ], index=1)
        
        with col2:
            # Job-specific parameters
            st.write("**Job Parameters:**")
            
            if job_type == "peak_analysis":
                prominence = st.slider("Peak Prominence", 0.01, 1.0, 0.1, key="job_prominence")
                width = st.slider("Peak Width", 1, 20, 5, key="job_width")
                total_files = st.number_input("Total Files to Process", 1, 1000, 100, key="job_total_files_peak")
                parameters = {
                    'prominence': prominence,
                    'width': width,
                    'total_files': total_files
                }
            elif job_type == "statistical_analysis":
                analysis_type = st.selectbox("Analysis Type", ["basic", "advanced", "comprehensive"], key="job_analysis_type")
                total_files = st.number_input("Total Files to Process", 1, 1000, 100, key="job_total_files_stats")
                parameters = {
                    'analysis_type': analysis_type,
                    'total_files': total_files
                }
            elif job_type == "anomaly_detection":
                contamination = st.slider("Contamination Level", 0.01, 0.5, 0.1, key="job_contamination")
                algorithm = st.selectbox("Algorithm", ["isolation_forest", "one_class_svm", "dbscan"], key="job_algorithm")
                total_files = st.number_input("Total Files to Process", 1, 1000, 100, key="job_total_files_anomaly")
                parameters = {
                    'contamination': contamination,
                    'algorithm': algorithm,
                    'total_files': total_files
                }
            else:
                parameters = {'total_files': st.number_input("Total Files to Process", 1, 1000, 100, key="job_total_files_other")}
        
        if st.button("🚀 Create and Queue Job", type="primary"):
            if job_name.strip():
                job_id = job_manager.create_job(
                    name=job_name,
                    job_type=job_type,
                    parameters=parameters,
                    priority=priority[1]
                )
                st.success(f"Job '{job_name}' created successfully! Job ID: {job_id[:8]}...")
                
                # Start job execution in background
                def run_job():
                    job_manager.simulate_job_execution(job_id)
                
                thread = threading.Thread(target=run_job)
                thread.daemon = True
                thread.start()
                
                st.rerun()
            else:
                st.error("Please enter a job name")
    
    # Active Jobs Monitoring
    st.markdown("---")
    st.write("### 🔄 Active Jobs Monitor")
    
    running_jobs = job_manager.get_jobs_by_status(JobStatus.RUNNING)
    
    if running_jobs:
        for job in running_jobs:
            with st.container():
                col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
                
                with col1:
                    st.write(f"**{job.name}** ({job.job_type})")
                    st.progress(job.progress / 100.0, f"Progress: {job.progress:.1f}%")
                    if job.current_step:
                        st.caption(f"Current step: {job.current_step}")
                
                with col2:
                    runtime = job.get_runtime()
                    st.metric("Runtime", f"{runtime:.1f}s")
                    if job.resource_usage['total_files'] > 0:
                        st.metric("Files Processed", 
                                f"{job.resource_usage['files_processed']}/{job.resource_usage['total_files']}")
                
                with col3:
                    st.metric("CPU Usage", f"{job.resource_usage['cpu_usage']:.1f}%")
                    st.metric("Memory Usage", f"{job.resource_usage['memory_usage']:.1f}%")
                
                with col4:
                    if st.button("⏸️", key=f"pause_{job.job_id}", help="Pause Job"):
                        job_manager.pause_job(job.job_id)
                        st.rerun()
                    if st.button("❌", key=f"cancel_{job.job_id}", help="Cancel Job"):
                        job_manager.cancel_job(job.job_id)
                        st.rerun()
                
                st.markdown("---")
    else:
        st.info("No jobs currently running")
    
    # Job Queue and History
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("### ⏳ Job Queue")
        pending_jobs = job_manager.get_jobs_by_status(JobStatus.PENDING)
        
        if pending_jobs:
            queue_data = []
            for job in sorted(pending_jobs, key=lambda x: (-x.priority.value, x.created_at)):
                queue_data.append({
                    'Name': job.name,
                    'Type': job.job_type,
                    'Priority': job.priority.name,
                    'Created': job.created_at.strftime("%H:%M:%S"),
                    'Job ID': job.job_id[:8] + "..."
                })
            
            st.dataframe(pd.DataFrame(queue_data), use_container_width=True, hide_index=True)
        else:
            st.info("Job queue is empty")
    
    with col2:
        st.write("### 📜 Recent Job History")
        completed_jobs = job_manager.get_jobs_by_status(JobStatus.COMPLETED) + \
                        job_manager.get_jobs_by_status(JobStatus.FAILED)
        
        if completed_jobs:
            history_data = []
            for job in sorted(completed_jobs, key=lambda x: x.completed_at or datetime.now(), reverse=True)[:10]:
                status_emoji = "✅" if job.status == JobStatus.COMPLETED else "❌"
                history_data.append({
                    'Status': status_emoji,
                    'Name': job.name,
                    'Type': job.job_type,
                    'Runtime': f"{job.get_runtime():.1f}s",
                    'Completed': job.completed_at.strftime("%H:%M:%S") if job.completed_at else "N/A"
                })
            
            st.dataframe(pd.DataFrame(history_data), use_container_width=True, hide_index=True)
        else:
            st.info("No completed jobs yet")
    
    # Detailed Job Management
    st.markdown("---")
    st.write("### 🔍 Detailed Job Management")
    
    all_jobs = job_manager.get_all_jobs()
    
    if all_jobs:
        # Job filter options
        col1, col2, col3 = st.columns(3)
        
        with col1:
            status_filter = st.multiselect(
                "Filter by Status",
                options=[status.value for status in JobStatus],
                default=[status.value for status in JobStatus]
            )
        
        with col2:
            type_filter = st.multiselect(
                "Filter by Type",
                options=list(set(job.job_type for job in all_jobs)),
                default=list(set(job.job_type for job in all_jobs))
            )
        
        with col3:
            priority_filter = st.multiselect(
                "Filter by Priority",
                options=[priority.name for priority in JobPriority],
                default=[priority.name for priority in JobPriority]
            )
        
        # Filter jobs
        filtered_jobs = [
            job for job in all_jobs
            if job.status.value in status_filter
            and job.job_type in type_filter
            and job.priority.name in priority_filter
        ]
        
        # Display filtered jobs
        if filtered_jobs:
            job_data = []
            for job in filtered_jobs:
                status_emoji = {
                    JobStatus.PENDING: "⏳",
                    JobStatus.RUNNING: "🔄", 
                    JobStatus.COMPLETED: "✅",
                    JobStatus.FAILED: "❌",
                    JobStatus.CANCELLED: "🚫",
                    JobStatus.PAUSED: "⏸️"
                }[job.status]
                
                job_data.append({
                    'Status': status_emoji,
                    'Name': job.name,
                    'Type': job.job_type,
                    'Priority': job.priority.name,
                    'Progress': f"{job.progress:.1f}%",
                    'Runtime': f"{job.get_runtime():.1f}s",
                    'Created': job.created_at.strftime("%m/%d %H:%M"),
                    'Job ID': job.job_id
                })
            
            df = pd.DataFrame(job_data)
            
            # Display as interactive table
            st.dataframe(
                df.drop('Job ID', axis=1),
                use_container_width=True,
                hide_index=True
            )
            
            # Job selection for details
            if not df.empty:
                job_options = [f"{row['Name']} ({row['Job ID'][:8]}...)" for _, row in df.iterrows()]
                selected_job_option = st.selectbox(
                    "Select job for detailed view:",
                    options=job_options,
                    key="job_detail_selector"
                )
                
                if selected_job_option:
                    # Extract job ID from the selected option
                    selected_idx = job_options.index(selected_job_option)
                    selected_job_id = df.iloc[selected_idx]['Job ID']
                selected_job = job_manager.get_job(selected_job_id)
                
                if selected_job:
                    st.write(f"### Job Details: {selected_job.name}")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.write("**Basic Information:**")
                        st.write(f"- **ID:** {selected_job.job_id}")
                        st.write(f"- **Type:** {selected_job.job_type}")
                        st.write(f"- **Status:** {selected_job.status.value}")
                        st.write(f"- **Priority:** {selected_job.priority.name}")
                        st.write(f"- **Progress:** {selected_job.progress:.1f}%")
                    
                    with col2:
                        st.write("**Timing:**")
                        st.write(f"- **Created:** {selected_job.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
                        if selected_job.started_at:
                            st.write(f"- **Started:** {selected_job.started_at.strftime('%Y-%m-%d %H:%M:%S')}")
                        if selected_job.completed_at:
                            st.write(f"- **Completed:** {selected_job.completed_at.strftime('%Y-%m-%d %H:%M:%S')}")
                        st.write(f"- **Runtime:** {selected_job.get_runtime():.1f} seconds")
                    
                    with col3:
                        st.write("**Parameters:**")
                        for key, value in selected_job.parameters.items():
                            st.write(f"- **{key}:** {value}")
                    
                    # Job actions
                    st.write("**Actions:**")
                    action_col1, action_col2, action_col3, action_col4 = st.columns(4)
                    
                    with action_col1:
                        if selected_job.status == JobStatus.RUNNING and st.button("⏸️ Pause", key="pause_selected"):
                            job_manager.pause_job(selected_job_id)
                            st.rerun()
                    
                    with action_col2:
                        if selected_job.status == JobStatus.PAUSED and st.button("▶️ Resume", key="resume_selected"):
                            job_manager.resume_job(selected_job_id)
                            st.rerun()
                    
                    with action_col3:
                        if selected_job.status in [JobStatus.PENDING, JobStatus.RUNNING, JobStatus.PAUSED] and \
                           st.button("❌ Cancel", key="cancel_selected"):
                            job_manager.cancel_job(selected_job_id)
                            st.rerun()
                    
                    with action_col4:
                        if selected_job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED] and \
                           st.button("🗑️ Delete", key="delete_selected"):
                            job_manager.delete_job(selected_job_id)
                            st.rerun()
                    
                    # Job logs
                    if selected_job.log_messages:
                        st.write("**Job Logs:**")
                        log_container = st.container()
                        with log_container:
                            for log in selected_job.log_messages[-10:]:  # Show last 10 logs
                                timestamp = log['timestamp'].strftime("%H:%M:%S")
                                level_emoji = {"info": "ℹ️", "error": "❌", "warning": "⚠️"}.get(log['level'], "ℹ️")
                                st.caption(f"{timestamp} {level_emoji} {log['message']}")
        else:
            st.info("No jobs match the current filters")
    else:
        st.info("No jobs created yet. Create your first batch job above!")
    
    # Performance Analytics
    st.markdown("---")
    st.write("### 📈 Performance Analytics")
    
    if len(all_jobs) > 0:
        # Create performance charts
        col1, col2 = st.columns(2)
        
        with col1:
            # Job status distribution
            status_counts = {}
            for status in JobStatus:
                status_counts[status.value] = len(job_manager.get_jobs_by_status(status))
            
            fig_status = px.pie(
                values=list(status_counts.values()),
                names=list(status_counts.keys()),
                title="Job Status Distribution"
            )
            st.plotly_chart(fig_status, use_container_width=True)
        
        with col2:
            # Job type distribution
            type_counts = {}
            for job in all_jobs:
                type_counts[job.job_type] = type_counts.get(job.job_type, 0) + 1
            
            fig_types = px.bar(
                x=list(type_counts.keys()),
                y=list(type_counts.values()),
                title="Jobs by Type"
            )
            st.plotly_chart(fig_types, use_container_width=True)
        
        # Runtime analysis for completed jobs
        completed_jobs = job_manager.get_jobs_by_status(JobStatus.COMPLETED)
        if completed_jobs:
            st.write("#### Runtime Analysis")
            
            runtime_data = []
            for job in completed_jobs:
                runtime_data.append({
                    'Job Name': job.name,
                    'Job Type': job.job_type,
                    'Runtime (seconds)': job.get_runtime(),
                    'Completed': job.completed_at
                })
            
            if runtime_data:
                df_runtime = pd.DataFrame(runtime_data)
                
                fig_runtime = px.scatter(
                    df_runtime,
                    x='Completed',
                    y='Runtime (seconds)',
                    color='Job Type',
                    hover_data=['Job Name'],
                    title="Job Runtime Over Time"
                )
                st.plotly_chart(fig_runtime, use_container_width=True)
    else:
        st.info("Create and run some jobs to see performance analytics")

    return job_manager