import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, accuracy_score
from sklearn.neural_network import MLPClassifier
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# TensorFlow removed due to compatibility issues - using scikit-learn only
TENSORFLOW_AVAILABLE = False

def prepare_binary_classification_data(organized_data, stage_0=0, stage_4=4):
    """
    Prepare data for binary classification between stage 0 and stage 4
    Returns features (X) and labels (y)
    """
    X = []
    y = []
    file_info = []
    
    # Extract data for stage 0 and stage 4
    for stage in [stage_0, stage_4]:
        if stage in organized_data:
            stage_data = organized_data[stage]
            for file_num, file_data in stage_data.items():
                wavelength = file_data['wavelength']
                intensity = file_data['intensity']
                
                # Use intensity as features
                X.append(intensity)
                y.append(stage)
                file_info.append({
                    'stage': stage,
                    'file_number': file_num,
                    'stage_file': f"Stage_{stage}_File_{file_num}"
                })
    
    X = np.array(X)
    y = np.array(y)
    
    # Handle missing values
    X = np.nan_to_num(X, nan=0.0)
    
    # Convert labels to binary (0 for stage_0, 1 for stage_4)
    y_binary = (y == stage_4).astype(int)
    
    return X, y_binary, file_info

def create_sklearn_neural_network(input_dim, hidden_layers=(100, 50), random_state=42):
    """
    Create a neural network using scikit-learn MLPClassifier
    """
    model = MLPClassifier(
        hidden_layer_sizes=hidden_layers,
        activation='relu',
        solver='adam',
        alpha=0.001,
        learning_rate='adaptive',
        max_iter=1000,
        random_state=random_state,
        early_stopping=True,
        validation_fraction=0.1,
        n_iter_no_change=20
    )
    return model

def create_tensorflow_neural_network(input_dim, hidden_layers=(128, 64, 32)):
    """
    Create a neural network using TensorFlow/Keras
    """
    if not TENSORFLOW_AVAILABLE:
        raise ImportError("TensorFlow is not available. Please use Scikit-learn MLP instead.")
    
    model = keras.Sequential()
    
    # Input layer
    model.add(layers.Dense(hidden_layers[0], activation='relu', input_shape=(input_dim,)))
    model.add(layers.Dropout(0.3))
    
    # Hidden layers
    for units in hidden_layers[1:]:
        model.add(layers.Dense(units, activation='relu'))
        model.add(layers.Dropout(0.2))
    
    # Output layer for binary classification
    model.add(layers.Dense(1, activation='sigmoid'))
    
    # Compile the model
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy', 'precision', 'recall']
    )
    
    return model

def train_sklearn_model(X, y, test_size=0.2, random_state=42):
    """
    Train the scikit-learn neural network model
    """
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    # Standardize the features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Create and train the model
    model = create_sklearn_neural_network(X.shape[1])
    model.fit(X_train_scaled, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test_scaled)
    y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    
    return {
        'model': model,
        'scaler': scaler,
        'X_train': X_train_scaled,
        'X_test': X_test_scaled,
        'y_train': y_train,
        'y_test': y_test,
        'y_pred': y_pred,
        'y_pred_proba': y_pred_proba,
        'accuracy': accuracy
    }

def train_tensorflow_model(X, y, test_size=0.2, epochs=100, batch_size=32, random_state=42):
    """
    Train the TensorFlow neural network model
    """
    if not TENSORFLOW_AVAILABLE:
        raise ImportError("TensorFlow is not available. Please use Scikit-learn MLP instead.")
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    # Standardize the features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Create the model
    model = create_tensorflow_neural_network(X.shape[1])
    
    # Define callbacks
    early_stopping = keras.callbacks.EarlyStopping(
        monitor='val_loss',
        patience=15,
        restore_best_weights=True
    )
    
    reduce_lr = keras.callbacks.ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.2,
        patience=8,
        min_lr=0.0001
    )
    
    # Train the model
    history = model.fit(
        X_train_scaled, y_train,
        validation_split=0.2,
        epochs=epochs,
        batch_size=batch_size,
        callbacks=[early_stopping, reduce_lr],
        verbose=0
    )
    
    # Make predictions
    y_pred_proba = model.predict(X_test_scaled).flatten()
    y_pred = (y_pred_proba > 0.5).astype(int)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    
    return {
        'model': model,
        'scaler': scaler,
        'history': history,
        'X_train': X_train_scaled,
        'X_test': X_test_scaled,
        'y_train': y_train,
        'y_test': y_test,
        'y_pred': y_pred,
        'y_pred_proba': y_pred_proba,
        'accuracy': accuracy
    }

def evaluate_model_performance(results, stage_0=0, stage_4=4):
    """
    Evaluate model performance and generate metrics
    """
    y_test = results['y_test']
    y_pred = results['y_pred']
    y_pred_proba = results['y_pred_proba']
    
    # Classification report
    class_names = [f'Stage {stage_0}', f'Stage {stage_4}']
    report = classification_report(y_test, y_pred, target_names=class_names, output_dict=True)
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    
    # ROC curve
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    roc_auc = auc(fpr, tpr)
    
    return {
        'classification_report': report,
        'confusion_matrix': cm,
        'roc_curve': (fpr, tpr),
        'roc_auc': roc_auc,
        'accuracy': results['accuracy']
    }

def plot_model_performance(results, evaluation, model_name="Neural Network", stage_0=0, stage_4=4):
    """
    Create comprehensive visualization of model performance
    """
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            'Confusion Matrix',
            'ROC Curve',
            'Training History (if available)',
            'Prediction Distribution'
        ],
        specs=[[{"type": "heatmap"}, {"type": "scatter"}],
               [{"type": "scatter"}, {"type": "histogram"}]]
    )
    
    # Confusion Matrix
    cm = evaluation['confusion_matrix']
    class_names = [f'Stage {stage_0}', f'Stage {stage_4}']
    
    fig.add_trace(
        go.Heatmap(
            z=cm,
            x=class_names,
            y=class_names,
            colorscale='Blues',
            text=cm,
            texttemplate='%{text}',
            textfont={"size": 16},
            showscale=False
        ),
        row=1, col=1
    )
    
    # ROC Curve
    fpr, tpr = evaluation['roc_curve']
    roc_auc = evaluation['roc_auc']
    
    fig.add_trace(
        go.Scatter(
            x=fpr,
            y=tpr,
            mode='lines',
            name=f'ROC Curve (AUC = {roc_auc:.3f})',
            line=dict(color='blue', width=2)
        ),
        row=1, col=2
    )
    
    # Add diagonal line for ROC
    fig.add_trace(
        go.Scatter(
            x=[0, 1],
            y=[0, 1],
            mode='lines',
            name='Random Classifier',
            line=dict(color='red', dash='dash')
        ),
        row=1, col=2
    )
    
    # Training History (for TensorFlow models)
    if 'history' in results:
        history = results['history'].history
        epochs = range(1, len(history['accuracy']) + 1)
        
        fig.add_trace(
            go.Scatter(
                x=list(epochs),
                y=history['accuracy'],
                mode='lines',
                name='Training Accuracy',
                line=dict(color='blue')
            ),
            row=2, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=list(epochs),
                y=history['val_accuracy'],
                mode='lines',
                name='Validation Accuracy',
                line=dict(color='red')
            ),
            row=2, col=1
        )
    else:
        # For sklearn models, show feature importance or other metrics
        fig.add_annotation(
            text="Training history not available<br>for scikit-learn models",
            x=0.5, y=0.5,
            xref="x3", yref="y3",
            showarrow=False,
            font=dict(size=14)
        )
    
    # Prediction Distribution
    y_pred_proba = results['y_pred_proba']
    y_test = results['y_test']
    
    # Separate predictions by true class
    stage_0_probs = y_pred_proba[y_test == 0]
    stage_4_probs = y_pred_proba[y_test == 1]
    
    fig.add_trace(
        go.Histogram(
            x=stage_0_probs,
            name=f'True Stage {stage_0}',
            opacity=0.7,
            nbinsx=20,
            marker_color='blue'
        ),
        row=2, col=2
    )
    
    fig.add_trace(
        go.Histogram(
            x=stage_4_probs,
            name=f'True Stage {stage_4}',
            opacity=0.7,
            nbinsx=20,
            marker_color='red'
        ),
        row=2, col=2
    )
    
    # Update layout
    fig.update_layout(
        title=f'{model_name} Classification Performance',
        height=800,
        showlegend=True
    )
    
    # Update axis labels
    fig.update_xaxes(title_text="Predicted", row=1, col=1)
    fig.update_yaxes(title_text="Actual", row=1, col=1)
    fig.update_xaxes(title_text="False Positive Rate", row=1, col=2)
    fig.update_yaxes(title_text="True Positive Rate", row=1, col=2)
    fig.update_xaxes(title_text="Epoch", row=2, col=1)
    fig.update_yaxes(title_text="Accuracy", row=2, col=1)
    fig.update_xaxes(title_text="Prediction Probability", row=2, col=2)
    fig.update_yaxes(title_text="Count", row=2, col=2)
    
    return fig

def classify_unknown_spectra(model, scaler, organized_data, stage_0=0, stage_4=4):
    """
    Classify all spectra in the dataset using the trained model
    """
    results = []
    
    for stage, stage_data in organized_data.items():
        for file_num, file_data in stage_data.items():
            intensity = file_data['intensity']
            intensity = np.nan_to_num(intensity, nan=0.0)
            
            # Reshape for prediction
            intensity_scaled = scaler.transform(intensity.reshape(1, -1))
            
            # Make prediction
            if hasattr(model, 'predict_proba'):
                # Scikit-learn model
                prob = model.predict_proba(intensity_scaled)[0, 1]
                prediction = model.predict(intensity_scaled)[0]
            else:
                # TensorFlow model
                prob = model.predict(intensity_scaled)[0, 0]
                prediction = (prob > 0.5).astype(int)
            
            predicted_stage = stage_4 if prediction == 1 else stage_0
            confidence = prob if prediction == 1 else 1 - prob
            
            results.append({
                'actual_stage': stage,
                'file_number': file_num,
                'predicted_stage': predicted_stage,
                'prediction_probability': prob,
                'confidence': confidence,
                'correct': stage in [stage_0, stage_4] and (
                    (stage == stage_0 and prediction == 0) or 
                    (stage == stage_4 and prediction == 1)
                )
            })
    
    return pd.DataFrame(results)

def generate_classification_report(evaluation, predictions_df, model_name="Neural Network", stage_0=0, stage_4=4):
    """
    Generate a comprehensive classification report
    """
    report = []
    
    report.append(f"# {model_name} Binary Classification Report")
    report.append(f"## Classification Task: Stage {stage_0} vs Stage {stage_4}\n")
    
    # Model Performance
    report.append("## Model Performance")
    report.append(f"- Overall Accuracy: {evaluation['accuracy']:.3f}")
    report.append(f"- ROC AUC Score: {evaluation['roc_auc']:.3f}\n")
    
    # Classification Report
    class_report = evaluation['classification_report']
    report.append("## Detailed Classification Metrics")
    
    for class_name in [f'Stage {stage_0}', f'Stage {stage_4}']:
        class_key = '0' if 'Stage 0' in class_name else '1'
        if class_key in class_report:
            metrics = class_report[class_key]
            report.append(f"### {class_name}")
            report.append(f"- Precision: {metrics['precision']:.3f}")
            report.append(f"- Recall: {metrics['recall']:.3f}")
            report.append(f"- F1-Score: {metrics['f1-score']:.3f}")
            report.append(f"- Support: {metrics['support']}")
            report.append("")
    
    # Macro and Weighted Averages
    report.append("### Overall Metrics")
    report.append(f"- Macro Avg Precision: {class_report['macro avg']['precision']:.3f}")
    report.append(f"- Macro Avg Recall: {class_report['macro avg']['recall']:.3f}")
    report.append(f"- Macro Avg F1-Score: {class_report['macro avg']['f1-score']:.3f}")
    report.append(f"- Weighted Avg F1-Score: {class_report['weighted avg']['f1-score']:.3f}\n")
    
    # Confusion Matrix
    cm = evaluation['confusion_matrix']
    report.append("## Confusion Matrix")
    report.append(f"```")
    report.append(f"                 Predicted")
    report.append(f"              Stage {stage_0}  Stage {stage_4}")
    report.append(f"Actual Stage {stage_0}    {cm[0,0]:4d}    {cm[0,1]:4d}")
    report.append(f"       Stage {stage_4}    {cm[1,0]:4d}    {cm[1,1]:4d}")
    report.append(f"```\n")
    
    # Predictions Summary
    if predictions_df is not None:
        total_predictions = len(predictions_df)
        binary_stages = predictions_df[predictions_df['actual_stage'].isin([stage_0, stage_4])]
        correct_binary = binary_stages['correct'].sum() if len(binary_stages) > 0 else 0
        
        report.append("## Predictions Summary")
        report.append(f"- Total spectra classified: {total_predictions}")
        report.append(f"- Binary classification accuracy: {correct_binary}/{len(binary_stages)} = {correct_binary/len(binary_stages):.3f}" if len(binary_stages) > 0 else "- No binary classification samples")
        
        # Stage-wise breakdown
        stage_breakdown = predictions_df.groupby('actual_stage').agg({
            'predicted_stage': lambda x: (x == stage_4).sum(),
            'confidence': 'mean'
        }).round(3)
        
        report.append("\n### Stage-wise Predictions")
        for stage, row in stage_breakdown.iterrows():
            stage_4_predictions = row['predicted_stage']
            avg_confidence = row['confidence']
            total_stage = len(predictions_df[predictions_df['actual_stage'] == stage])
            report.append(f"- Stage {stage}: {stage_4_predictions}/{total_stage} classified as Stage {stage_4} (avg confidence: {avg_confidence:.3f})")
    
    return "\n".join(report)

def cross_validate_model(X, y, model_type='sklearn', cv_folds=5, random_state=42):
    """
    Perform cross-validation on the neural network model
    """
    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Create model
    model = create_sklearn_neural_network(X.shape[1])
    
    # Perform cross-validation
    cv_scores = cross_val_score(
        model, X_scaled, y, 
        cv=StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_state),
        scoring='accuracy'
    )
    
    return {
        'cv_scores': cv_scores,
        'mean_accuracy': cv_scores.mean(),
        'std_accuracy': cv_scores.std(),
        'model_type': model_type
    }