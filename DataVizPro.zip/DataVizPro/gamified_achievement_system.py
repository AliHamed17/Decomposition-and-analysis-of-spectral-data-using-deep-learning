import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import json
import batch_job_manager as job_mgr

class Achievement:
    def __init__(self, id: str, name: str, description: str, category: str, 
                 badge_icon: str, points: int, tier: str = "Bronze", 
                 requirements: Dict = None, unlock_condition: str = ""):
        self.id = id
        self.name = name
        self.description = description
        self.category = category
        self.badge_icon = badge_icon
        self.points = points
        self.tier = tier
        self.requirements = requirements or {}
        self.unlock_condition = unlock_condition
        self.unlocked = False
        self.progress = 0.0
        self.unlock_date = None

class UserProgress:
    def __init__(self):
        self.total_points = 0
        self.level = 1
        self.experience_points = 0
        self.unlocked_achievements = set()
        self.job_stats = {
            'total_jobs_completed': 0,
            'total_jobs_failed': 0,
            'complex_jobs_optimized': 0,
            'critical_jobs_handled': 0,
            'consecutive_successes': 0,
            'max_consecutive_successes': 0,
            'avg_complexity_reduction': 0.0,
            'total_runtime_saved': 0.0,
            'resource_efficiency_improvements': 0,
            'error_rate_reductions': 0
        }
        self.mastery_streaks = {
            'optimization_streak': 0,
            'efficiency_streak': 0,
            'reliability_streak': 0
        }

class GamifiedAchievementSystem:
    def __init__(self):
        self.achievements = self._initialize_achievements()
        self.level_thresholds = [0, 100, 250, 500, 1000, 2000, 3500, 5500, 8000, 12000, 16000]
        self.categories = ["Efficiency Master", "Complexity Reducer", "Reliability Expert", 
                          "Resource Optimizer", "Performance Guru", "Innovation Pioneer"]
    
    def _initialize_achievements(self) -> Dict[str, Achievement]:
        """Initialize all available achievements"""
        achievements = {}
        
        # Beginner achievements
        achievements["first_job"] = Achievement(
            "first_job", "First Steps", "Complete your first batch job",
            "Beginner", "🎯", 10, "Bronze",
            {"jobs_completed": 1}, "Complete 1 job"
        )
        
        achievements["job_rookie"] = Achievement(
            "job_rookie", "Job Rookie", "Complete 10 batch jobs",
            "Beginner", "🔰", 25, "Bronze",
            {"jobs_completed": 10}, "Complete 10 jobs"
        )
        
        achievements["complexity_aware"] = Achievement(
            "complexity_aware", "Complexity Aware", "Analyze job complexity for the first time",
            "Beginner", "📊", 15, "Bronze",
            {"complexity_analyses": 1}, "Run complexity analysis"
        )
        
        # Efficiency achievements
        achievements["efficiency_novice"] = Achievement(
            "efficiency_novice", "Efficiency Novice", "Achieve 90%+ success rate over 25 jobs",
            "Efficiency Master", "⚡", 50, "Silver",
            {"success_rate": 0.9, "min_jobs": 25}, "Maintain 90%+ success rate"
        )
        
        achievements["efficiency_expert"] = Achievement(
            "efficiency_expert", "Efficiency Expert", "Achieve 95%+ success rate over 50 jobs",
            "Efficiency Master", "⚡", 100, "Gold",
            {"success_rate": 0.95, "min_jobs": 50}, "Maintain 95%+ success rate"
        )
        
        achievements["efficiency_master"] = Achievement(
            "efficiency_master", "Efficiency Master", "Achieve 98%+ success rate over 100 jobs",
            "Efficiency Master", "⚡", 200, "Platinum",
            {"success_rate": 0.98, "min_jobs": 100}, "Maintain 98%+ success rate"
        )
        
        # Complexity reduction achievements
        achievements["complexity_reducer"] = Achievement(
            "complexity_reducer", "Complexity Reducer", "Reduce average job complexity by 20%",
            "Complexity Reducer", "🔻", 75, "Silver",
            {"complexity_reduction": 0.2}, "Reduce complexity by 20%"
        )
        
        achievements["complexity_crusher"] = Achievement(
            "complexity_crusher", "Complexity Crusher", "Reduce average job complexity by 40%",
            "Complexity Reducer", "🔻", 150, "Gold",
            {"complexity_reduction": 0.4}, "Reduce complexity by 40%"
        )
        
        achievements["simplicity_sage"] = Achievement(
            "simplicity_sage", "Simplicity Sage", "Maintain <0.3 average complexity over 50 jobs",
            "Complexity Reducer", "🧙", 250, "Platinum",
            {"avg_complexity": 0.3, "min_jobs": 50}, "Keep low complexity"
        )
        
        # Reliability achievements
        achievements["reliable_operator"] = Achievement(
            "reliable_operator", "Reliable Operator", "Complete 25 consecutive jobs without failure",
            "Reliability Expert", "🛡️", 100, "Gold",
            {"consecutive_successes": 25}, "25 consecutive successes"
        )
        
        achievements["reliability_champion"] = Achievement(
            "reliability_champion", "Reliability Champion", "Complete 50 consecutive jobs without failure",
            "Reliability Expert", "🏆", 200, "Platinum",
            {"consecutive_successes": 50}, "50 consecutive successes"
        )
        
        achievements["zero_tolerance"] = Achievement(
            "zero_tolerance", "Zero Tolerance", "Achieve zero failures over 100 jobs",
            "Reliability Expert", "💎", 300, "Diamond",
            {"zero_failures": 100}, "100 jobs with zero failures"
        )
        
        # Resource optimization achievements
        achievements["resource_saver"] = Achievement(
            "resource_saver", "Resource Saver", "Reduce average resource usage by 25%",
            "Resource Optimizer", "🔋", 75, "Silver",
            {"resource_reduction": 0.25}, "Reduce resource usage by 25%"
        )
        
        achievements["green_operator"] = Achievement(
            "green_operator", "Green Operator", "Maintain <60% average resource usage",
            "Resource Optimizer", "🌱", 125, "Gold",
            {"avg_resource_usage": 0.6}, "Keep low resource usage"
        )
        
        achievements["efficiency_engineer"] = Achievement(
            "efficiency_engineer", "Efficiency Engineer", "Improve throughput by 50%",
            "Resource Optimizer", "⚙️", 175, "Platinum",
            {"throughput_improvement": 0.5}, "Improve throughput by 50%"
        )
        
        # Performance achievements
        achievements["speed_demon"] = Achievement(
            "speed_demon", "Speed Demon", "Reduce average runtime by 30%",
            "Performance Guru", "🚀", 100, "Gold",
            {"runtime_reduction": 0.3}, "Reduce runtime by 30%"
        )
        
        achievements["performance_prophet"] = Achievement(
            "performance_prophet", "Performance Prophet", "Achieve <30s average runtime",
            "Performance Guru", "🔮", 150, "Platinum",
            {"avg_runtime": 30}, "Keep runtime under 30s"
        )
        
        achievements["lightning_fast"] = Achievement(
            "lightning_fast", "Lightning Fast", "Complete 10 jobs in under 10 seconds each",
            "Performance Guru", "⚡", 200, "Diamond",
            {"fast_jobs": 10, "max_runtime": 10}, "10 ultra-fast jobs"
        )
        
        # Innovation achievements
        achievements["experimenter"] = Achievement(
            "experimenter", "Experimenter", "Try all job types at least once",
            "Innovation Pioneer", "🧪", 50, "Silver",
            {"job_types_tried": 5}, "Try 5 different job types"
        )
        
        achievements["optimization_guru"] = Achievement(
            "optimization_guru", "Optimization Guru", "Implement 10 optimization recommendations",
            "Innovation Pioneer", "💡", 150, "Gold",
            {"optimizations_implemented": 10}, "Implement 10 optimizations"
        )
        
        achievements["mastery_legend"] = Achievement(
            "mastery_legend", "Mastery Legend", "Unlock all other achievements",
            "Innovation Pioneer", "👑", 500, "Legendary",
            {"all_achievements": True}, "Unlock all achievements"
        )
        
        # Streak achievements
        achievements["hot_streak"] = Achievement(
            "hot_streak", "Hot Streak", "Complete 10 optimizations in a row",
            "Performance Guru", "🔥", 75, "Silver",
            {"optimization_streak": 10}, "10 optimization streak"
        )
        
        achievements["unstoppable"] = Achievement(
            "unstoppable", "Unstoppable", "Complete 20 optimizations in a row",
            "Performance Guru", "🌟", 150, "Gold",
            {"optimization_streak": 20}, "20 optimization streak"
        )
        
        return achievements
    
    def calculate_level(self, experience_points: int) -> int:
        """Calculate user level based on experience points"""
        for level, threshold in enumerate(self.level_thresholds):
            if experience_points < threshold:
                return level
        return len(self.level_thresholds)
    
    def get_next_level_progress(self, experience_points: int) -> Tuple[int, int, float]:
        """Get progress to next level"""
        current_level = self.calculate_level(experience_points)
        if current_level >= len(self.level_thresholds) - 1:
            return current_level, 0, 1.0
        
        current_threshold = self.level_thresholds[current_level - 1] if current_level > 0 else 0
        next_threshold = self.level_thresholds[current_level]
        
        progress = (experience_points - current_threshold) / (next_threshold - current_threshold)
        points_needed = next_threshold - experience_points
        
        return current_level, points_needed, progress
    
    def check_achievements(self, user_progress: UserProgress, job_data: pd.DataFrame = None) -> List[Achievement]:
        """Check for newly unlocked achievements"""
        newly_unlocked = []
        
        if job_data is not None and not job_data.empty:
            # Update user stats based on job data
            self._update_user_stats(user_progress, job_data)
        
        for achievement_id, achievement in self.achievements.items():
            if achievement_id in user_progress.unlocked_achievements:
                continue
            
            if self._check_achievement_conditions(achievement, user_progress, job_data):
                achievement.unlocked = True
                achievement.unlock_date = datetime.now()
                user_progress.unlocked_achievements.add(achievement_id)
                user_progress.total_points += achievement.points
                user_progress.experience_points += achievement.points
                newly_unlocked.append(achievement)
        
        # Update level
        user_progress.level = self.calculate_level(user_progress.experience_points)
        
        return newly_unlocked
    
    def _update_user_stats(self, user_progress: UserProgress, job_data: pd.DataFrame):
        """Update user statistics based on job data"""
        if job_data.empty:
            return
        
        completed_jobs = job_data[job_data['status'] == 'completed']
        failed_jobs = job_data[job_data['status'] == 'failed']
        
        user_progress.job_stats['total_jobs_completed'] = len(completed_jobs)
        user_progress.job_stats['total_jobs_failed'] = len(failed_jobs)
        
        if len(job_data) > 0:
            success_rate = len(completed_jobs) / len(job_data)
            
            # Calculate consecutive successes
            consecutive = 0
            max_consecutive = 0
            for _, job in job_data.iterrows():
                if job['status'] == 'completed':
                    consecutive += 1
                    max_consecutive = max(max_consecutive, consecutive)
                else:
                    consecutive = 0
            
            user_progress.job_stats['consecutive_successes'] = consecutive
            user_progress.job_stats['max_consecutive_successes'] = max_consecutive
            
            # Complexity and performance metrics
            if 'complexity_score' in job_data.columns:
                avg_complexity = job_data['complexity_score'].mean()
                complex_jobs = job_data[job_data['complexity_score'] > 0.7]
                user_progress.job_stats['complex_jobs_optimized'] = len(complex_jobs)
                
                # Calculate complexity reduction (simulated)
                if len(job_data) > 10:
                    recent_complexity = job_data.tail(10)['complexity_score'].mean()
                    older_complexity = job_data.head(10)['complexity_score'].mean()
                    reduction = max(0, (older_complexity - recent_complexity) / older_complexity)
                    user_progress.job_stats['avg_complexity_reduction'] = reduction
            
            # Resource efficiency
            if 'cpu_usage' in job_data.columns and 'memory_usage' in job_data.columns:
                avg_resource = (job_data['cpu_usage'].mean() + job_data['memory_usage'].mean()) / 2
                if avg_resource < 60:
                    user_progress.job_stats['resource_efficiency_improvements'] += 1
    
    def _check_achievement_conditions(self, achievement: Achievement, 
                                    user_progress: UserProgress, job_data: pd.DataFrame = None) -> bool:
        """Check if achievement conditions are met"""
        reqs = achievement.requirements
        stats = user_progress.job_stats
        
        # Job completion achievements
        if "jobs_completed" in reqs:
            if stats['total_jobs_completed'] < reqs["jobs_completed"]:
                return False
        
        # Success rate achievements
        if "success_rate" in reqs and "min_jobs" in reqs:
            total_jobs = stats['total_jobs_completed'] + stats['total_jobs_failed']
            if total_jobs < reqs["min_jobs"]:
                return False
            if total_jobs > 0:
                actual_rate = stats['total_jobs_completed'] / total_jobs
                if actual_rate < reqs["success_rate"]:
                    return False
        
        # Consecutive successes
        if "consecutive_successes" in reqs:
            if stats['max_consecutive_successes'] < reqs["consecutive_successes"]:
                return False
        
        # Complexity reduction
        if "complexity_reduction" in reqs:
            if stats['avg_complexity_reduction'] < reqs["complexity_reduction"]:
                return False
        
        # Zero failures
        if "zero_failures" in reqs:
            if stats['total_jobs_failed'] > 0 or stats['total_jobs_completed'] < reqs["zero_failures"]:
                return False
        
        # All achievements (mastery)
        if "all_achievements" in reqs:
            if len(user_progress.unlocked_achievements) < len(self.achievements) - 1:  # Exclude this achievement
                return False
        
        # Job types variety
        if "job_types_tried" in reqs and job_data is not None:
            unique_types = job_data['job_type'].nunique() if 'job_type' in job_data.columns else 0
            if unique_types < reqs["job_types_tried"]:
                return False
        
        # Complexity analysis
        if "complexity_analyses" in reqs:
            # This would be tracked separately in real implementation
            return True  # Simplified for demo
        
        return True
    
    def get_achievement_progress(self, achievement: Achievement, user_progress: UserProgress, 
                               job_data: pd.DataFrame = None) -> float:
        """Calculate progress towards an achievement (0.0 to 1.0)"""
        if achievement.id in user_progress.unlocked_achievements:
            return 1.0
        
        reqs = achievement.requirements
        stats = user_progress.job_stats
        progress_factors = []
        
        if "jobs_completed" in reqs:
            progress_factors.append(min(1.0, stats['total_jobs_completed'] / reqs["jobs_completed"]))
        
        if "success_rate" in reqs and "min_jobs" in reqs:
            total_jobs = stats['total_jobs_completed'] + stats['total_jobs_failed']
            job_progress = min(1.0, total_jobs / reqs["min_jobs"])
            if total_jobs > 0:
                rate_progress = min(1.0, (stats['total_jobs_completed'] / total_jobs) / reqs["success_rate"])
            else:
                rate_progress = 0.0
            progress_factors.append(min(job_progress, rate_progress))
        
        if "consecutive_successes" in reqs:
            progress_factors.append(min(1.0, stats['max_consecutive_successes'] / reqs["consecutive_successes"]))
        
        if "complexity_reduction" in reqs:
            progress_factors.append(min(1.0, stats['avg_complexity_reduction'] / reqs["complexity_reduction"]))
        
        if "zero_failures" in reqs:
            if stats['total_jobs_failed'] > 0:
                progress_factors.append(0.0)
            else:
                progress_factors.append(min(1.0, stats['total_jobs_completed'] / reqs["zero_failures"]))
        
        return min(progress_factors) if progress_factors else 0.0
    
    def get_leaderboard_data(self, all_users: List[UserProgress]) -> pd.DataFrame:
        """Generate leaderboard data"""
        leaderboard = []
        for i, user in enumerate(sorted(all_users, key=lambda x: x.total_points, reverse=True)):
            leaderboard.append({
                'Rank': str(i + 1),
                'User': f"User_{i+1}",
                'Level': str(user.level),
                'Total Points': str(user.total_points),
                'Achievements': str(len(user.unlocked_achievements)),
                'Jobs Completed': str(user.job_stats['total_jobs_completed']),
                'Success Rate': f"{(user.job_stats['total_jobs_completed'] / max(1, user.job_stats['total_jobs_completed'] + user.job_stats['total_jobs_failed'])) * 100:.1f}%"
            })
        return pd.DataFrame(leaderboard)
    
    def create_achievement_dashboard(self, job_manager=None):
        """Create the main gamified achievement dashboard"""
        
        st.markdown("""
        <div class="analysis-section">
            <h2>🏆 Gamified Achievement System</h2>
            <p>Master job complexity optimization through achievements, levels, and competitive challenges</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Initialize or load user progress
        if 'user_progress' not in st.session_state:
            st.session_state.user_progress = UserProgress()
        
        user_progress = st.session_state.user_progress
        
        # Generate sample job data for demonstration
        sample_data = self._generate_sample_job_data(50)
        
        # Check for new achievements
        newly_unlocked = self.check_achievements(user_progress, sample_data)
        
        # Display new achievements notification
        if newly_unlocked:
            for achievement in newly_unlocked:
                st.success(f"🎉 Achievement Unlocked: **{achievement.name}** (+{achievement.points} points)")
        
        # User profile and level progress
        st.write("### 👤 User Profile")
        
        current_level, points_needed, level_progress = self.get_next_level_progress(user_progress.experience_points)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Level", current_level)
        
        with col2:
            st.metric("Total Points", user_progress.total_points)
        
        with col3:
            st.metric("Achievements", f"{len(user_progress.unlocked_achievements)}/{len(self.achievements)}")
        
        with col4:
            if points_needed > 0:
                st.metric("Next Level", f"{points_needed} points needed")
            else:
                st.metric("Status", "Max Level!")
        
        # Level progress bar
        if points_needed > 0:
            st.write("**Level Progress:**")
            st.progress(level_progress, f"Level {current_level} → {current_level + 1}")
        
        # Achievement categories
        st.write("### 🏅 Achievement Categories")
        
        category_tabs = st.tabs(self.categories + ["All Achievements"])
        
        for i, category in enumerate(self.categories):
            with category_tabs[i]:
                self._display_category_achievements(category, user_progress, sample_data)
        
        with category_tabs[-1]:
            self._display_all_achievements(user_progress, sample_data)
        
        # Statistics and progress
        st.write("### 📊 Performance Statistics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Performance metrics
            stats = user_progress.job_stats
            total_jobs = stats['total_jobs_completed'] + stats['total_jobs_failed']
            success_rate = (stats['total_jobs_completed'] / max(1, total_jobs)) * 100
            
            # Convert all values to strings to prevent mixed type errors
            performance_data = {
                'Metric': ['Jobs Completed', 'Success Rate', 'Max Consecutive', 'Complex Jobs Handled'],
                'Value': [str(stats['total_jobs_completed']), f"{success_rate:.1f}%", 
                         str(stats['max_consecutive_successes']), str(stats['complex_jobs_optimized'])]
            }
            
            st.write("**Performance Metrics:**")
            st.dataframe(pd.DataFrame(performance_data), hide_index=True, use_container_width=True)
        
        with col2:
            # Achievement progress chart
            categories_progress = {}
            for category in self.categories:
                cat_achievements = [a for a in self.achievements.values() if a.category == category]
                unlocked_in_cat = len([a for a in cat_achievements if a.id in user_progress.unlocked_achievements])
                categories_progress[category] = (unlocked_in_cat / len(cat_achievements)) * 100 if cat_achievements else 0
            
            fig = go.Figure(data=go.Bar(
                x=list(categories_progress.values()),
                y=list(categories_progress.keys()),
                orientation='h',
                marker_color='lightblue'
            ))
            
            fig.update_layout(
                title="Category Progress",
                xaxis_title="Completion %",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        # Leaderboard
        st.write("### 🏆 Leaderboard")
        
        # Generate sample leaderboard data
        sample_users = [user_progress] + [self._generate_sample_user() for _ in range(9)]
        leaderboard = self.get_leaderboard_data(sample_users)
        
        # Highlight current user
        current_user_rank = leaderboard[leaderboard['User'] == 'User_1']['Rank'].iloc[0]
        
        st.write(f"**Your Current Rank: #{current_user_rank}**")
        st.dataframe(leaderboard, hide_index=True, use_container_width=True)
        
        # Challenges and goals
        st.write("### 🎯 Active Challenges")
        
        self._display_active_challenges(user_progress, sample_data)
        
        # Achievement simulation
        st.write("### 🔮 Achievement Simulator")
        
        with st.expander("Simulate Progress"):
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("Complete 10 Jobs", use_container_width=True):
                    user_progress.job_stats['total_jobs_completed'] += 10
                    newly_unlocked = self.check_achievements(user_progress, sample_data)
                    if newly_unlocked:
                        for achievement in newly_unlocked:
                            st.success(f"🎉 {achievement.name} unlocked!")
                    st.rerun()
            
            with col2:
                if st.button("Improve Efficiency", use_container_width=True):
                    user_progress.job_stats['max_consecutive_successes'] += 5
                    user_progress.job_stats['avg_complexity_reduction'] += 0.1
                    newly_unlocked = self.check_achievements(user_progress, sample_data)
                    if newly_unlocked:
                        for achievement in newly_unlocked:
                            st.success(f"🎉 {achievement.name} unlocked!")
                    st.rerun()
    
    def _display_category_achievements(self, category: str, user_progress: UserProgress, job_data: pd.DataFrame):
        """Display achievements for a specific category"""
        category_achievements = [a for a in self.achievements.values() if a.category == category]
        
        for achievement in sorted(category_achievements, key=lambda x: x.points):
            self._display_achievement_card(achievement, user_progress, job_data)
    
    def _display_all_achievements(self, user_progress: UserProgress, job_data: pd.DataFrame):
        """Display all achievements"""
        # Group by tier
        tiers = {"Bronze": [], "Silver": [], "Gold": [], "Platinum": [], "Diamond": [], "Legendary": []}
        
        for achievement in self.achievements.values():
            tiers[achievement.tier].append(achievement)
        
        for tier, achievements in tiers.items():
            if achievements:
                st.write(f"#### {tier} Tier")
                for achievement in sorted(achievements, key=lambda x: x.points):
                    self._display_achievement_card(achievement, user_progress, job_data)
    
    def _display_achievement_card(self, achievement: Achievement, user_progress: UserProgress, job_data: pd.DataFrame):
        """Display individual achievement card"""
        unlocked = achievement.id in user_progress.unlocked_achievements
        progress = self.get_achievement_progress(achievement, user_progress, job_data)
        
        # Create achievement container
        container = st.container()
        
        with container:
            col1, col2, col3 = st.columns([1, 6, 2])
            
            with col1:
                if unlocked:
                    st.write(f"✅ {achievement.badge_icon}")
                else:
                    st.write(f"⬜ {achievement.badge_icon}")
            
            with col2:
                if unlocked:
                    st.write(f"**{achievement.name}** ({achievement.tier})")
                    st.write(f"*{achievement.description}*")
                    if achievement.unlock_date:
                        st.caption(f"Unlocked: {achievement.unlock_date.strftime('%Y-%m-%d')}")
                else:
                    st.write(f"**{achievement.name}** ({achievement.tier}) - *Locked*")
                    st.write(f"*{achievement.description}*")
                    st.write(f"**Requirement:** {achievement.unlock_condition}")
                    if progress > 0:
                        st.progress(progress, f"Progress: {progress*100:.1f}%")
            
            with col3:
                st.write(f"**{achievement.points} pts**")
                if not unlocked:
                    st.caption(f"{achievement.category}")
        
        st.markdown("---")
    
    def _display_active_challenges(self, user_progress: UserProgress, job_data: pd.DataFrame):
        """Display active challenges and goals"""
        challenges = [
            {
                "name": "Efficiency Sprint",
                "description": "Complete 15 jobs with 95%+ success rate",
                "reward": "75 bonus points",
                "progress": min(1.0, user_progress.job_stats['total_jobs_completed'] / 15),
                "time_limit": "3 days remaining"
            },
            {
                "name": "Complexity Buster",
                "description": "Reduce average complexity below 0.4",
                "reward": "100 bonus points",
                "progress": 0.6,
                "time_limit": "5 days remaining"
            },
            {
                "name": "Reliability Master",
                "description": "Achieve 20 consecutive successful jobs",
                "reward": "50 bonus points",
                "progress": user_progress.job_stats['max_consecutive_successes'] / 20,
                "time_limit": "1 week remaining"
            }
        ]
        
        for challenge in challenges:
            with st.container():
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**{challenge['name']}**")
                    st.write(challenge['description'])
                    # Ensure progress value is between 0 and 1
                    progress_value = min(max(challenge['progress'], 0.0), 1.0)
                    st.progress(progress_value, f"Progress: {progress_value*100:.1f}%")
                
                with col2:
                    st.write(f"🎁 {challenge['reward']}")
                    st.caption(challenge['time_limit'])
                
                st.markdown("---")
    
    def _generate_sample_job_data(self, num_jobs: int) -> pd.DataFrame:
        """Generate sample job data for achievement testing"""
        np.random.seed(42)
        
        job_types = ['peak_analysis', 'statistical_analysis', 'anomaly_detection', 'data_preprocessing']
        statuses = ['completed', 'failed']
        
        data = []
        for i in range(num_jobs):
            # Bias towards completed jobs for demonstration
            status = np.random.choice(statuses, p=[0.85, 0.15])
            
            data.append({
                'job_id': f"job_{i+1}",
                'job_type': np.random.choice(job_types),
                'status': status,
                'complexity_score': np.random.uniform(0.2, 0.8),
                'runtime_seconds': np.random.uniform(20, 180),
                'cpu_usage': np.random.uniform(30, 80),
                'memory_usage': np.random.uniform(25, 75),
                'created_at': datetime.now() - timedelta(days=np.random.randint(1, 30))
            })
        
        return pd.DataFrame(data)
    
    def _generate_sample_user(self) -> UserProgress:
        """Generate sample user for leaderboard"""
        user = UserProgress()
        user.total_points = np.random.randint(50, 800)
        user.experience_points = user.total_points
        user.level = self.calculate_level(user.experience_points)
        user.job_stats['total_jobs_completed'] = np.random.randint(10, 100)
        user.job_stats['total_jobs_failed'] = np.random.randint(0, 10)
        user.unlocked_achievements = set(list(self.achievements.keys())[:np.random.randint(1, len(self.achievements)//2)])
        return user

def create_gamified_achievement_dashboard():
    """Main function to create the gamified achievement dashboard"""
    
    # Initialize the achievement system
    achievement_system = GamifiedAchievementSystem()
    
    # Get job manager if available
    job_manager = st.session_state.get('batch_job_manager', None)
    
    # Create the dashboard
    achievement_system.create_achievement_dashboard(job_manager)
    
    return achievement_system