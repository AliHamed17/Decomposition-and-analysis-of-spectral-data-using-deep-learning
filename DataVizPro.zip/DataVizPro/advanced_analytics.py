import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import signal, interpolate, stats
from scipy.optimize import curve_fit
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

def apply_baseline_correction(wavelength, intensity, polynomial_order=2):
    """
    Apply polynomial baseline correction to a spectrum
    Returns corrected intensity array
    """
    # Fit polynomial to the data
    coeffs = np.polyfit(wavelength, intensity, polynomial_order)
    baseline = np.polyval(coeffs, wavelength)
    
    # Subtract baseline
    corrected_intensity = intensity - baseline
    
    return corrected_intensity, baseline

def apply_smoothing(intensity, window_length=11, polyorder=3):
    """
    Apply Savitzky-Golay smoothing filter to the intensity data
    Returns smoothed intensity array
    """
    # Ensure window_length is odd and valid
    if window_length % 2 == 0:
        window_length += 1
    
    if window_length > len(intensity):
        window_length = len(intensity) // 2 * 2 - 1
        if window_length < 3:
            return intensity
    
    if polyorder >= window_length:
        polyorder = window_length - 1
    
    smoothed = signal.savgol_filter(intensity, window_length, polyorder)
    return smoothed

def find_spectral_peaks(wavelength, intensity, prominence=0.1, width=5):
    """
    Find peaks in a spectrum
    Returns peak indices, peak wavelengths, and peak properties
    """
    # Normalize intensity for peak finding
    normalized_intensity = (intensity - np.min(intensity)) / (np.max(intensity) - np.min(intensity))
    
    # Find peaks
    peaks, properties = signal.find_peaks(
        normalized_intensity, 
        prominence=prominence,
        width=width,
        distance=10
    )
    
    peak_wavelengths = wavelength[peaks]
    peak_intensities = intensity[peaks]
    
    return peaks, peak_wavelengths, peak_intensities, properties

def calculate_peak_metrics(wavelength, intensity, peaks, properties):
    """
    Calculate metrics for detected peaks (height, width, area)
    Returns a DataFrame with peak metrics
    """
    if len(peaks) == 0:
        return pd.DataFrame()
    
    peak_data = []
    
    for i, peak_idx in enumerate(peaks):
        # Calculate peak area (simple trapezoidal integration around peak)
        left_base = int(properties['left_bases'][i]) if 'left_bases' in properties else max(0, peak_idx - 10)
        right_base = int(properties['right_bases'][i]) if 'right_bases' in properties else min(len(intensity), peak_idx + 10)
        
        peak_area = np.trapz(
            intensity[left_base:right_base+1], 
            wavelength[left_base:right_base+1]
        )
        
        peak_info = {
            'peak_index': peak_idx,
            'wavelength': wavelength[peak_idx],
            'intensity': intensity[peak_idx],
            'prominence': properties['prominences'][i],
            'width': properties['widths'][i] if 'widths' in properties else np.nan,
            'area': peak_area,
            'left_base': wavelength[left_base],
            'right_base': wavelength[right_base]
        }
        peak_data.append(peak_info)
    
    return pd.DataFrame(peak_data)

def perform_pca_analysis(data, n_components=2):
    """
    Perform Principal Component Analysis on spectral data
    Returns PCA model, transformed data, and explained variance
    """
    # Prepare data matrix
    X = []
    labels = []
    
    for stage, stage_data in data.items():
        for file_num, file_data in stage_data.items():
            X.append(file_data['intensity'])
            labels.append(f'S{stage}_F{file_num}')
    
    X = np.array(X)
    
    # Standardize data
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Apply PCA
    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X_scaled)
    
    return pca, X_pca, labels, scaler

def plot_pca_results(X_pca, explained_variance, labels, stages):
    """
    Plot PCA results in 2D or 3D
    Returns the plot figure
    """
    # Extract stage information from labels
    stage_nums = [int(label.split('_')[0][1:]) for label in labels]
    
    # Create color mapping
    colors = px.colors.qualitative.Set1
    color_map = {stage: colors[i % len(colors)] for i, stage in enumerate(sorted(set(stage_nums)))}
    point_colors = [color_map[stage] for stage in stage_nums]
    
    if X_pca.shape[1] >= 3:
        # 3D plot
        fig = go.Figure(data=go.Scatter3d(
            x=X_pca[:, 0],
            y=X_pca[:, 1],
            z=X_pca[:, 2],
            mode='markers+text',
            marker=dict(
                size=8,
                color=point_colors,
                opacity=0.8
            ),
            text=labels,
            textposition="top center",
            hovertemplate='<b>%{text}</b><br>PC1: %{x:.3f}<br>PC2: %{y:.3f}<br>PC3: %{z:.3f}<extra></extra>'
        ))
        
        fig.update_layout(
            title=f'PCA Analysis (3D) - Explained Variance: PC1={explained_variance[0]:.1%}, PC2={explained_variance[1]:.1%}, PC3={explained_variance[2]:.1%}',
            scene=dict(
                xaxis_title=f'PC1 ({explained_variance[0]:.1%})',
                yaxis_title=f'PC2 ({explained_variance[1]:.1%})',
                zaxis_title=f'PC3 ({explained_variance[2]:.1%})'
            )
        )
    else:
        # 2D plot
        fig = go.Figure(data=go.Scatter(
            x=X_pca[:, 0],
            y=X_pca[:, 1],
            mode='markers+text',
            marker=dict(
                size=10,
                color=point_colors,
                opacity=0.8
            ),
            text=labels,
            textposition="top center",
            hovertemplate='<b>%{text}</b><br>PC1: %{x:.3f}<br>PC2: %{y:.3f}<extra></extra>'
        ))
        
        fig.update_layout(
            title=f'PCA Analysis (2D) - Explained Variance: PC1={explained_variance[0]:.1%}, PC2={explained_variance[1]:.1%}',
            xaxis_title=f'PC1 ({explained_variance[0]:.1%})',
            yaxis_title=f'PC2 ({explained_variance[1]:.1%})'
        )
    
    return fig

def compare_before_after_processing(wavelength, original_intensity, processed_intensity, title="Before and After Processing"):
    """
    Create a comparison plot showing before and after processing
    Returns the figure object
    """
    fig = go.Figure()
    
    # Original spectrum
    fig.add_trace(go.Scatter(
        x=wavelength,
        y=original_intensity,
        mode='lines',
        name='Original',
        line=dict(color='blue', width=2)
    ))
    
    # Processed spectrum
    fig.add_trace(go.Scatter(
        x=wavelength,
        y=processed_intensity,
        mode='lines',
        name='Processed',
        line=dict(color='red', width=2, dash='dash')
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title='Wavelength',
        yaxis_title='Intensity',
        hovermode='x unified'
    )
    
    return fig

def batch_process_spectra(data, stage, processing_params):
    """
    Apply processing to all spectra in a stage
    Returns processed data
    """
    if stage not in data:
        return None
    
    processed_data = {}
    
    for file_num, file_data in data[stage].items():
        wavelength = file_data['wavelength']
        intensity = file_data['intensity']
        
        processed_intensity = intensity.copy()
        
        # Apply baseline correction if requested
        if processing_params.get('baseline_correction', False):
            polynomial_order = processing_params.get('polynomial_order', 2)
            processed_intensity, _ = apply_baseline_correction(wavelength, processed_intensity, polynomial_order)
        
        # Apply smoothing if requested
        if processing_params.get('smoothing', False):
            window_length = processing_params.get('window_length', 11)
            polyorder = processing_params.get('polyorder', 3)
            processed_intensity = apply_smoothing(processed_intensity, window_length, polyorder)
        
        # Apply normalization if requested
        if processing_params.get('normalization', False):
            norm_method = processing_params.get('norm_method', 'minmax')
            if norm_method == 'minmax':
                processed_intensity = (processed_intensity - np.min(processed_intensity)) / (np.max(processed_intensity) - np.min(processed_intensity))
            elif norm_method == 'zscore':
                processed_intensity = (processed_intensity - np.mean(processed_intensity)) / np.std(processed_intensity)
        
        processed_data[file_num] = {
            'wavelength': wavelength,
            'intensity': processed_intensity,
            'original_intensity': intensity
        }
    
    return processed_data

def calculate_derivative_spectrum(wavelength, intensity, order=1):
    """
    Calculate derivative spectrum
    Returns derivative intensity array
    """
    # Calculate derivative using numpy gradient
    if order == 1:
        derivative = np.gradient(intensity, wavelength)
    elif order == 2:
        first_derivative = np.gradient(intensity, wavelength)
        derivative = np.gradient(first_derivative, wavelength)
    else:
        # For higher orders, use recursive approach
        derivative = intensity.copy()
        for _ in range(order):
            derivative = np.gradient(derivative, wavelength)
    
    return derivative

def plot_derivative_spectrum(wavelength, intensity, derivative, order=1):
    """
    Plot original spectrum and its derivative
    Returns the figure object
    """
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=[
            'Original Spectrum',
            f'{order}{"st" if order == 1 else "nd" if order == 2 else "th"} Derivative'
        ],
        vertical_spacing=0.1
    )
    
    # Original spectrum
    fig.add_trace(
        go.Scatter(
            x=wavelength,
            y=intensity,
            mode='lines',
            name='Original',
            line=dict(color='blue', width=2)
        ),
        row=1, col=1
    )
    
    # Derivative
    fig.add_trace(
        go.Scatter(
            x=wavelength,
            y=derivative,
            mode='lines',
            name=f'{order}{"st" if order == 1 else "nd" if order == 2 else "th"} Derivative',
            line=dict(color='red', width=2)
        ),
        row=2, col=1
    )
    
    fig.update_xaxes(title_text="Wavelength", row=2, col=1)
    fig.update_yaxes(title_text="Intensity", row=1, col=1)
    fig.update_yaxes(title_text="Derivative", row=2, col=1)
    
    fig.update_layout(
        title=f'Spectral Derivative Analysis (Order {order})',
        height=600,
        showlegend=False
    )
    
    return fig

def fit_gaussian_peaks(wavelength, intensity, peak_wavelengths):
    """
    Fit Gaussian functions to detected peaks
    Returns fitted parameters and R-squared
    """
    def multi_gaussian(x, *params):
        """Multiple Gaussian function"""
        y = np.zeros_like(x)
        for i in range(0, len(params), 3):
            amplitude, center, width = params[i:i+3]
            y += amplitude * np.exp(-((x - center) / width) ** 2)
        return y
    
    # Initial parameter guess
    p0 = []
    for peak_wav in peak_wavelengths:
        # Find intensity at peak wavelength
        peak_idx = np.argmin(np.abs(wavelength - peak_wav))
        amplitude = intensity[peak_idx]
        center = peak_wav
        width = 10  # Initial guess for width
        p0.extend([amplitude, center, width])
    
    try:
        # Fit the multi-Gaussian function
        popt, pcov = curve_fit(multi_gaussian, wavelength, intensity, p0=p0, maxfev=10000)
        
        # Calculate fitted curve
        fitted_curve = multi_gaussian(wavelength, *popt)
        
        # Calculate R-squared
        ss_res = np.sum((intensity - fitted_curve) ** 2)
        ss_tot = np.sum((intensity - np.mean(intensity)) ** 2)
        r_squared = 1 - (ss_res / ss_tot)
        
        # Organize parameters
        fitted_params = []
        for i in range(0, len(popt), 3):
            fitted_params.append({
                'amplitude': popt[i],
                'center': popt[i+1],
                'width': popt[i+2]
            })
        
        return fitted_params, fitted_curve, r_squared
    
    except Exception as e:
        print(f"Gaussian fitting failed: {e}")
        return None, None, None

def calculate_spectral_similarity(intensity1, intensity2, method='correlation'):
    """
    Calculate similarity between two spectra
    Returns similarity score
    """
    if method == 'correlation':
        similarity = np.corrcoef(intensity1, intensity2)[0, 1]
    elif method == 'cosine':
        dot_product = np.dot(intensity1, intensity2)
        norm1 = np.linalg.norm(intensity1)
        norm2 = np.linalg.norm(intensity2)
        similarity = dot_product / (norm1 * norm2)
    elif method == 'euclidean':
        similarity = 1 / (1 + np.linalg.norm(intensity1 - intensity2))
    else:
        raise ValueError("Method must be 'correlation', 'cosine', or 'euclidean'")
    
    return similarity

def create_similarity_matrix(data, stages=None, method='correlation'):
    """
    Create a similarity matrix between all spectra
    Returns similarity matrix and labels
    """
    if stages is None:
        stages = list(data.keys())
    
    # Collect all spectra
    spectra = []
    labels = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                spectra.append(file_data['intensity'])
                labels.append(f'S{stage}_F{file_num}')
    
    # Calculate similarity matrix
    n_spectra = len(spectra)
    similarity_matrix = np.zeros((n_spectra, n_spectra))
    
    for i in range(n_spectra):
        for j in range(n_spectra):
            if i == j:
                similarity_matrix[i, j] = 1.0
            else:
                similarity_matrix[i, j] = calculate_spectral_similarity(
                    spectra[i], spectra[j], method
                )
    
    return similarity_matrix, labels