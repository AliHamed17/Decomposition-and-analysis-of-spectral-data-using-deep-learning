import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from scipy import signal, interpolate
from scipy.stats import gaussian_kde
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

def plot_interactive_spectra_comparison(data, stages=None, max_files_per_stage=5):
    """
    Create an interactive comparison plot with play button and animation
    """
    if stages is None:
        stages = list(data.keys())
    
    # Prepare data for animation
    frames = []
    all_traces = []
    
    colors = px.colors.qualitative.Set1
    
    for stage_idx, stage in enumerate(stages):
        if stage not in data:
            continue
            
        stage_color = colors[stage_idx % len(colors)]
        file_numbers = list(data[stage].keys())[:max_files_per_stage]
        
        for file_idx, file_num in enumerate(file_numbers):
            file_data = data[stage][file_num]
            wavelength = file_data['wavelength']
            intensity = file_data['intensity']
            
            trace_name = f'Stage {stage} - File {file_num}'
            
            # Create trace for each frame
            trace = go.Scatter(
                x=wavelength,
                y=intensity,
                mode='lines',
                name=trace_name,
                line=dict(color=stage_color, width=2),
                visible=False
            )
            all_traces.append(trace)
    
    # Create frames for animation
    frame_count = 0
    for stage_idx, stage in enumerate(stages):
        if stage not in data:
            continue
            
        file_numbers = list(data[stage].keys())[:max_files_per_stage]
        
        for file_idx, file_num in enumerate(file_numbers):
            frame_data = []
            visible = [False] * len(all_traces)
            
            # Show all traces up to current frame
            for i in range(frame_count + 1):
                visible[i] = True
            
            frames.append(go.Frame(
                data=[trace.update(visible=vis) for trace, vis in zip(all_traces, visible)],
                name=f'frame_{frame_count}'
            ))
            frame_count += 1
    
    # Create figure
    fig = go.Figure(
        data=all_traces,
        frames=frames
    )
    
    # Set initial visibility
    for i, trace in enumerate(fig.data):
        trace.visible = i == 0
    
    # Add play button
    fig.update_layout(
        title="Interactive Spectral Comparison with Animation",
        xaxis_title="Wavelength",
        yaxis_title="Intensity",
        updatemenus=[{
            "buttons": [
                {
                    "args": [None, {"frame": {"duration": 500, "redraw": True},
                                   "fromcurrent": True}],
                    "label": "Play",
                    "method": "animate"
                },
                {
                    "args": [None, {"frame": {"duration": 0, "redraw": True},
                                   "mode": "immediate",
                                   "transition": {"duration": 0}}],
                    "label": "Pause",
                    "method": "animate"
                }
            ],
            "direction": "left",
            "pad": {"r": 10, "t": 87},
            "showactive": False,
            "type": "buttons",
            "x": 0.1,
            "xanchor": "right",
            "y": 0,
            "yanchor": "top"
        }],
        height=600
    )
    
    return fig

def plot_spectral_clustering(data, stages=None, n_clusters=3, method='kmeans'):
    """
    Perform clustering analysis on spectral data and visualize results
    """
    if stages is None:
        stages = list(data.keys())
    
    # Prepare data for clustering
    X = []
    labels = []
    stage_info = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                intensity = file_data['intensity']
                X.append(intensity)
                labels.append(f'S{stage}_F{file_num}')
                stage_info.append(stage)
    
    if len(X) < n_clusters:
        return None
    
    # Standardize data
    X = np.array(X)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Perform clustering
    if method == 'kmeans':
        clusterer = KMeans(n_clusters=n_clusters, random_state=42)
        cluster_labels = clusterer.fit_predict(X_scaled)
        
        # Calculate silhouette score
        if len(set(cluster_labels)) > 1:
            silhouette = silhouette_score(X_scaled, cluster_labels)
        else:
            silhouette = 0
            
    elif method == 'dbscan':
        clusterer = DBSCAN(eps=0.5, min_samples=2)
        cluster_labels = clusterer.fit_predict(X_scaled)
        n_clusters = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)
        
        if n_clusters > 1:
            # Only calculate silhouette for non-noise points
            non_noise = cluster_labels != -1
            if np.sum(non_noise) > 1 and len(set(cluster_labels[non_noise])) > 1:
                silhouette = silhouette_score(X_scaled[non_noise], cluster_labels[non_noise])
            else:
                silhouette = 0
        else:
            silhouette = 0
    
    # Create visualization
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=[
            'Cluster Visualization (PCA)',
            'Cluster Distribution',
            'Silhouette Analysis',
            'Cluster Centers'
        ],
        specs=[[{"type": "scatter"}, {"type": "bar"}],
               [{"type": "bar"}, {"type": "scatter"}]]
    )
    
    # PCA for visualization
    from sklearn.decomposition import PCA
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    
    # Plot clusters in PCA space
    colors = px.colors.qualitative.Set1
    for cluster_id in set(cluster_labels):
        if cluster_id == -1:  # Noise points for DBSCAN
            color = 'black'
            name = 'Noise'
        else:
            color = colors[cluster_id % len(colors)]
            name = f'Cluster {cluster_id}'
        
        mask = cluster_labels == cluster_id
        fig.add_trace(
            go.Scatter(
                x=X_pca[mask, 0],
                y=X_pca[mask, 1],
                mode='markers',
                name=name,
                marker=dict(color=color, size=8),
                text=[labels[i] for i in range(len(labels)) if mask[i]],
                showlegend=True
            ),
            row=1, col=1
        )
    
    # Cluster distribution
    cluster_counts = pd.Series(cluster_labels).value_counts().sort_index()
    fig.add_trace(
        go.Bar(
            x=[f'Cluster {i}' if i != -1 else 'Noise' for i in cluster_counts.index],
            y=cluster_counts.values,
            name='Count',
            showlegend=False
        ),
        row=1, col=2
    )
    
    # Silhouette score
    fig.add_trace(
        go.Bar(
            x=['Silhouette Score'],
            y=[silhouette],
            name='Quality',
            showlegend=False,
            marker_color='lightblue'
        ),
        row=2, col=1
    )
    
    # Cluster centers (for k-means)
    if method == 'kmeans' and hasattr(clusterer, 'cluster_centers_'):
        # Show first few wavelength points of cluster centers
        sample_wavelength = data[stages[0]][list(data[stages[0]].keys())[0]]['wavelength']
        n_points = min(50, len(sample_wavelength))
        
        for i, center in enumerate(clusterer.cluster_centers_):
            fig.add_trace(
                go.Scatter(
                    x=sample_wavelength[:n_points],
                    y=scaler.inverse_transform([center])[0][:n_points],
                    mode='lines',
                    name=f'Center {i}',
                    line=dict(color=colors[i % len(colors)]),
                    showlegend=False
                ),
                row=2, col=2
            )
    
    fig.update_layout(
        title=f'Spectral Clustering Analysis ({method.upper()}) - Silhouette Score: {silhouette:.3f}',
        height=800
    )
    
    return fig, cluster_labels, silhouette

def plot_spectral_heatmap_advanced(data, stages=None, interpolate_missing=True):
    """
    Create an advanced heatmap with interpolation and enhanced features
    """
    if stages is None:
        stages = list(data.keys())
    
    # Collect all data
    all_wavelengths = []
    all_intensities = []
    file_info = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                wavelength = file_data['wavelength']
                intensity = file_data['intensity']
                
                all_wavelengths.append(wavelength)
                all_intensities.append(intensity)
                file_info.append(f'S{stage}_F{file_num}')
    
    if not all_wavelengths:
        return None
    
    # Find common wavelength range
    min_wav = max(np.min(w) for w in all_wavelengths)
    max_wav = min(np.max(w) for w in all_wavelengths)
    
    # Create common wavelength grid
    common_wavelength = np.linspace(min_wav, max_wav, 1000)
    
    # Interpolate all spectra to common grid
    interpolated_intensities = []
    
    for wavelength, intensity in zip(all_wavelengths, all_intensities):
        # Filter to common range
        mask = (wavelength >= min_wav) & (wavelength <= max_wav)
        wav_filtered = wavelength[mask]
        int_filtered = intensity[mask]
        
        if len(wav_filtered) > 1:
            # Interpolate
            f = interpolate.interp1d(wav_filtered, int_filtered, kind='linear', fill_value='extrapolate')
            interpolated_intensity = f(common_wavelength)
            interpolated_intensities.append(interpolated_intensity)
        else:
            # If not enough points, skip this spectrum
            interpolated_intensities.append(np.full_like(common_wavelength, np.nan))
    
    # Create heatmap
    intensity_matrix = np.array(interpolated_intensities)
    
    fig = go.Figure(data=go.Heatmap(
        z=intensity_matrix,
        x=common_wavelength,
        y=file_info,
        colorscale='Viridis',
        hoverongaps=False,
        colorbar=dict(title="Intensity")
    ))
    
    fig.update_layout(
        title='Advanced Spectral Heatmap (Interpolated)',
        xaxis_title='Wavelength',
        yaxis_title='Files',
        height=max(400, len(file_info) * 20)
    )
    
    return fig

def plot_dynamic_range_analysis(data, stages=None):
    """
    Analyze and visualize the dynamic range of spectral data
    """
    if stages is None:
        stages = list(data.keys())
    
    # Calculate statistics for each file
    stats_data = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                intensity = file_data['intensity']
                
                stats = {
                    'stage': stage,
                    'file': file_num,
                    'min': np.min(intensity),
                    'max': np.max(intensity),
                    'mean': np.mean(intensity),
                    'std': np.std(intensity),
                    'range': np.max(intensity) - np.min(intensity),
                    'cv': np.std(intensity) / np.mean(intensity) if np.mean(intensity) != 0 else 0,
                    'snr': np.mean(intensity) / np.std(intensity) if np.std(intensity) != 0 else 0
                }
                stats_data.append(stats)
    
    df = pd.DataFrame(stats_data)
    
    # Create subplots
    fig = make_subplots(
        rows=2, cols=3,
        subplot_titles=[
            'Dynamic Range by Stage',
            'Signal-to-Noise Ratio',
            'Coefficient of Variation',
            'Min vs Max Intensity',
            'Mean vs Standard Deviation',
            'Distribution of Ranges'
        ]
    )
    
    # Dynamic range by stage
    for stage in stages:
        stage_data = df[df['stage'] == stage]
        if not stage_data.empty:
            fig.add_trace(
                go.Box(
                    y=stage_data['range'],
                    name=f'Stage {stage}',
                    showlegend=False
                ),
                row=1, col=1
            )
    
    # SNR by stage
    for stage in stages:
        stage_data = df[df['stage'] == stage]
        if not stage_data.empty:
            fig.add_trace(
                go.Box(
                    y=stage_data['snr'],
                    name=f'Stage {stage}',
                    showlegend=False
                ),
                row=1, col=2
            )
    
    # Coefficient of variation
    for stage in stages:
        stage_data = df[df['stage'] == stage]
        if not stage_data.empty:
            fig.add_trace(
                go.Box(
                    y=stage_data['cv'],
                    name=f'Stage {stage}',
                    showlegend=False
                ),
                row=1, col=3
            )
    
    # Min vs Max scatter
    colors = px.colors.qualitative.Set1
    for i, stage in enumerate(stages):
        stage_data = df[df['stage'] == stage]
        if not stage_data.empty:
            fig.add_trace(
                go.Scatter(
                    x=stage_data['min'],
                    y=stage_data['max'],
                    mode='markers',
                    name=f'Stage {stage}',
                    marker=dict(color=colors[i % len(colors)]),
                    showlegend=False
                ),
                row=2, col=1
            )
    
    # Mean vs Std scatter
    for i, stage in enumerate(stages):
        stage_data = df[df['stage'] == stage]
        if not stage_data.empty:
            fig.add_trace(
                go.Scatter(
                    x=stage_data['mean'],
                    y=stage_data['std'],
                    mode='markers',
                    name=f'Stage {stage}',
                    marker=dict(color=colors[i % len(colors)]),
                    showlegend=False
                ),
                row=2, col=2
            )
    
    # Range distribution
    fig.add_trace(
        go.Histogram(
            x=df['range'],
            nbinsx=20,
            name='Range Distribution',
            showlegend=False
        ),
        row=2, col=3
    )
    
    fig.update_layout(
        title='Dynamic Range and Signal Quality Analysis',
        height=800
    )
    
    return fig, df

def plot_spectral_fingerprint(data, stage, max_files=10):
    """
    Create a unique fingerprint visualization for each spectrum
    """
    if stage not in data:
        return None
    
    stage_data = data[stage]
    file_numbers = list(stage_data.keys())[:max_files]
    
    # Create polar plots for fingerprints
    fig = make_subplots(
        rows=2, cols=min(5, len(file_numbers)),
        specs=[[{"type": "polar"}] * min(5, len(file_numbers)),
               [{"type": "polar"}] * min(5, max(0, len(file_numbers) - 5))],
        subplot_titles=[f'File {num}' for num in file_numbers]
    )
    
    for i, file_num in enumerate(file_numbers):
        if i >= 10:  # Limit to 10 files
            break
            
        file_data = stage_data[file_num]
        intensity = file_data['intensity']
        
        # Create fingerprint by sampling intensity at regular intervals
        n_points = min(50, len(intensity))
        indices = np.linspace(0, len(intensity)-1, n_points, dtype=int)
        sampled_intensity = intensity[indices]
        
        # Normalize to [0, 1]
        if np.max(sampled_intensity) != np.min(sampled_intensity):
            normalized_intensity = (sampled_intensity - np.min(sampled_intensity)) / (np.max(sampled_intensity) - np.min(sampled_intensity))
        else:
            normalized_intensity = np.ones_like(sampled_intensity)
        
        # Create angles
        theta = np.linspace(0, 360, n_points, endpoint=False)
        
        row = 1 if i < 5 else 2
        col = (i % 5) + 1
        
        fig.add_trace(
            go.Scatterpolar(
                r=normalized_intensity,
                theta=theta,
                mode='lines+markers',
                name=f'File {file_num}',
                line=dict(width=2),
                marker=dict(size=4),
                showlegend=False
            ),
            row=row, col=col
        )
    
    fig.update_layout(
        title=f'Spectral Fingerprints - Stage {stage}',
        height=600
    )
    
    return fig

def plot_wavelength_importance(data, stages=None, method='variance'):
    """
    Analyze which wavelengths are most important for distinguishing stages
    """
    if stages is None:
        stages = list(data.keys())
    
    # Collect data organized by wavelength
    wavelength_data = {}
    stage_labels = []
    
    for stage in stages:
        if stage in data:
            for file_num, file_data in data[stage].items():
                wavelength = file_data['wavelength']
                intensity = file_data['intensity']
                
                for i, (wav, intens) in enumerate(zip(wavelength, intensity)):
                    if wav not in wavelength_data:
                        wavelength_data[wav] = []
                    wavelength_data[wav].append((intens, stage))
    
    # Calculate importance scores
    importance_scores = {}
    wavelengths = []
    
    for wav, values in wavelength_data.items():
        intensities = [v[0] for v in values]
        stages_for_wav = [v[1] for v in values]
        
        if method == 'variance':
            # Higher variance means more discriminative
            score = np.var(intensities)
        elif method == 'range':
            # Larger range means more discriminative
            score = np.max(intensities) - np.min(intensities)
        elif method == 'stage_separation':
            # How well this wavelength separates stages
            stage_means = {}
            for s in set(stages_for_wav):
                stage_intensities = [intensities[i] for i, stage in enumerate(stages_for_wav) if stage == s]
                stage_means[s] = np.mean(stage_intensities)
            
            if len(stage_means) > 1:
                score = np.var(list(stage_means.values()))
            else:
                score = 0
        
        importance_scores[wav] = score
        wavelengths.append(wav)
    
    # Sort by importance
    sorted_wavelengths = sorted(wavelengths, key=lambda x: importance_scores[x], reverse=True)
    sorted_scores = [importance_scores[wav] for wav in sorted_wavelengths]
    
    # Create visualization
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=[
            f'Wavelength Importance ({method.replace("_", " ").title()})',
            'Top 20 Most Important Wavelengths'
        ]
    )
    
    # Full spectrum importance
    fig.add_trace(
        go.Scatter(
            x=sorted_wavelengths,
            y=sorted_scores,
            mode='lines',
            name='Importance Score',
            line=dict(width=2, color='blue')
        ),
        row=1, col=1
    )
    
    # Top 20 wavelengths
    top_20 = sorted_wavelengths[:20]
    top_20_scores = sorted_scores[:20]
    
    fig.add_trace(
        go.Bar(
            x=top_20,
            y=top_20_scores,
            name='Top 20',
            marker_color='lightcoral'
        ),
        row=2, col=1
    )
    
    fig.update_layout(
        title=f'Wavelength Importance Analysis - {method.replace("_", " ").title()}',
        height=800
    )
    
    return fig, dict(zip(sorted_wavelengths, sorted_scores))