import streamlit as st
import time
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Callable
import threading
from queue import Queue
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json

class InteractiveProgressVisualizer:
    def __init__(self):
        self.progress_data = Queue()
        self.is_processing = False
        self.total_steps = 0
        self.current_step = 0
        self.step_details = {}
        self.start_time = None
        self.processing_stats = {
            'files_processed': 0,
            'files_total': 0,
            'errors_count': 0,
            'processing_speed': 0,
            'estimated_time_remaining': 0
        }
    
    def initialize_progress(self, total_steps: int, step_names: List[str]):
        """Initialize progress tracking with step details"""
        self.total_steps = total_steps
        self.current_step = 0
        self.step_details = {i: {'name': name, 'status': 'pending', 'duration': 0, 'details': ''} 
                           for i, name in enumerate(step_names)}
        self.start_time = time.time()
        self.is_processing = True
        
        # Clear any existing progress data
        while not self.progress_data.empty():
            self.progress_data.get()
    
    def update_step(self, step_index: int, status: str, details: str = "", duration: float = 0):
        """Update the status of a specific step"""
        if step_index in self.step_details:
            self.step_details[step_index].update({
                'status': status,
                'details': details,
                'duration': duration
            })
            
            if status == 'completed':
                self.current_step = max(self.current_step, step_index + 1)
            
            # Add to progress queue for real-time updates
            self.progress_data.put({
                'step_index': step_index,
                'status': status,
                'details': details,
                'timestamp': time.time()
            })
    
    def update_file_progress(self, files_processed: int, files_total: int, errors_count: int = 0):
        """Update file processing progress"""
        self.processing_stats.update({
            'files_processed': files_processed,
            'files_total': files_total,
            'errors_count': errors_count
        })
        
        # Calculate processing speed and ETA
        if self.start_time and files_processed > 0:
            elapsed_time = time.time() - self.start_time
            self.processing_stats['processing_speed'] = files_processed / elapsed_time
            
            if self.processing_stats['processing_speed'] > 0:
                remaining_files = files_total - files_processed
                self.processing_stats['estimated_time_remaining'] = remaining_files / self.processing_stats['processing_speed']
    
    def create_progress_dashboard(self, container):
        """Create an interactive progress dashboard"""
        with container:
            if not self.is_processing:
                st.info("No active processing tasks")
                return
            
            # Overall progress
            overall_progress = self.current_step / self.total_steps if self.total_steps > 0 else 0
            
            col1, col2, col3 = st.columns([2, 1, 1])
            
            with col1:
                st.progress(overall_progress, f"Overall Progress: {overall_progress:.1%}")
            
            with col2:
                elapsed = time.time() - self.start_time if self.start_time else 0
                st.metric("Elapsed Time", f"{elapsed:.1f}s")
            
            with col3:
                eta = self.processing_stats.get('estimated_time_remaining', 0)
                st.metric("ETA", f"{eta:.1f}s" if eta > 0 else "Calculating...")
            
            # Step-by-step progress
            st.subheader("Processing Steps")
            
            for i, step_info in self.step_details.items():
                col1, col2, col3, col4 = st.columns([3, 1, 1, 2])
                
                with col1:
                    step_name = step_info['name']
                    if step_info['status'] == 'completed':
                        st.success(f"✅ {step_name}")
                    elif step_info['status'] == 'processing':
                        st.info(f"⏳ {step_name}")
                    elif step_info['status'] == 'error':
                        st.error(f"❌ {step_name}")
                    else:
                        st.write(f"⏸️ {step_name}")
                
                with col2:
                    st.write(step_info['status'].title())
                
                with col3:
                    duration = step_info.get('duration', 0)
                    st.write(f"{duration:.1f}s" if duration > 0 else "-")
                
                with col4:
                    details = step_info.get('details', '')
                    if details:
                        st.caption(details)
            
            # File processing progress
            if self.processing_stats['files_total'] > 0:
                st.subheader("File Processing Progress")
                
                files_progress = self.processing_stats['files_processed'] / self.processing_stats['files_total']
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Files Processed", 
                             f"{self.processing_stats['files_processed']}/{self.processing_stats['files_total']}")
                
                with col2:
                    st.metric("Success Rate", 
                             f"{((self.processing_stats['files_processed'] - self.processing_stats['errors_count']) / max(1, self.processing_stats['files_processed'])):.1%}")
                
                with col3:
                    st.metric("Processing Speed", 
                             f"{self.processing_stats['processing_speed']:.1f} files/s")
                
                with col4:
                    st.metric("Errors", self.processing_stats['errors_count'])
                
                st.progress(files_progress, f"File Progress: {files_progress:.1%}")
    
    def create_real_time_chart(self, container):
        """Create real-time processing charts"""
        with container:
            if not self.is_processing:
                return
            
            # Create a real-time processing speed chart
            fig = make_subplots(
                rows=2, cols=1,
                subplot_titles=('Processing Speed', 'Cumulative Progress'),
                vertical_spacing=0.15
            )
            
            # Mock time series data for demonstration
            time_points = list(range(0, int(time.time() - (self.start_time or time.time())) + 1))
            processing_speeds = [self.processing_stats['processing_speed']] * len(time_points)
            cumulative_files = list(range(0, min(len(time_points), self.processing_stats['files_processed'] + 1)))
            
            # Processing speed chart
            fig.add_trace(
                go.Scatter(
                    x=time_points,
                    y=processing_speeds,
                    mode='lines+markers',
                    name='Files/Second',
                    line=dict(color='#1f77b4', width=2)
                ),
                row=1, col=1
            )
            
            # Cumulative progress chart
            fig.add_trace(
                go.Scatter(
                    x=time_points[:len(cumulative_files)],
                    y=cumulative_files,
                    mode='lines+markers',
                    name='Files Processed',
                    line=dict(color='#ff7f0e', width=2),
                    fill='tonexty'
                ),
                row=2, col=1
            )
            
            fig.update_layout(
                height=400,
                title="Real-Time Processing Metrics",
                showlegend=True
            )
            
            fig.update_xaxes(title_text="Time (seconds)")
            fig.update_yaxes(title_text="Speed (files/s)", row=1, col=1)
            fig.update_yaxes(title_text="Files Processed", row=2, col=1)
            
            st.plotly_chart(fig, use_container_width=True)
    
    def create_step_timeline(self, container):
        """Create a timeline visualization of processing steps"""
        with container:
            if not self.step_details:
                return
            
            # Create timeline data
            timeline_data = []
            for i, step_info in self.step_details.items():
                status_color = {
                    'completed': '#28a745',
                    'processing': '#ffc107',
                    'error': '#dc3545',
                    'pending': '#6c757d'
                }.get(step_info['status'], '#6c757d')
                
                timeline_data.append({
                    'step': step_info['name'],
                    'status': step_info['status'],
                    'duration': step_info.get('duration', 0),
                    'color': status_color,
                    'details': step_info.get('details', '')
                })
            
            # Create Gantt-like chart
            fig = go.Figure()
            
            for i, data in enumerate(timeline_data):
                fig.add_trace(go.Bar(
                    x=[data['duration']] if data['duration'] > 0 else [1],
                    y=[data['step']],
                    orientation='h',
                    marker_color=data['color'],
                    name=data['status'].title(),
                    text=data['details'] if data['details'] else data['status'],
                    textposition='inside',
                    showlegend=i == 0 or data['status'] not in [item['status'] for item in timeline_data[:i]]
                ))
            
            fig.update_layout(
                title="Processing Steps Timeline",
                xaxis_title="Duration (seconds)",
                yaxis_title="Processing Steps",
                height=max(300, len(timeline_data) * 50),
                barmode='overlay'
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    def create_loading_animation(self, container, message: str = "Processing..."):
        """Create an animated loading indicator"""
        with container:
            # Create loading dots animation using markdown
            loading_placeholder = st.empty()
            
            dots = ""
            for _ in range(3):
                dots += "."
                loading_placeholder.markdown(f"**{message}{dots}**")
                time.sleep(0.5)
    
    def create_circular_progress(self, container, progress: float, title: str = "Progress"):
        """Create a circular progress indicator"""
        with container:
            # Create circular progress using plotly
            fig = go.Figure(go.Indicator(
                mode = "gauge+number+delta",
                value = progress * 100,
                domain = {'x': [0, 1], 'y': [0, 1]},
                title = {'text': title},
                delta = {'reference': 0},
                gauge = {
                    'axis': {'range': [None, 100]},
                    'bar': {'color': "darkblue"},
                    'steps': [
                        {'range': [0, 50], 'color': "lightgray"},
                        {'range': [50, 100], 'color': "gray"}
                    ],
                    'threshold': {
                        'line': {'color': "red", 'width': 4},
                        'thickness': 0.75,
                        'value': 90
                    }
                }
            ))
            
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)
    
    def finish_processing(self):
        """Mark processing as complete"""
        self.is_processing = False
        
        # Mark any pending steps as completed
        for step_info in self.step_details.values():
            if step_info['status'] == 'pending':
                step_info['status'] = 'completed'
    
    def create_progress_summary(self, container):
        """Create a summary of the completed processing"""
        with container:
            if self.is_processing:
                st.warning("Processing still in progress...")
                return
            
            total_time = time.time() - self.start_time if self.start_time else 0
            completed_steps = sum(1 for step in self.step_details.values() if step['status'] == 'completed')
            error_steps = sum(1 for step in self.step_details.values() if step['status'] == 'error')
            
            st.success("Processing Complete!")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Time", f"{total_time:.1f}s")
            
            with col2:
                st.metric("Steps Completed", f"{completed_steps}/{self.total_steps}")
            
            with col3:
                st.metric("Files Processed", self.processing_stats['files_processed'])
            
            with col4:
                st.metric("Errors", error_steps + self.processing_stats['errors_count'])
            
            # Show processing efficiency
            if total_time > 0 and self.processing_stats['files_processed'] > 0:
                efficiency = self.processing_stats['files_processed'] / total_time
                st.info(f"Average processing speed: {efficiency:.2f} files per second")


def create_data_loading_progress_demo():
    """Create a demo of the interactive progress system"""
    st.header("🔄 Interactive Data Loading Progress")
    
    # Initialize progress visualizer
    if 'progress_visualizer' not in st.session_state:
        st.session_state.progress_visualizer = InteractiveProgressVisualizer()
    
    visualizer = st.session_state.progress_visualizer
    
    # Demo controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Start Demo Processing", type="primary"):
            # Initialize demo processing
            steps = [
                "Uploading Files",
                "Validating Data",
                "Extracting Spectral Data", 
                "Organizing by Stages",
                "Processing Analysis",
                "Generating Visualizations"
            ]
            
            visualizer.initialize_progress(len(steps), steps)
            
            # Simulate processing steps
            for i, step in enumerate(steps):
                step_start = time.time()
                visualizer.update_step(i, 'processing', f"Processing {step.lower()}...")
                
                # Simulate processing time
                time.sleep(1)
                
                # Simulate file processing
                if i >= 2:  # Start file processing from step 3
                    for file_num in range(1, 11):
                        visualizer.update_file_progress(file_num, 10, 0)
                        time.sleep(0.1)
                
                step_duration = time.time() - step_start
                visualizer.update_step(i, 'completed', f"Completed {step.lower()}", step_duration)
            
            visualizer.finish_processing()
    
    with col2:
        if st.button("Reset Progress"):
            st.session_state.progress_visualizer = InteractiveProgressVisualizer()
            st.rerun()
    
    with col3:
        if st.button("Simulate Error"):
            visualizer.update_step(2, 'error', "Failed to extract data from corrupted file")
    
    # Progress dashboard containers
    dashboard_container = st.container()
    chart_container = st.container()
    timeline_container = st.container()
    summary_container = st.container()
    
    # Update displays
    visualizer.create_progress_dashboard(dashboard_container)
    visualizer.create_real_time_chart(chart_container)
    visualizer.create_step_timeline(timeline_container)
    
    if not visualizer.is_processing:
        visualizer.create_progress_summary(summary_container)